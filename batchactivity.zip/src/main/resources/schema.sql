DROP TABLE IF EXISTS `files`;
CREATE TABLE `files` (
	`id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
	`fileName` VARCHAR(100),
	`arrivalTs` VARCHAR(100),
	`county` VARCHAR(100),
	`processingStartTs` VARCHAR(100),
	`processingEndTs` VARCHAR(100),
	`processingStatus` VARCHAR(100),
	`numberOfErrors` INT(3),
	`numberOfRecords` INT(3),
	`fileType` VARCHAR(10),
	`error` VARCHAR(200),
	`controlNumber` INT(3),
	PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;