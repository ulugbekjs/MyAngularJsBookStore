package com.batchactivity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


import java.sql.SQLException;
import org.springframework.context.ConfigurableApplicationContext;


@SpringBootApplication
public class BatchactivityApplication {

	public static void main(String[] args) {
		SpringApplication.run(BatchactivityApplication.class, args);
	}
}
