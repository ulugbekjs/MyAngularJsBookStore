package com.batchactivity.dao;

import com.batchactivity.models.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class FileDAO implements IFileDAO {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	// find all files
	@Override
	public List<File> findAll() {
		return jdbcTemplate.query("SELECT * FROM files", new FileRowMapper());
	}
}


// Mapper class
class FileRowMapper implements RowMapper<File> {
	@Override
	public File mapRow(ResultSet rs, int rowNum) throws SQLException {
		
		File file = new File();
		file.setId(rs.getInt("id"));
		file.setFileName(rs.getString("fileName"));
		file.setArrivalTs(rs.getString("arrivalTs"));
		file.setCounty(rs.getString("county"));
		file.setProcessingStartTs(rs.getString("processingStartTs"));
		file.setProcessingEndTs(rs.getString("processingEndTs"));
		file.setProcessingStatus(rs.getString("processingStatus"));
		file.setNumberOfErrors(rs.getInt("numberOfErrors"));
		file.setNumberOfRecords(rs.getInt("numberOfRecords"));
		file.setFileType(rs.getString("fileType"));
		file.setError(rs.getString("error"));
		file.setControlNumber(rs.getInt("controlNumber"));
		
		return file;
	}
	
}
