package com.batchactivity.dao;

import java.util.List;
import com.batchactivity.models.File;

public interface IFileDAO {
	public List<File> findAll();
}
