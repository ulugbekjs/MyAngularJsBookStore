package com.batchactivity.models;

public class File {
	private int id;
	private String fileName;
	private String arrivalTs;
	private String county;
	private String processingStartTs;
	private String processingEndTs;
	private String processingStatus;
	private int numberOfErrors;
	private int numberOfRecords;
	private String fileType;
	private String error;
	private int controlNumber;

	public File() {
		this.id = 0;
		this.fileName = "";
		this.arrivalTs = "";
		this.county = "";
		this.processingStartTs = "";
		this.processingEndTs = "";
		this.processingStatus = "";
		this.numberOfErrors = 0;
		this.numberOfRecords = 0;
		this.fileType = "";
		this.error = "";
		this.controlNumber = 0;
	}

	public File(int id, String fileName, String arrivalTs, String county, String processingStartTs,
			String processingEndTs, String processingStatus, int numberOfErrors, int numberOfRecords, String fileType,
			String error, int controlNumber) {
		this.id = id;
		this.fileName = fileName;
		this.arrivalTs = arrivalTs;
		this.county = county;
		this.processingStartTs = processingStartTs;
		this.processingEndTs = processingEndTs;
		this.processingStatus = processingStatus;
		this.numberOfErrors = numberOfErrors;
		this.numberOfRecords = numberOfRecords;
		this.fileType = fileType;
		this.error = error;
		this.controlNumber = controlNumber;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}


	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getArrivalTs() {
		return arrivalTs;
	}
	public void setArrivalTs(String arrivalTs) {
		this.arrivalTs = arrivalTs;
	}
	public String getCounty() {
		return county;
	}
	public void setCounty(String county) {
		this.county = county;
	}
	public String getProcessingStartTs() {
		return processingStartTs;
	}
	public void setProcessingStartTs(String processingStartTs) {
		this.processingStartTs = processingStartTs;
	}
	public String getProcessingEndTs() {
		return processingEndTs;
	}
	public void setProcessingEndTs(String processingEndTs) {
		this.processingEndTs = processingEndTs;
	}
	public String getProcessingStatus() {
		return processingStatus;
	}
	public void setProcessingStatus(String processingStatus) {
		this.processingStatus = processingStatus;
	}
	public int getNumberOfErrors() {
		return numberOfErrors;
	}
	public void setNumberOfErrors(int numberOfErrors) {
		this.numberOfErrors = numberOfErrors;
	}
	public int getNumberOfRecords() {
		return numberOfRecords;
	}
	public void setNumberOfRecords(int numberOfRecords) {
		this.numberOfRecords = numberOfRecords;
	}
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	public int getControlNumber() {
		return controlNumber;
	}
	public void setControlNumber(int controlNumber) {
		this.controlNumber = controlNumber;
	}

	
	
	
	
}
