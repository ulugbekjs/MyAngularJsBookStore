package com.batchactivity.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.batchactivity.models.File;
import com.batchactivity.service.IFileService;

@RestController
public class FileController {
	
	// This is dummy API key, in the future we ll implement JWT
	private final static String API_KEY = "ABC123";	

	@Autowired IFileService fileService;
	
	@RequestMapping("/files")
	public List<File> allFiles(@RequestParam(value="key", defaultValue=API_KEY) String key) {
		System.out.println("param value: "  + key + " API_KEY:  " + API_KEY);
		if(key.equals(API_KEY)) {
			return fileService.getAllFiles();
		} 
		System.out.println("API_KEY is not match");
		return null;
	}
	
	
}
