package com.batchactivity.service;

import java.util.List;
import com.batchactivity.models.File;

public interface IFileService {
	public List<File> getAllFiles();
	public List<File> getFilesByFileType(String fileType);
	public List<File> getFilesByDateRange(String startDate, String endDate);
}
