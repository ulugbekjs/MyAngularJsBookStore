package com.batchactivity.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.batchactivity.dao.IFileDAO;
import com.batchactivity.models.File;

@Service
public class FileService implements IFileService {
	
	@Autowired
	private IFileDAO fileDAO;

	@Override
	public List<File> getAllFiles() {
		return fileDAO.findAll();
	}	

	@Override
	public List<File> getFilesByFileType(String fileType) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<File> getFilesByDateRange(String startDate, String endDate) {
		// TODO Auto-generated method stub
		return null;
	}

}
