import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { LocationResultsPage } from '../locationresults/locationresults';


/*
  Generated class for the locations page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-locations',
  templateUrl: 'locations.html'
})
export class LocationsPage {
//pages

shownGroup = null;
hRetailer = false;
hideRest = false;
hATM = false;
checkBTitle1 = 'Retailers';
checkBTitle2 = "Restaurarnts & Farmer's Market";
checkBTitle3 = 'ATMs';
fnsAuthRetailer = false;
SNAPRetailer = false;
WICRetailer = false;
fnaAuthRestAndMrkt = false;
cashAccessATM = false;
surchargeFreeATM = false;
retailerFnsAuthDesc= 'FNS-Authorized';
retailerSNAPDesc = 'SNAP'; 
retailerWICDesc = 'WIC';
restailerFnsAuthDesc= 'FNS-Authorized';
atmCashLocDesc = 'Cash Access Location';
atmSurchargeDesc = 'Surcharge - Free';
userSearchTag = [];
userSearchSubTag = [];
searchPlaceHolder = 'e.g Name, Address, Zip, City or County';
defaultSrchVal = '';
searchWarningText = 'Please give valid input';


  constructor(public navCtrl: NavController, public navParams: NavParams) {
    this.navCtrl = navCtrl;
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad LocationsPage');
  }

   toggleGroup(group) {
    if (this.isGroupShown(group)) {
      this.shownGroup = null;
    } else {
      this.shownGroup = group;
    }
  };

   isGroupShown(group) {
    return this.shownGroup === group;
  }; 

  changeRet(){    
    if(this.hRetailer)
    {
      this.hRetailer = false;
    }else if(!this.hRetailer){
      this.hRetailer = true;
    }
  }

  changeRest(){    
    if(this.hideRest)
    {
      this.hideRest = false;
    }else if(!this.hideRest){
      this.hideRest = true;
    }
  }

  changeATM(){    
    if(this.hATM)
    {
      this.hATM = false;
    }else if(!this.hATM){
      this.hATM = true;
    }
  }

  goToNextPage(){    

    if((!this.fnsAuthRetailer && !this.SNAPRetailer && !this.WICRetailer && !this.fnaAuthRestAndMrkt &&  !this.cashAccessATM && !this.surchargeFreeATM) && this.defaultSrchVal===''){      
      return false;
    }

    if(this.fnsAuthRetailer || this.SNAPRetailer || this.WICRetailer){      
      // this.userSearchTag = this.userSearchTag+this.checkBTitle1+', ';
      this.userSearchTag.push(this.checkBTitle1);
      if(this.fnsAuthRetailer){
        //  this.userSearchSubTag = this.userSearchSubTag+this.retailerFnsAuthDesc+', ';
        this.userSearchSubTag.push(this.retailerFnsAuthDesc);
      }
      if(this.SNAPRetailer){
        // this.userSearchSubTag = this.userSearchSubTag+this.retailerSNAPDesc+', ';
        this.userSearchSubTag.push(this.retailerSNAPDesc);
      }
      if(this.WICRetailer){
        // this.userSearchSubTag = this.userSearchSubTag+this.retailerWICDesc+', ';
        this.userSearchSubTag.push(this.retailerWICDesc);
      }
    }
    if(this.fnaAuthRestAndMrkt){
      //  this.userSearchTag =  this.userSearchTag+this.checkBTitle2+', ';
       this.userSearchTag.push(this.checkBTitle2);       
       if(!this.fnsAuthRetailer){
        //  this.userSearchSubTag = this.userSearchSubTag+this.restailerFnsAuthDesc+', ';
         this.userSearchSubTag.push(this.restailerFnsAuthDesc);
       }
    }
    if(this.cashAccessATM || this.surchargeFreeATM){
      //  this.userSearchTag =  this.userSearchTag+this.checkBTitle3+'';
       this.userSearchTag.push(this.checkBTitle3);
        if(this.cashAccessATM){
        //  this.userSearchSubTag = this.userSearchSubTag+this.atmCashLocDesc+', ';
         this.userSearchSubTag.push(this.atmCashLocDesc);
       }
        if(this.surchargeFreeATM){
        //  this.userSearchSubTag = this.userSearchSubTag+this.atmSurchargeDesc+'';
         this.userSearchSubTag.push(this.atmSurchargeDesc);
       }
    }     
    this.navCtrl.push(LocationResultsPage,{userSearchTag : this.userSearchTag,userSearchSubTag : this.userSearchSubTag});    //Passing data to next page.

    this.userSearchTag = [];
    this.userSearchSubTag = [];

  }
  goBackToPrvPage(){
    this.navCtrl.pop();
  }

}
