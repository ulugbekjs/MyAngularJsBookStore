import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name: "txnfilter",
    pure: false
})
export class TrnTypeFilter implements PipeTransform {

    transform(items: Array<any>, conditions: {[field: string]: any}): Array<any> {
        return items.filter(item => {
            for (let field in conditions) {
                if (item[field] == conditions[field] || conditions[field] == "ALL"  ) {
                    return true;
                }
            }
            return false;
        });
    }
}
