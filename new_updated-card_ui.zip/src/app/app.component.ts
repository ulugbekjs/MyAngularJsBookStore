import { Component, ViewChild } from '@angular/core';
import { Nav, MenuController, Platform } from 'ionic-angular';
import { StatusBar, Splashscreen } from 'ionic-native';
import { TabsPage } from '../pages/tabs/tabs';
import { LoginPage } from '../pages/login/login';

import { HomePage } from '../pages/home/home';
import { TransactionsPage } from '../pages/transactions/transactions';
import { SettingsPage } from '../pages/settings/settings';
import { AuthService } from '../providers/auth-service';
import { LanguagePage } from '../pages/language/language';
import { ResourcesPage } from '../pages/resources/resources';
import { TranslateService } from 'ng2-translate/ng2-translate';
import { LocationPage } from '../location/location';

export interface PageInterface {
  title: string;
  component: any;
  icon: string;
  index?: number;
 
}

@Component({
  templateUrl: 'app.html'
})

export class MyApp {
  Pages: PageInterface[] = [
    { title: 'Home', component: TabsPage, icon: 'calendar' },
    { title: 'About', component: TabsPage, index: 1, icon: 'information-circle' },
    { title: 'LocationsPage', component: TabsPage, index: 2, icon: 'LocationsPage' },
    { title: 'Setting', component: TabsPage, index: 3, icon: 'Setting' },
    { title: 'Language', component: LanguagePage, index: 4, icon: 'Language' },
    { title: 'Resources', component: ResourcesPage, index: 5, icon: 'Resources' },
    { title: 'TransactionsPage', component: TransactionsPage, index: 6, icon: 'Food' },
    { title: 'TransactionsPage', component: TransactionsPage, index: 7, icon: 'Cash' },
  ];

  rootPage = LoginPage;
 // rootPage = TabsPage;
  shownGroup = null;
  @ViewChild(Nav) nav: Nav;

  constructor(platform: Platform, public menu: MenuController, private auth: AuthService, private translate: TranslateService) {
    platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      StatusBar.styleDefault();
      Splashscreen.hide();
      this.initTranslation();
    });
  }

  openPage(page: PageInterface) {
    // Reset the content nav to have just this page
    // we wouldn't want the back button to show in this scenario
    //this.nav.setRoot(TransactionsPage);
    // let params = {};

    console.log(page);
    this.menu.close();

    if (page.index) {
      this.nav.setRoot(page.component, { tabIndex: page.index });
    }
    else if(page.index==4 )
    {
      this.nav.setRoot(page.component );
    }
    else if(page.index==5 )
    {
      this.nav.setRoot(page.component );
    }
    else if(page.index==6 )
    {
      this.nav.setRoot(page.component,{tabIndex: page.index});

    }
     else if(page.index==7 )
    {
      this.nav.setRoot(page.component,{tabIndex: page.index});

    }
    else {
      this.nav.setRoot(page.component).catch(() => {
        console.log("Didn't set nav root");
      });
    }
  }
  
  toggleGroup(group) {
    if (this.isGroupShown(group)) {
      this.shownGroup = null;
    } else {
      this.shownGroup = group;
    }
  };

  isGroupShown(group) {
    return this.shownGroup === group;
  };

  public logout() {
    this.auth.logout().subscribe(succ => {
      this.nav.setRoot(LoginPage)
      this.menu.close();
    });
  }

  initTranslation() {
    var userLang = navigator.language.split('-')[0]; // use navigator lang if available
    userLang = /(fr|en|es|in|zh)/gi.test(userLang) ? userLang : 'es';
    console.log("before" + userLang);
    // this language will be used as a fallback when a translation isn't found in the current language
    this.translate.setDefaultLang('es');
    console.log("after" + userLang);
    // the lang to use, if the lang isn't available, it will use the current loader to get them
    this.translate.use('en');
    this.translate.get("HOME", null).subscribe(localizedValue => console.log(localizedValue));
  }

  /*ngAfterViewInit() {
    if (this.auth.authenticated()) {
      this.nav.setRoot(HomePage)
    }
  }*/

}
