package com.efunds.gov.email.ondemand;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;


public class EmailAPI {
	
	private final Logger logger = Logger.getLogger(EmailAPI.class);  
	
	// Sample EmailTemplates, we can manipulate more templates according to the needs
	public enum EmailTemplates {		
		TEMPLATE_01("Subject for CONTENT_TYPE_01", "email-template.ftl", 4),
		TEMPLATE_02("Subject for CONTENT_TYPE_02", "email-template2.ftl", 4),
		TEMPLATE_DEFAULT("Subject for CONTENT_DEFAULT", "email-template3.ftl", 4);
		
		private String emailSubject;
		private String template;
		private int modelSize;
		
		EmailTemplates(String emailSubject, String template, int modelSize) {
			this.emailSubject = emailSubject;
			this.template = template;			
			this.modelSize = modelSize;
		}
		
		private String getEmailSubject() {
			return this.emailSubject;
		}				
		private String getTemplate() {
			return this.template;
		}
		private int getModelSize() {
			return this.modelSize;
		}
		
	}
	
	
	private Mail mail = null;
	private EmailTemplates template = null;
	
	public EmailAPI() {
		this.mail = new Mail();
	}
	
//	Mandatory settings	
	public EmailAPI from(String mailFrom) {
		this.mail.setMailFrom(mailFrom);
		return this;
	}
	public EmailAPI to(String mailTo) {
		this.mail.setMailTo(mailTo);
		return this;
	}

//	Option 1: Let users set "Email Subject" and "Email Content" 	
	public EmailAPI subject(String mailSubject) {
		this.mail.setMailSubject(mailSubject);
		return this;
	}
	public EmailAPI content(String mailContent) {
		this.mail.setMailContent(mailContent);
		return this;
	}
	
//	Option 2: By selecting "EmailContentType.*" will automatically set the proper "Email Subject" and "Email Content"
	public EmailAPI setEmailTemplate(EmailTemplates emailTemplate, Map<String, String> model) {
		this.mail.setMailSubject(emailTemplate.getEmailSubject());
		this.mail.setContentType(emailTemplate.getTemplate());
		this.mail.setModel(model);
		this.mail.setMailContent("please do not delete this. This is a dummy-content, will be replaced by HTML-template");
		template = emailTemplate;
		return this;
	}
	
//	Optional
	public EmailAPI addAttachment(File file) {
		System.out.println("* * * file attachement");
		List <File> attachments = this.mail.getAttachments();
		attachments.add(file);
		this.mail.setAttachments(attachments);
		System.out.println("* * * file attachement");
		return this;
	}
	
	/**
	 *	Sending the email 
	*/		
	public void send() {
		logger.info("Enter -> EmailAPI.send()");
		
		if(validateMail(mail)) {
			AbstractApplicationContext context = new AnnotationConfigApplicationContext(EmailConfig.class);
	        MailService mailService = (MailService) context.getBean("mailService");
	        mailService.sendEmail(this.mail);
	        context.close();
		}else {
			logger.error("Error: input Mail validation error, please see above which Mail paramter is not set correctly...");
		}
        
        logger.info("Exit -> EmailAPI.send()");
	}
	
	
	/** 
	 * @param mail
	 * 
	 */	
	private boolean validateMail(Mail mail) {
		boolean output = true;
		EmailValidator emailValidator = new EmailValidator();
		if(!emailValidator.validate(mail.getMailFrom())){
			logger.error("Error: From@email is not set proerly");
			output = false;
		} else if(!emailValidator.validate(mail.getMailTo())){
			logger.error("Error: To@email is not set proerly");
			output = false;
		} else if(mail.getMailSubject() == null){
			logger.error("Error: Email subject is Empty");
			output = false;
		} else if(mail.getMailContent() == null) {
			logger.error("Error: Email content is Empty");
			output = false;
		} else if (template != null && mail.getModel().size() != template.getModelSize()){
			logger.error("Error: model.size() did not match to the number of placeholders in EmailTemplate");
			logger.error("Selected EmailTemplate: " + template);
			logger.error("Selected EmailTemplate requires " + template.getModelSize() + " entries");
			logger.error("--------------------------------------------------------------------------");
			output = false;
		}
		return output;
	}

}
