package com.efunds.gov.main;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.efunds.gov.email.batch.common.Commons;
import com.efunds.gov.email.batch.controller.MailerController;
import com.efunds.gov.email.ondemand.EmailAPI;

public class App {
	
	public static void main( String[] args )
    {
		// This is sample usage of "on-demand EmailAPI"
		// all the source code for "on-demand EmailAPI" is in [com.efunds.gov.email.ondemand] package.
		
		
		EmailAPI myapi = new EmailAPI();
		
		Map<String, String> model = new HashMap<String, String>();
		model.put("firstName", "John");
		model.put("lastName", "Deer");
		model.put("signature", "FIS");
		model.put("location", "WI");
		
		myapi.from("sample-from@email.com")
		.to("sample-to@email.com")		
		.setEmailTemplate(EmailAPI.EmailTemplates.TEMPLATE_01, model)
		.addAttachment(new File("C://temp2.csv"))
		.send();
		
		
		
		// This is sample run for Email batch send
		/*	
		// Launcher will provide the 3 parameters: agency, dateOfRun, timeInterval
		// agency: "CAEBT"
		// dateOfRun: "09/28/2017"
		// timeInterval: 2 (in hours)
    	String[] tempArgs = {"CAEBT", "10/10/2017", "2"};
    	
    	// Setting up the System properties
    	Commons.setSystemProperties(tempArgs);
    	
    	ClassPathXmlApplicationContext appContext = new ClassPathXmlApplicationContext(new String[] {"email-application.xml"});
    	BeanFactory factory = (BeanFactory) appContext;
    	MailerController controller = (MailerController)factory.getBean("emailController"); 
    	
    	// Launching the email module
    	controller.callEmailModule();
    	*/
		

    }

}
