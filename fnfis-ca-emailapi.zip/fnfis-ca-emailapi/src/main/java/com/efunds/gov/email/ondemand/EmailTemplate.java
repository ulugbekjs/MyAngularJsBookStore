package com.efunds.gov.email.ondemand;

public enum EmailTemplate {
	TEMPLATE_01("Subject for CONTENT_TYPE_01", "email-template.ftl", 4),
	TEMPLATE_02("Subject for CONTENT_TYPE_02", "email-template2.ftl", 4),
	TEMPLATE_DEFAULT("Subject for CONTENT_DEFAULT", "email-template3.ftl", 4);
	
	private String 	emailSubject;
	private String 	templateUrl;
	private int 	modelSize;
	
	EmailTemplate(String emailSubject, String templateUrl, int modelSize) {
		this.emailSubject = emailSubject;
		this.templateUrl = templateUrl;			
		this.modelSize = modelSize;
	}
	
	public String getEmailSubject() {
		return this.emailSubject;
	}				
	public String getTemplateUrl() {
		return this.templateUrl;
	}
	public int getModelSize() {
		return this.modelSize;
	}
}
