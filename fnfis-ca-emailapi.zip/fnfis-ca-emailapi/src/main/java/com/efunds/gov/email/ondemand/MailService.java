package com.efunds.gov.email.ondemand;

public interface MailService {
	public void sendEmail(Mail mail);
}
