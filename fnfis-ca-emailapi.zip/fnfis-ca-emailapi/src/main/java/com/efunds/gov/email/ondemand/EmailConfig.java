package com.efunds.gov.email.ondemand;

import java.util.Properties;

import org.apache.log4j.Logger;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.ui.freemarker.FreeMarkerConfigurationFactoryBean;
 
@Configuration
@ComponentScan(basePackages = "com.efunds.gov.email.ondemand")
public class EmailConfig {
	
	private final Logger logger = Logger.getLogger(EmailConfig.class);
	
    @Bean
    public JavaMailSender emailSender() {
    	logger.info("Enter -> EmailConfig.getMailSender()");
    	
        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
 
        // This is gmail SMTP host settings
        // This will be changed to FIS SMTP host settings
        mailSender.setHost("smtp.gmail.com");
        mailSender.setPort(587);
        mailSender.setUsername("your-email");
        mailSender.setPassword("your-password");
 
        Properties javaMailProperties = new Properties();
        
        javaMailProperties.put("mail.smtp.starttls.enable", "true");
        javaMailProperties.put("mail.smtp.auth", "true");
        javaMailProperties.put("mail.transport.protocol", "smtp");
        javaMailProperties.put("mail.debug", "true");
 
        mailSender.setJavaMailProperties(javaMailProperties);
        
        logger.info("Exit -> EmailConfig.getMailSender()");
        return mailSender;
    }
 
    @Bean
    public FreeMarkerConfigurationFactoryBean fmConfiguration() {
    	logger.info("Enter -> EmailConfig.getFreeMarkerConfiguration()");
        
    	FreeMarkerConfigurationFactoryBean fmConfigFactoryBean = new FreeMarkerConfigurationFactoryBean();
        fmConfigFactoryBean.setTemplateLoaderPath("/templates/");
        
        logger.info("Exit -> EmailConfig.getFreeMarkerConfiguration()");
        return fmConfigFactoryBean;
    }
}