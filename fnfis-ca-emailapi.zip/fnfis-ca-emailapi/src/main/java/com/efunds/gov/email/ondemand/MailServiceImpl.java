package com.efunds.gov.email.ondemand;


import java.io.File;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
 
import freemarker.template.Configuration;
 
@Service("mailService")
public class MailServiceImpl implements MailService {
	
	private final Logger logger = Logger.getLogger(MailServiceImpl.class);  
 
    @Autowired
    JavaMailSender emailSender;
 
    @Autowired
    Configuration fmConfiguration;
 
    public void sendEmail(Mail mail) {
    	logger.info("Enter -> MailServiceImpl.sendEmail(Mail mail)");
    	
    	
        MimeMessage mimeMessage = emailSender.createMimeMessage();
 
        try {
 
            MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true);
 
            mimeMessageHelper.setSubject(mail.getMailSubject());
            mimeMessageHelper.setFrom(mail.getMailFrom());
            mimeMessageHelper.setTo(mail.getMailTo());
            mail.setMailContent(geContentFromTemplate(mail));
            mimeMessageHelper.setText(mail.getMailContent(), true);
            
            if(mail.getAttachments() != null && mail.getAttachments().size() > 0) {
            	for(File attachment: mail.getAttachments()) {
            		mimeMessageHelper.addAttachment(attachment.getName(), attachment);
            	}
            }
 
            logger.info(mail.getMailContent());
            //emailSender.send(mimeMessageHelper.getMimeMessage());
            
        } catch (MessagingException e) {
            e.printStackTrace();
            logger.error("Error: " + e.getMessage());
        }
        
        logger.info("Exit -> MailServiceImpl.sendEmail(Mail mail)");
    }
 
    private String geContentFromTemplate(Mail mail) {
    	logger.info("Enter -> MailServiceImpl.geContentFromTemplate.(Mail mail)");
        StringBuffer content = new StringBuffer();
 
        try {
            content.append(FreeMarkerTemplateUtils
            		.processTemplateIntoString(fmConfiguration.getTemplate(mail.getContentType()), mail.getModel()));
        } catch (Exception e) {
            e.printStackTrace();
            logger.info("Error: " + e.getMessage());
        }
        logger.info("Exit -> MailServiceImpl.geContentFromTemplate.(Mail mail)");
        return content.toString();
    }
 
}