package com.efunds.gov.email.batch.dao;

import java.util.List;

public interface MailerDAO {
	public List getEmailList(String format, String agency);
	public void updateAlertTable(final List sendEmailList);
	
	// will be deleted
	public void demoPopulateAlertTable();
	public void demoPopulateClientTable();
	public void demoAlertTableStatusOn();
	
}