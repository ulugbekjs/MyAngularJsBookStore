package com.efunds.gov.email.batch.common;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESedeKeySpec;

import org.apache.axis.encoding.Base64;

public class DecryptPasswordTripleDES {

	public static String decrypt(String key, String cipherText)
		throws
			NoSuchPaddingException,
			InvalidKeyException,
			IllegalBlockSizeException,
			BadPaddingException,
			InvalidKeySpecException,
			NoSuchAlgorithmException {

		Cipher desCipher = null;
		byte[] enckey = null;
		SecretKey secretKey = null;
		enckey = ToBytes(key);
		DESedeKeySpec desKeySpec = new DESedeKeySpec(enckey);
		SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DESede");
		secretKey = keyFactory.generateSecret(desKeySpec);

		// Create Cipher
		desCipher = Cipher.getInstance("DESede/ECB/PKCS5Padding");
		
		desCipher.init(Cipher.DECRYPT_MODE, secretKey);
		String clearText = new String(desCipher.doFinal(Base64.decode(cipherText)));
				
		return clearText;

	}

	private static byte[] ToBytes(String key) {
		byte[] unpackedResult = new byte[key.length()];
		for (int i = 0; i < unpackedResult.length; i++) {
			char c = key.charAt(i);
			if ((short) c < 65)
				unpackedResult[i] = (byte) ((short) c - 48);
			else
				unpackedResult[i] = (byte) ((short) c - 55);
		}

		if (unpackedResult.length == 48) {
			byte[] packedResult = new byte[unpackedResult.length / 2];
			for (int i = 0; i < unpackedResult.length; i++) {
				char c = key.charAt(i);
				if (i % 2 == 0)
					packedResult[i / 2] = (byte) (unpackedResult[i] << 4);
				else
					packedResult[i / 2] =
						(byte) (packedResult[i / 2] | (byte) unpackedResult[i]);
			}
			return packedResult;
		}

		return unpackedResult;

	}

}
