var mapping_atm = [
  {
    zipcode: 93030,
    title: 'RBS WorldPay',
    description: '201   E 4TH ST, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.14661,
    latitude: -119.19554
  },
  {
    zipcode: 93033,
    title: 'FIS',
    description: '541   W HUENEME RD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.1474,
    latitude: -119.18463
  },
  {
    zipcode: 93041,
    title: 'RBS WorldPay',
    description: '711   E PORT HUENEME RD, Port Hueneme, CA 93041',
    surcharge: true,
    longitude: 34.14759,
    latitude: -119.18974
  },
  {
    zipcode: 93041,
    title: 'WELLS FARGO BANK',
    description: '147   N VENTURA RD, Port Hueneme, CA 93041',
    surcharge: true,
    longitude: 34.14777,
    latitude: -119.19546
  },
  {
    zipcode: 91361,
    title: 'MONEYPASS',
    description: '32111    AGOURA RD, Westlake Village, CA 91361',
    surcharge: false,
    longitude: 34.14823,
    latitude: -118.81945
  },
  {
    zipcode: 93033,
    title: 'PULSE NETWORK',
    description: '5537    PERKINS RD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.14867,
    latitude: -119.18398
  },
  {
    zipcode: 91361,
    title: 'FIRST BANK',
    description: '2797    AGOURA RD, Westlake Village, CA 91361',
    surcharge: false,
    longitude: 34.15055,
    latitude: -118.82535
  },
  {
    zipcode: 91361,
    title: 'WELLS FARGO BANK',
    description: '2725    AGOURA RD, Westlake Village, CA 91361',
    surcharge: true,
    longitude: 34.15083,
    latitude: -118.82597
  },
  {
    zipcode: 91361,
    title: 'CARDTRONICS',
    description: '2791    AGOURA RD, Westlake Village, CA 91361',
    surcharge: true,
    longitude: 34.15083,
    latitude: -118.82597
  },
  {
    zipcode: 91361,
    title: 'COMERICA BANK',
    description: '2915    TOWNSGATE RD, Westlake Village, CA 91361',
    surcharge: false,
    longitude: 34.1517,
    latitude: -118.82185
  },
  {
    zipcode: 91362,
    title: 'RBS WorldPay',
    description: '2    DOLE DR, Thousand Oaks, CA 91362',
    surcharge: true,
    longitude: 34.15209,
    latitude: -118.80284
  },
  {
    zipcode: 91361,
    title: 'BANK OF AMERICA',
    description: '954   S WESTLAKE BLVD, Westlake Village, CA 91361',
    surcharge: false,
    longitude: 34.15319,
    latitude: -118.82825
  },
  {
    zipcode: 91361,
    title: 'BANK OF AMERICA',
    description: '954   S WESTLAKE BLVD, Westlake Village, CA 91361',
    surcharge: false,
    longitude: 34.15319,
    latitude: -118.82825
  },
  {
    zipcode: 91361,
    title: 'BANK OF AMERICA',
    description: '954   S WESTLAKE BLVD, Westlake Village, CA 91361',
    surcharge: false,
    longitude: 34.15319,
    latitude: -118.82825
  },
  {
    zipcode: 91361,
    title: 'BANK OF AMERICA',
    description: '954   S WESTLAKE BLVD, Westlake Village, CA 91361',
    surcharge: false,
    longitude: 34.15319,
    latitude: -118.82825
  },
  {
    zipcode: 91361,
    title: 'CITIBANK',
    description: '974   S WESTLAKE BLVD, Westlake Village, CA 91361',
    surcharge: false,
    longitude: 34.15319,
    latitude: -118.82825
  },
  {
    zipcode: 91361,
    title: 'CITIBANK',
    description: '974   S WESTLAKE BLVD, Westlake Village, CA 91361',
    surcharge: false,
    longitude: 34.15319,
    latitude: -118.82825
  },
  {
    zipcode: 91361,
    title: 'CHASE',
    description: '1014   S WESTLAKE BLVD, Westlake Village, CA 91361',
    surcharge: true,
    longitude: 34.1537,
    latitude: -118.82789
  },
  {
    zipcode: 91361,
    title: 'CHASE',
    description: '1014   S WESTLAKE BLVD, Westlake Village, CA 91361',
    surcharge: true,
    longitude: 34.1537,
    latitude: -118.82789
  },
  {
    zipcode: 91361,
    title: 'CHASE',
    description: '1014   S WESTLAKE BLVD, Westlake Village, CA 91361',
    surcharge: true,
    longitude: 34.1537,
    latitude: -118.82789
  },
  {
    zipcode: 91362,
    title: 'MONEYPASS',
    description: '5750    LINDERO CANYON RD, Thousand Oaks, CA 91362',
    surcharge: false,
    longitude: 34.15397,
    latitude: -118.79659
  },
  {
    zipcode: 91362,
    title: 'WELLS FARGO BANK',
    description: '5770    LINDERO CANYON RD, Thousand Oaks, CA 91362',
    surcharge: true,
    longitude: 34.15397,
    latitude: -118.79659
  },
  {
    zipcode: 91362,
    title: 'WELLS FARGO BANK',
    description: '5770    LINDERO CANYON RD, Thousand Oaks, CA 91362',
    surcharge: true,
    longitude: 34.15397,
    latitude: -118.79659
  },
  {
    zipcode: 91361,
    title: 'CHASE',
    description: '2734    TOWNSGATE RD, Westlake Village, CA 91361',
    surcharge: true,
    longitude: 34.15402,
    latitude: -118.82588
  },
  {
    zipcode: 93033,
    title: '1ST ISO PROCESSING',
    description: '400   W PLEASANT VALLEY RD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.15463,
    latitude: -119.18275
  },
  {
    zipcode: 93041,
    title: 'RBS WorldPay',
    description: '480   E PLEASANT VALLEY RD, Port Hueneme, CA 93041',
    surcharge: true,
    longitude: 34.15468,
    latitude: -119.19397
  },
  {
    zipcode: 93033,
    title: 'WELLS FARGO BANK',
    description: '133   W PLEASANT VALLEY RD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.15478,
    latitude: -119.17893
  },
  {
    zipcode: 93041,
    title: 'BANK OF AMERICA',
    description: '826   N VENTURA RD, Port Hueneme, CA 93041',
    surcharge: false,
    longitude: 34.15567,
    latitude: -119.19508
  },
  {
    zipcode: 93041,
    title: 'RBS WorldPay',
    description: '848   N VENTURA RD, Port Hueneme, CA 93041',
    surcharge: true,
    longitude: 34.15567,
    latitude: -119.19508
  },
  {
    zipcode: 91362,
    title: '1ST ISO PROCESSING',
    description: '30750    RUSSELL RANCH RD, Thousand Oaks, CA 91362',
    surcharge: true,
    longitude: 34.15608,
    latitude: -118.80386
  },
  {
    zipcode: 91361,
    title: 'MONEYPASS',
    description: '2663    TOWNSGATE RD, Westlake Village, CA 91361',
    surcharge: false,
    longitude: 34.15627,
    latitude: -118.82851
  },
  {
    zipcode: 91362,
    title: 'RABOBANK',
    description: '2663    TOWNSGATE RD, Thousand Oaks, CA 91362',
    surcharge: false,
    longitude: 34.15627,
    latitude: -118.82851
  },
  {
    zipcode: 93033,
    title: 'RBS WorldPay',
    description: '1790   E PLEASANT VALLEY RD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.15706,
    latitude: -119.16102
  },
  {
    zipcode: 91362,
    title: 'CITIBANK',
    description: '3967   E THOUSAND OAKS BLVD, Thousand Oaks, CA 91362',
    surcharge: false,
    longitude: 34.16125,
    latitude: -118.82339
  },
  {
    zipcode: 93033,
    title: 'CARDTRONICS',
    description: '2060   E PLEASANT VALLEY RD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.16126,
    latitude: -119.1524
  },
  {
    zipcode: 91362,
    title: 'WELLS FARGO BANK',
    description: '3965   E THOUSAND OAKS BLVD, Thousand Oaks, CA 91362',
    surcharge: true,
    longitude: 34.16127,
    latitude: -118.82342
  },
  {
    zipcode: 91362,
    title: 'WELLS FARGO BANK',
    description: '3965   E THOUSAND OAKS BLVD, Thousand Oaks, CA 91362',
    surcharge: true,
    longitude: 34.16127,
    latitude: -118.82342
  },
  {
    zipcode: 91362,
    title: 'WELLS FARGO BANK',
    description: '3965   E THOUSAND OAKS BLVD, Thousand Oaks, CA 91362',
    surcharge: true,
    longitude: 34.16127,
    latitude: -118.82342
  },
  {
    zipcode: 91362,
    title: 'UNION BANK',
    description: '3887   E THOUSAND OAKS BLVD, Thousand Oaks, CA 91362',
    surcharge: true,
    longitude: 34.16194,
    latitude: -118.82466
  },
  {
    zipcode: 91362,
    title: 'UNION BANK',
    description: '3887   E THOUSAND OAKS BLVD, Thousand Oaks, CA 91362',
    surcharge: true,
    longitude: 34.16194,
    latitude: -118.82466
  },
  {
    zipcode: 91362,
    title: 'CHASE',
    description: '3960   E THOUSAND OAKS BLVD, Thousand Oaks, CA 91362',
    surcharge: true,
    longitude: 34.16205,
    latitude: -118.82508
  },
  {
    zipcode: 91362,
    title: 'CHASE',
    description: '3960   E THOUSAND OAKS BLVD, Thousand Oaks, CA 91362',
    surcharge: true,
    longitude: 34.16205,
    latitude: -118.82508
  },
  {
    zipcode: 93033,
    title: 'CARDTRONICS',
    description: '4000   S ROSE AVE, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.16315,
    latitude: -119.15933
  },
  {
    zipcode: 91361,
    title: 'CARDTRONICS',
    description: '395    HAMPSHIRE RD, Westlake Village, CA 91361',
    surcharge: true,
    longitude: 34.1635,
    latitude: -118.83824
  },
  {
    zipcode: 91361,
    title: 'SWITCH COMMERCE INC.',
    description: '225    HAMPSHIRE RD, Westlake Village, CA 91361',
    surcharge: true,
    longitude: 34.1653,
    latitude: -118.83823
  },
  {
    zipcode: 91361,
    title: 'CHASE',
    description: '248    HAMPSHIRE RD, Westlake Village, CA 91361',
    surcharge: true,
    longitude: 34.1654,
    latitude: -118.83804
  },
  {
    zipcode: 93033,
    title: 'RBS WorldPay',
    description: '121   E YUCCA ST, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.16601,
    latitude: -119.17652
  },
  {
    zipcode: 93033,
    title: 'PULSE NETWORK',
    description: '3650    SAVIERS RD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.16662,
    latitude: -119.17753
  },
  {
    zipcode: 91362,
    title: 'RBS WorldPay',
    description: '11    HAMPSHIRE RD, Thousand Oaks, CA 91362',
    surcharge: true,
    longitude: 34.16715,
    latitude: -118.83732
  },
  {
    zipcode: 91320,
    title: 'MONEYPASS',
    description: '541   S REINO RD, Newbury Park, CA 91320',
    surcharge: false,
    longitude: 34.16773,
    latitude: -118.95642
  },
  {
    zipcode: 93033,
    title: 'CARDTRONICS',
    description: '3443    SAVIERS RD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.16812,
    latitude: -119.1777
  },
  {
    zipcode: 91320,
    title: 'CHASE',
    description: '461   S REINO RD, Newbury Park, CA 91320',
    surcharge: true,
    longitude: 34.16813,
    latitude: -118.95632
  },
  {
    zipcode: 93033,
    title: 'CARDTRONICS',
    description: '3280    SAVIERS RD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.16999,
    latitude: -119.1775
  },
  {
    zipcode: 91320,
    title: 'CHASE',
    description: '500   N VENTU PARK RD, Newbury Park, CA 91320',
    surcharge: true,
    longitude: 34.17003,
    latitude: -118.90548
  },
  {
    zipcode: 91320,
    title: 'CHASE',
    description: '500   N VENTU PARK RD, Newbury Park, CA 91320',
    surcharge: true,
    longitude: 34.17003,
    latitude: -118.90548
  },
  {
    zipcode: 91320,
    title: 'CHASE',
    description: '500   N VENTU PARK RD, Newbury Park, CA 91320',
    surcharge: true,
    longitude: 34.17003,
    latitude: -118.90548
  },
  {
    zipcode: 91320,
    title: 'PULSE NETWORK',
    description: '512   N VENTU PARK RD, Newbury Park, CA 91320',
    surcharge: true,
    longitude: 34.17003,
    latitude: -118.90548
  },
  {
    zipcode: 91320,
    title: 'CARDTRONICS',
    description: '550   N VENTU PARK RD, Newbury Park, CA 91320',
    surcharge: true,
    longitude: 34.17003,
    latitude: -118.90548
  },
  {
    zipcode: 93036,
    title: 'PULSE NETWORK',
    description: '2362   N OXNARD BLVD, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.17013,
    latitude: -119.15253
  },
  {
    zipcode: 93033,
    title: 'FIS',
    description: '3211    SAVIERS RD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.17018,
    latitude: -119.17768
  },
  {
    zipcode: 93033,
    title: 'FIS',
    description: '3003    SAVIERS RD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.17184,
    latitude: -119.17766
  },
  {
    zipcode: 93033,
    title: 'PULSE NETWORK',
    description: '3021    SAVIERS RD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.17184,
    latitude: -119.17766
  },
  {
    zipcode: 93033,
    title: 'RBS WorldPay',
    description: '2901    SAVIERS RD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.17286,
    latitude: -119.17765
  },
  {
    zipcode: 93033,
    title: 'CARDTRONICS',
    description: '2201   E CHANNEL ISLANDS BLVD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.17335,
    latitude: -119.14899
  },
  {
    zipcode: 93033,
    title: 'CITIBANK',
    description: '2900    SAVIERS RD, Oxnard, CA 93033',
    surcharge: false,
    longitude: 34.17337,
    latitude: -119.17745
  },
  {
    zipcode: 93033,
    title: 'CITIBANK',
    description: '2900    SAVIERS RD, Oxnard, CA 93033',
    surcharge: false,
    longitude: 34.17337,
    latitude: -119.17745
  },
  {
    zipcode: 93033,
    title: 'CITIBANK',
    description: '2900    SAVIERS RD, Oxnard, CA 93033',
    surcharge: false,
    longitude: 34.17337,
    latitude: -119.17745
  },
  {
    zipcode: 93033,
    title: 'WELLS FARGO BANK',
    description: '2831    SAVIERS RD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.17393,
    latitude: -119.17754
  },
  {
    zipcode: 93033,
    title: 'WELLS FARGO BANK',
    description: '2831    SAVIERS RD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.17393,
    latitude: -119.17754
  },
  {
    zipcode: 93033,
    title: 'WELLS FARGO BANK',
    description: '2831    SAVIERS RD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.17393,
    latitude: -119.17754
  },
  {
    zipcode: 93033,
    title: 'WELLS FARGO BANK',
    description: '2831    SAVIERS RD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.17393,
    latitude: -119.17754
  },
  {
    zipcode: 93033,
    title: 'PULSE NETWORK',
    description: '2800    SAVIERS RD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.17405,
    latitude: -119.17754
  },
  {
    zipcode: 93033,
    title: 'FIS',
    description: '2810   S VENTURA RD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.17416,
    latitude: -119.19496
  },
  {
    zipcode: 93033,
    title: 'PULSE NETWORK',
    description: '2701    SAVIERS RD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.17496,
    latitude: -119.17762
  },
  {
    zipcode: 93033,
    title: 'FIS',
    description: '2660   S VENTURA RD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.17524,
    latitude: -119.1949
  },
  {
    zipcode: 93033,
    title: 'FIS',
    description: '1420   W CHANNEL ISLANDS BLVD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.17556,
    latitude: -119.19389
  },
  {
    zipcode: 93033,
    title: 'RBS WorldPay',
    description: '1440   W CHANNEL ISLANDS BLVD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.17556,
    latitude: -119.19389
  },
  {
    zipcode: 93033,
    title: 'RBS WorldPay',
    description: '2612    SAVIERS RD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.17562,
    latitude: -119.17743
  },
  {
    zipcode: 93041,
    title: 'CITIBANK',
    description: '739   W CHANNEL ISLANDS BLVD, Port Hueneme, CA 93041',
    surcharge: false,
    longitude: 34.17579,
    latitude: -119.22118
  },
  {
    zipcode: 93041,
    title: 'CITIBANK',
    description: '739   W CHANNEL ISLANDS BLVD, Port Hueneme, CA 93041',
    surcharge: false,
    longitude: 34.17579,
    latitude: -119.22118
  },
  {
    zipcode: 93041,
    title: 'BANK OF AMERICA',
    description: '755   W CHANNEL ISLANDS BLVD, Port Hueneme, CA 93041',
    surcharge: false,
    longitude: 34.17579,
    latitude: -119.22118
  },
  {
    zipcode: 93041,
    title: 'BANK OF AMERICA',
    description: '755   W CHANNEL ISLANDS BLVD, Port Hueneme, CA 93041',
    surcharge: false,
    longitude: 34.17579,
    latitude: -119.22118
  },
  {
    zipcode: 93041,
    title: 'BANK OF AMERICA',
    description: '755   W CHANNEL ISLANDS BLVD, Port Hueneme, CA 93041',
    surcharge: false,
    longitude: 34.17579,
    latitude: -119.22118
  },
  {
    zipcode: 93035,
    title: 'RBS WorldPay',
    description: '2101    MANDALAY BEACH RD, Oxnard, CA 93035',
    surcharge: true,
    longitude: 34.17654,
    latitude: -119.23288
  },
  {
    zipcode: 93041,
    title: 'FIS',
    description: '2480    VICTORIA AVE, Port Hueneme, CA 93041',
    surcharge: true,
    longitude: 34.17668,
    latitude: -119.22141
  },
  {
    zipcode: 93041,
    title: 'RBS WorldPay',
    description: '2651   N VENTURA RD, Port Hueneme, CA 93041',
    surcharge: true,
    longitude: 34.17678,
    latitude: -119.19507
  },
  {
    zipcode: 93041,
    title: 'CARDTRONICS',
    description: '581   W CHANNEL ISLANDS BLVD, Port Hueneme, CA 93041',
    surcharge: true,
    longitude: 34.17712,
    latitude: -119.21007
  },
  {
    zipcode: 93041,
    title: 'UNION BANK',
    description: '583   W CHANNEL ISLANDS BLVD, Port Hueneme, CA 93041',
    surcharge: true,
    longitude: 34.17712,
    latitude: -119.21007
  },
  {
    zipcode: 93041,
    title: 'CHASE',
    description: '619   W CHANNEL ISLANDS BLVD, Port Hueneme, CA 93041',
    surcharge: true,
    longitude: 34.17712,
    latitude: -119.21007
  },
  {
    zipcode: 93041,
    title: 'CHASE',
    description: '619   W CHANNEL ISLANDS BLVD, Port Hueneme, CA 93041',
    surcharge: true,
    longitude: 34.17712,
    latitude: -119.21007
  },
  {
    zipcode: 93041,
    title: 'CHASE',
    description: '619   W CHANNEL ISLANDS BLVD, Port Hueneme, CA 93041',
    surcharge: true,
    longitude: 34.17712,
    latitude: -119.21007
  },
  {
    zipcode: 93041,
    title: 'CHASE',
    description: '619   W CHANNEL ISLANDS BLVD, Port Hueneme, CA 93041',
    surcharge: true,
    longitude: 34.17712,
    latitude: -119.21007
  },
  {
    zipcode: 93041,
    title: 'CHASE',
    description: '619   W CHANNEL ISLANDS BLVD, Port Hueneme, CA 93041',
    surcharge: true,
    longitude: 34.17712,
    latitude: -119.21007
  },
  {
    zipcode: 93041,
    title: 'CHASE',
    description: '619   W CHANNEL ISLANDS BLVD, Port Hueneme, CA 93041',
    surcharge: true,
    longitude: 34.17712,
    latitude: -119.21007
  },
  {
    zipcode: 93033,
    title: 'RBS WorldPay',
    description: '2401    SAVIERS RD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.17732,
    latitude: -119.17761
  },
  {
    zipcode: 93033,
    title: 'BANK OF AMERICA',
    description: '2475    SAVIERS RD, Oxnard, CA 93033',
    surcharge: false,
    longitude: 34.17732,
    latitude: -119.17761
  },
  {
    zipcode: 93033,
    title: 'BANK OF AMERICA',
    description: '2475    SAVIERS RD, Oxnard, CA 93033',
    surcharge: false,
    longitude: 34.17732,
    latitude: -119.17761
  },
  {
    zipcode: 93033,
    title: 'BANK OF AMERICA',
    description: '2475    SAVIERS RD, Oxnard, CA 93033',
    surcharge: false,
    longitude: 34.17732,
    latitude: -119.17761
  },
  {
    zipcode: 93033,
    title: 'BANK OF AMERICA',
    description: '2475    SAVIERS RD, Oxnard, CA 93033',
    surcharge: false,
    longitude: 34.17732,
    latitude: -119.17761
  },
  {
    zipcode: 93033,
    title: 'BANK OF AMERICA',
    description: '2475    SAVIERS RD, Oxnard, CA 93033',
    surcharge: false,
    longitude: 34.17732,
    latitude: -119.17761
  },
  {
    zipcode: 93033,
    title: 'BANK OF AMERICA',
    description: '2475    SAVIERS RD, Oxnard, CA 93033',
    surcharge: false,
    longitude: 34.17732,
    latitude: -119.17761
  },
  {
    zipcode: 93033,
    title: 'BANK OF AMERICA',
    description: '2475    SAVIERS RD, Oxnard, CA 93033',
    surcharge: false,
    longitude: 34.17732,
    latitude: -119.17761
  },
  {
    zipcode: 93041,
    title: 'RBS WorldPay',
    description: '2521   N VENTURA RD, Port Hueneme, CA 93041',
    surcharge: true,
    longitude: 34.17739,
    latitude: -119.19511
  },
  {
    zipcode: 93041,
    title: 'WELLS FARGO BANK',
    description: '533   W CHANNEL ISLANDS BLVD, Port Hueneme, CA 93041',
    surcharge: true,
    longitude: 34.17794,
    latitude: -119.21643
  },
  {
    zipcode: 93041,
    title: 'WELLS FARGO BANK',
    description: '533   W CHANNEL ISLANDS BLVD, Port Hueneme, CA 93041',
    surcharge: true,
    longitude: 34.17794,
    latitude: -119.21643
  },
  {
    zipcode: 91360,
    title: 'CITIBANK',
    description: '33 STE M N MOORPARK RD, Thousand Oaks, CA 91360',
    surcharge: false,
    longitude: 34.1781,
    latitude: -118.87648
  },
  {
    zipcode: 91362,
    title: 'BANK OF AMERICA',
    description: '1155    LINDERO CANYON RD, Thousand Oaks, CA 91362',
    surcharge: false,
    longitude: 34.17839,
    latitude: -118.78756
  },
  {
    zipcode: 91362,
    title: 'BANK OF AMERICA',
    description: '1155    LINDERO CANYON RD, Thousand Oaks, CA 91362',
    surcharge: false,
    longitude: 34.17839,
    latitude: -118.78756
  },
  {
    zipcode: 91360,
    title: 'CARDTRONICS',
    description: '60   N MOORPARK RD, Thousand Oaks, CA 91360',
    surcharge: true,
    longitude: 34.17844,
    latitude: -118.87627
  },
  {
    zipcode: 91360,
    title: 'UNION BANK',
    description: '33   W THOUSAND OAKS BLVD, Thousand Oaks, CA 91360',
    surcharge: true,
    longitude: 34.17885,
    latitude: -118.877
  },
  {
    zipcode: 91360,
    title: 'WELLS FARGO BANK',
    description: '140   E THOUSAND OAKS BLVD, Thousand Oaks, CA 91360',
    surcharge: true,
    longitude: 34.1789,
    latitude: -118.8759
  },
  {
    zipcode: 91360,
    title: 'WELLS FARGO BANK',
    description: '140   E THOUSAND OAKS BLVD, Thousand Oaks, CA 91360',
    surcharge: true,
    longitude: 34.1789,
    latitude: -118.8759
  },
  {
    zipcode: 91360,
    title: 'WELLS FARGO BANK',
    description: '140   E THOUSAND OAKS BLVD, Thousand Oaks, CA 91360',
    surcharge: true,
    longitude: 34.1789,
    latitude: -118.8759
  },
  {
    zipcode: 91360,
    title: 'CARDTRONICS',
    description: '172   N MOORPARK RD, Thousand Oaks, CA 91360',
    surcharge: true,
    longitude: 34.17961,
    latitude: -118.87618
  },
  {
    zipcode: 93033,
    title: 'CARDTRONICS',
    description: '2850   S ROSE AVE, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.18008,
    latitude: -119.15972
  },
  {
    zipcode: 93033,
    title: 'CARDTRONICS',
    description: '2851   S ROSE AVE, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.18008,
    latitude: -119.1599
  },
  {
    zipcode: 91360,
    title: 'CHASE',
    description: '148   W HILLCREST DR, Thousand Oaks, CA 91360',
    surcharge: true,
    longitude: 34.18044,
    latitude: -118.87993
  },
  {
    zipcode: 91360,
    title: 'CHASE',
    description: '148   W HILLCREST DR, Thousand Oaks, CA 91360',
    surcharge: true,
    longitude: 34.18044,
    latitude: -118.87993
  },
  {
    zipcode: 91360,
    title: 'CHASE',
    description: '148   W HILLCREST DR, Thousand Oaks, CA 91360',
    surcharge: true,
    longitude: 34.18044,
    latitude: -118.87993
  },
  {
    zipcode: 91360,
    title: 'BANK OF AMERICA',
    description: '152   W HILLCREST DR, Thousand Oaks, CA 91360',
    surcharge: false,
    longitude: 34.18058,
    latitude: -118.88056
  },
  {
    zipcode: 91360,
    title: 'BANK OF AMERICA',
    description: '152   W HILLCREST DR, Thousand Oaks, CA 91360',
    surcharge: false,
    longitude: 34.18058,
    latitude: -118.88056
  },
  {
    zipcode: 91360,
    title: 'BANK OF THE WEST',
    description: '180   N MOORPARK RD, Thousand Oaks, CA 91360',
    surcharge: false,
    longitude: 34.18122,
    latitude: -118.87587
  },
  {
    zipcode: 93035,
    title: 'CARDTRONICS',
    description: '1955    PATTERSON RD, Oxnard, CA 93035',
    surcharge: true,
    longitude: 34.18141,
    latitude: -119.20838
  },
  {
    zipcode: 91320,
    title: 'BANK OF AMERICA',
    description: '2345    BORCHARD RD, Newbury Park, CA 91320',
    surcharge: false,
    longitude: 34.18145,
    latitude: -118.92796
  },
  {
    zipcode: 91320,
    title: 'BANK OF AMERICA',
    description: '2345    BORCHARD RD, Newbury Park, CA 91320',
    surcharge: false,
    longitude: 34.18145,
    latitude: -118.92796
  },
  {
    zipcode: 91320,
    title: 'BANK OF AMERICA',
    description: '2345    BORCHARD RD, Newbury Park, CA 91320',
    surcharge: false,
    longitude: 34.18145,
    latitude: -118.92796
  },
  {
    zipcode: 91377,
    title: 'CARDTRONICS',
    description: '632    LINDERO CANYON RD, Oak Park, CA 91377',
    surcharge: true,
    longitude: 34.18163,
    latitude: -118.78658
  },
  {
    zipcode: 91320,
    title: 'CARDTRONICS',
    description: '2305    BORCHARD RD, Newbury Park, CA 91320',
    surcharge: true,
    longitude: 34.18188,
    latitude: -118.92746
  },
  {
    zipcode: 91320,
    title: 'CARDTRONICS',
    description: '123   N REINO RD, Newbury Park, CA 91320',
    surcharge: true,
    longitude: 34.18243,
    latitude: -118.95342
  },
  {
    zipcode: 91320,
    title: 'BANK OF AMERICA',
    description: '177   N REINO RD, Newbury Park, CA 91320',
    surcharge: false,
    longitude: 34.18243,
    latitude: -118.95342
  },
  {
    zipcode: 93033,
    title: 'RBS WorldPay',
    description: '1712    SAVIERS RD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.18253,
    latitude: -119.17737
  },
  {
    zipcode: 91377,
    title: 'WELLS FARGO BANK',
    description: '604    LINDERO CANYON RD, Oak Park, CA 91377',
    surcharge: true,
    longitude: 34.18269,
    latitude: -118.7864
  },
  {
    zipcode: 91377,
    title: 'WELLS FARGO BANK',
    description: '604    LINDERO CANYON RD, Oak Park, CA 91377',
    surcharge: true,
    longitude: 34.18269,
    latitude: -118.7864
  },
  {
    zipcode: 91377,
    title: 'WELLS FARGO BANK',
    description: '604    LINDERO CANYON RD, Oak Park, CA 91377',
    surcharge: true,
    longitude: 34.18269,
    latitude: -118.7864
  },
  {
    zipcode: 91320,
    title: 'CITIBANK',
    description: '2170    NEWBURY RD, Newbury Park, CA 91320',
    surcharge: false,
    longitude: 34.18291,
    latitude: -118.9249
  },
  {
    zipcode: 91320,
    title: 'CITIBANK',
    description: '2170    NEWBURY RD, Newbury Park, CA 91320',
    surcharge: false,
    longitude: 34.18291,
    latitude: -118.9249
  },
  {
    zipcode: 93035,
    title: 'FIS',
    description: '1601   S VICTORIA AVE, Oxnard, CA 93035',
    surcharge: true,
    longitude: 34.18343,
    latitude: -119.2214
  },
  {
    zipcode: 91360,
    title: 'BANK OF AMERICA',
    description: '222   W HILLCREST DR, Thousand Oaks, CA 91360',
    surcharge: false,
    longitude: 34.18348,
    latitude: -118.88452
  },
  {
    zipcode: 93030,
    title: 'PULSE NETWORK',
    description: '1500   S OXNARD BLVD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.18466,
    latitude: -119.1708
  },
  {
    zipcode: 91360,
    title: 'PULSE NETWORK',
    description: '467   N MOORPARK RD, Thousand Oaks, CA 91360',
    surcharge: true,
    longitude: 34.18494,
    latitude: -118.87525
  },
  {
    zipcode: 91360,
    title: 'CHASE',
    description: '350   W HILLCREST DR, Thousand Oaks, CA 91360',
    surcharge: true,
    longitude: 34.18495,
    latitude: -118.88569
  },
  {
    zipcode: 91360,
    title: 'RBS WorldPay',
    description: '350   W HILLCREST DR, Thousand Oaks, CA 91360',
    surcharge: true,
    longitude: 34.18495,
    latitude: -118.88569
  },
  {
    zipcode: 93030,
    title: 'PULSE NETWORK',
    description: '1400   S OXNARD BLVD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.18543,
    latitude: -119.17179
  },
  {
    zipcode: 91362,
    title: 'MONEYPASS',
    description: '1135    LINDERO CANYON RD, Thousand Oaks, CA 91362',
    surcharge: false,
    longitude: 34.18559,
    latitude: -118.79001
  },
  {
    zipcode: 93033,
    title: 'RBS WorldPay',
    description: '1309    SAVIERS RD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.18582,
    latitude: -119.17754
  },
  {
    zipcode: 91360,
    title: 'MONEYPASS',
    description: '550   N MOORPARK RD, Thousand Oaks, CA 91360',
    surcharge: false,
    longitude: 34.18605,
    latitude: -118.87484
  },
  {
    zipcode: 91360,
    title: 'CARDTRONICS',
    description: '50   E WILBUR RD, Thousand Oaks, CA 91360',
    surcharge: true,
    longitude: 34.18646,
    latitude: -118.87445
  },
  {
    zipcode: 91320,
    title: 'PULSE NETWORK',
    description: '2454   W HILLCREST DR, Newbury Park, CA 91320',
    surcharge: true,
    longitude: 34.18657,
    latitude: -118.93024
  },
  {
    zipcode: 91320,
    title: 'CARDTRONICS',
    description: '609    RANCHO CONEJO BLVD, Newbury Park, CA 91320',
    surcharge: true,
    longitude: 34.18703,
    latitude: -118.92515
  },
  {
    zipcode: 93033,
    title: 'PULSE NETWORK',
    description: '1271    SAVIERS RD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.18722,
    latitude: -119.17755
  },
  {
    zipcode: 93030,
    title: 'CARDTRONICS',
    description: '1205   S OXNARD BLVD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.18771,
    latitude: -119.17499
  },
  {
    zipcode: 91320,
    title: 'PULSE NETWORK',
    description: '575   N VENTU PARK RD, Newbury Park, CA 91320',
    surcharge: true,
    longitude: 34.1882,
    latitude: -118.91124
  },
  {
    zipcode: 91320,
    title: 'CARDTRONICS',
    description: '583   N VENTU PARK RD, Newbury Park, CA 91320',
    surcharge: true,
    longitude: 34.1882,
    latitude: -118.91124
  },
  {
    zipcode: 91320,
    title: 'FIS',
    description: '495   N VENTU PARK RD, Newbury Park, CA 91320',
    surcharge: true,
    longitude: 34.18824,
    latitude: -118.91125
  },
  {
    zipcode: 91320,
    title: 'RBS WorldPay',
    description: '445   N VENTU PARK RD, Newbury Park, CA 91320',
    surcharge: true,
    longitude: 34.18827,
    latitude: -118.91125
  },
  {
    zipcode: 91320,
    title: 'RBS WorldPay',
    description: '855   N WENDY DR, Newbury Park, CA 91320',
    surcharge: true,
    longitude: 34.18852,
    latitude: -118.94074
  },
  {
    zipcode: 93033,
    title: 'CARDTRONICS',
    description: '1110   S C ST, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.1891,
    latitude: -119.18111
  },
  {
    zipcode: 93030,
    title: 'CARDTRONICS',
    description: '1132   S OXNARD BLVD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.18975,
    latitude: -119.17719
  },
  {
    zipcode: 93030,
    title: 'FIS',
    description: '1133   S OXNARD BLVD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.18975,
    latitude: -119.1774
  },
  {
    zipcode: 93030,
    title: 'RBS WorldPay',
    description: '818   W WOOLEY RD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.1899,
    latitude: -119.18641
  },
  {
    zipcode: 93030,
    title: 'FIS',
    description: '834   W WOOLEY RD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.1899,
    latitude: -119.18658
  },
  {
    zipcode: 93030,
    title: 'CARDTRONICS',
    description: '1041   S OXNARD BLVD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.18993,
    latitude: -119.17751
  },
  {
    zipcode: 93030,
    title: 'RBS WorldPay',
    description: '1050   S A ST, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.19068,
    latitude: -119.17857
  },
  {
    zipcode: 93030,
    title: 'PULSE NETWORK',
    description: '1049   S VENTURA RD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.1911,
    latitude: -119.1949
  },
  {
    zipcode: 91320,
    title: 'WELLS FARGO BANK',
    description: '925    BROADBECK DR, Newbury Park, CA 91320',
    surcharge: true,
    longitude: 34.19121,
    latitude: -118.93656
  },
  {
    zipcode: 91320,
    title: 'WELLS FARGO BANK',
    description: '925    BROADBECK DR, Newbury Park, CA 91320',
    surcharge: true,
    longitude: 34.19121,
    latitude: -118.93656
  },
  {
    zipcode: 91320,
    title: 'WELLS FARGO BANK',
    description: '925    BROADBECK DR, Newbury Park, CA 91320',
    surcharge: true,
    longitude: 34.19121,
    latitude: -118.93656
  },
  {
    zipcode: 93035,
    title: 'RBS WorldPay',
    description: '1055    PATTERSON RD, Oxnard, CA 93035',
    surcharge: true,
    longitude: 34.19123,
    latitude: -119.20808
  },
  {
    zipcode: 91320,
    title: 'PULSE NETWORK',
    description: '2870    CAMINO DOS RIOS, Newbury Park, CA 91320',
    surcharge: true,
    longitude: 34.19239,
    latitude: -118.93648
  },
  {
    zipcode: 93030,
    title: 'PULSE NETWORK',
    description: '877   S VENTURA RD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.19264,
    latitude: -119.19479
  },
  {
    zipcode: 93030,
    title: '1ST ISO PROCESSING',
    description: '860   S A ST, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.19292,
    latitude: -119.17855
  },
  {
    zipcode: 93030,
    title: 'RBS WorldPay',
    description: '700   S OXNARD BLVD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.19386,
    latitude: -119.17732
  },
  {
    zipcode: 91360,
    title: 'CARDTRONICS',
    description: '1382   N MOORPARK RD, Thousand Oaks, CA 91360',
    surcharge: true,
    longitude: 34.19534,
    latitude: -118.87159
  },
  {
    zipcode: 93030,
    title: 'PULSE NETWORK',
    description: '601   S A ST, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.19568,
    latitude: -119.17867
  },
  {
    zipcode: 93030,
    title: 'PULSE NETWORK',
    description: '655   S VENTURA RD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.19572,
    latitude: -119.19484
  },
  {
    zipcode: 93030,
    title: 'FIS',
    description: '625   N OXNARD BLVD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.19602,
    latitude: -119.17747
  },
  {
    zipcode: 93030,
    title: 'CARDTRONICS',
    description: '501   S ROSE AVE, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.19611,
    latitude: -119.15986
  },
  {
    zipcode: 93030,
    title: 'CARDTRONICS',
    description: '501   S ROSE AVE, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.19611,
    latitude: -119.15986
  },
  {
    zipcode: 93035,
    title: 'CHASE',
    description: '1201   S VICTORIA AVE, Oxnard, CA 93035',
    surcharge: true,
    longitude: 34.19616,
    latitude: -119.21785
  },
  {
    zipcode: 93035,
    title: 'CHASE',
    description: '1201   S VICTORIA AVE, Oxnard, CA 93035',
    surcharge: true,
    longitude: 34.19616,
    latitude: -119.21785
  },
  {
    zipcode: 93035,
    title: 'CHASE',
    description: '1201   S VICTORIA AVE, Oxnard, CA 93035',
    surcharge: true,
    longitude: 34.19616,
    latitude: -119.21785
  },
  {
    zipcode: 93035,
    title: 'CHASE',
    description: '1201   S VICTORIA AVE, Oxnard, CA 93035',
    surcharge: true,
    longitude: 34.19616,
    latitude: -119.21785
  },
  {
    zipcode: 93035,
    title: 'MONEYPASS',
    description: '1291   S VICTORIA AVE, Oxnard, CA 93035',
    surcharge: false,
    longitude: 34.19616,
    latitude: -119.21785
  },
  {
    zipcode: 91360,
    title: 'BANK OF AMERICA',
    description: '1440   N MOORPARK RD, Thousand Oaks, CA 91360',
    surcharge: false,
    longitude: 34.1965,
    latitude: -118.87067
  },
  {
    zipcode: 91360,
    title: 'BANK OF AMERICA',
    description: '1440   N MOORPARK RD, Thousand Oaks, CA 91360',
    surcharge: false,
    longitude: 34.1965,
    latitude: -118.87067
  },
  {
    zipcode: 93030,
    title: 'CARDTRONICS',
    description: '551   S VENTURA RD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.19711,
    latitude: -119.19475
  },
  {
    zipcode: 93030,
    title: 'CARDTRONICS',
    description: '100   E 5TH ST, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.19756,
    latitude: -119.17719
  },
  {
    zipcode: 93030,
    title: 'RBS WorldPay',
    description: '154   E 5TH ST, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.19756,
    latitude: -119.1765
  },
  {
    zipcode: 93030,
    title: 'CARDTRONICS',
    description: '1501   W 5TH ST, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.19775,
    latitude: -119.19487
  },
  {
    zipcode: 93030,
    title: 'UNION BANK',
    description: '255   W 5TH ST, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.19775,
    latitude: -119.17912
  },
  {
    zipcode: 93030,
    title: 'CARDTRONICS',
    description: '481   S VENTURA RD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.19793,
    latitude: -119.19484
  },
  {
    zipcode: 93030,
    title: 'CARDTRONICS',
    description: '430   S OXNARD BLVD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.19834,
    latitude: -119.17726
  },
  {
    zipcode: 91360,
    title: 'MONEYPASS',
    description: '1500   N MOORPARK RD, Thousand Oaks, CA 91360',
    surcharge: false,
    longitude: 34.19849,
    latitude: -118.86906
  },
  {
    zipcode: 91360,
    title: 'WELLS FARGO BANK',
    description: '1596   N MOORPARK RD, Thousand Oaks, CA 91360',
    surcharge: true,
    longitude: 34.19849,
    latitude: -118.86906
  },
  {
    zipcode: 91360,
    title: 'WELLS FARGO BANK',
    description: '1596   N MOORPARK RD, Thousand Oaks, CA 91360',
    surcharge: true,
    longitude: 34.19849,
    latitude: -118.86906
  },
  {
    zipcode: 93030,
    title: 'WELLS FARGO BANK',
    description: '450   S VENTURA RD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.19856,
    latitude: -119.19465
  },
  {
    zipcode: 93030,
    title: 'WELLS FARGO BANK',
    description: '450   S VENTURA RD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.19856,
    latitude: -119.19465
  },
  {
    zipcode: 93030,
    title: 'BANK OF AMERICA',
    description: '401   S A ST, Oxnard, CA 93030',
    surcharge: false,
    longitude: 34.19898,
    latitude: -119.17865
  },
  {
    zipcode: 93030,
    title: 'FIS',
    description: '301   W 4TH ST, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.19899,
    latitude: -119.18014
  },
  {
    zipcode: 93030,
    title: 'FIS',
    description: '321   W 4TH ST, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.19909,
    latitude: -119.18058
  },
  {
    zipcode: 93030,
    title: 'FIS',
    description: '321   S C ST, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.20005,
    latitude: -119.18116
  },
  {
    zipcode: 91360,
    title: 'RBS WorldPay',
    description: '1640   N MOORPARK RD, Thousand Oaks, CA 91360',
    surcharge: true,
    longitude: 34.20073,
    latitude: -118.86811
  },
  {
    zipcode: 91360,
    title: 'CHASE',
    description: '1678   N MOORPARK RD, Thousand Oaks, CA 91360',
    surcharge: true,
    longitude: 34.20073,
    latitude: -118.86811
  },
  {
    zipcode: 91360,
    title: 'CHASE',
    description: '1678   N MOORPARK RD, Thousand Oaks, CA 91360',
    surcharge: true,
    longitude: 34.20073,
    latitude: -118.86811
  },
  {
    zipcode: 91360,
    title: 'MONEYPASS',
    description: '1790   N MOORPARK RD, Thousand Oaks, CA 91360',
    surcharge: false,
    longitude: 34.20132,
    latitude: -118.86819
  },
  {
    zipcode: 93030,
    title: 'RABOBANK',
    description: '155   S A ST, Oxnard, CA 93030',
    surcharge: false,
    longitude: 34.20222,
    latitude: -119.17862
  },
  {
    zipcode: 93030,
    title: 'CARDTRONICS',
    description: '105   S ROSE AVE, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.20255,
    latitude: -119.15973
  },
  {
    zipcode: 93030,
    title: 'CARDTRONICS',
    description: '624    COOPER RD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.20442,
    latitude: -119.1725
  },
  {
    zipcode: 93030,
    title: 'CARDTRONICS',
    description: '506    COOPER RD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.20443,
    latitude: -119.17358
  },
  {
    zipcode: 93030,
    title: 'RBS WorldPay',
    description: '300    COOPER RD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.20444,
    latitude: -119.17524
  },
  {
    zipcode: 93030,
    title: 'CARDTRONICS',
    description: '733    COOPER RD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.20459,
    latitude: -119.17143
  },
  {
    zipcode: 93030,
    title: 'PULSE NETWORK',
    description: '517    COOPER RD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.20461,
    latitude: -119.17358
  },
  {
    zipcode: 93030,
    title: 'CARDTRONICS',
    description: '310   N A ST, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.20521,
    latitude: -119.1784
  },
  {
    zipcode: 93030,
    title: 'PULSE NETWORK',
    description: '303   N OXNARD BLVD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.20589,
    latitude: -119.17736
  },
  {
    zipcode: 93030,
    title: 'CARDTRONICS',
    description: '438   E COLONIA RD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.20633,
    latitude: -119.17411
  },
  {
    zipcode: 93030,
    title: 'RBS WorldPay',
    description: '1454    DORIS AVE, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.20823,
    latitude: -119.19432
  },
  {
    zipcode: 93030,
    title: 'CARDTRONICS',
    description: '490   S VICTORIA AVE, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.20838,
    latitude: -119.22084
  },
  {
    zipcode: 93010,
    title: 'RBS WorldPay',
    description: '4509    PLEASANT VALLEY RD, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.21063,
    latitude: -119.00954
  },
  {
    zipcode: 93030,
    title: 'FIS',
    description: '902   N A ST, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.21072,
    latitude: -119.17835
  },
  {
    zipcode: 91362,
    title: 'BANK OF AMERICA',
    description: '2012   E AVENIDA DE LOS ARBOLES, Thousand Oaks, CA 91362',
    surcharge: false,
    longitude: 34.21114,
    latitude: -118.84233
  },
  {
    zipcode: 91362,
    title: 'BANK OF AMERICA',
    description: '2012   E AVENIDA DE LOS ARBOLES, Thousand Oaks, CA 91362',
    surcharge: false,
    longitude: 34.21114,
    latitude: -118.84233
  },
  {
    zipcode: 93030,
    title: 'CHASE',
    description: '860   N VENTURA RD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.21117,
    latitude: -119.19454
  },
  {
    zipcode: 93030,
    title: 'CHASE',
    description: '860   N VENTURA RD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.21117,
    latitude: -119.19454
  },
  {
    zipcode: 93030,
    title: 'CHASE',
    description: '860   N VENTURA RD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.21117,
    latitude: -119.19454
  },
  {
    zipcode: 93030,
    title: 'CHASE',
    description: '860   N VENTURA RD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.21117,
    latitude: -119.19454
  },
  {
    zipcode: 93030,
    title: 'CHASE',
    description: '860   N VENTURA RD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.21117,
    latitude: -119.19454
  },
  {
    zipcode: 91362,
    title: 'MONEYPASS',
    description: '2048   E AVENIDA DE LOS ARBOLES, Thousand Oaks, CA 91362',
    surcharge: false,
    longitude: 34.21118,
    latitude: -118.84187
  },
  {
    zipcode: 91362,
    title: 'CARDTRONICS',
    description: '2048   E AVENIDA DE LOS ARBOLES, Thousand Oaks, CA 91362',
    surcharge: false,
    longitude: 34.21118,
    latitude: -118.84187
  },
  {
    zipcode: 91362,
    title: 'CHASE',
    description: '2072   E AVENIDA DE LOS ARBOLES, Thousand Oaks, CA 91362',
    surcharge: true,
    longitude: 34.21123,
    latitude: -118.84156
  },
  {
    zipcode: 91362,
    title: 'CHASE',
    description: '2072   E AVENIDA DE LOS ARBOLES, Thousand Oaks, CA 91362',
    surcharge: true,
    longitude: 34.21123,
    latitude: -118.84156
  },
  {
    zipcode: 91362,
    title: 'WELLS FARGO BANK',
    description: '1760 STE C E AVENIDA DE LOS ARBOLES, Thousand Oaks, CA 91362',
    surcharge: true,
    longitude: 34.21129,
    latitude: -118.84567
  },
  {
    zipcode: 91362,
    title: 'WELLS FARGO BANK',
    description: '1760 STE C E AVENIDA DE LOS ARBOLES, Thousand Oaks, CA 91362',
    surcharge: true,
    longitude: 34.21129,
    latitude: -118.84567
  },
  {
    zipcode: 93030,
    title: 'CARDTRONICS',
    description: '1801   N ROSE AVE, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.21175,
    latitude: -119.1454
  },
  {
    zipcode: 93012,
    title: 'RBS WorldPay',
    description: '4735    PLEASANT VALLEY RD, Camarillo, CA 93012',
    surcharge: true,
    longitude: 34.21183,
    latitude: -119.00893
  },
  {
    zipcode: 93030,
    title: 'BANK OF AMERICA',
    description: '920   N VENTURA RD, Oxnard, CA 93030',
    surcharge: false,
    longitude: 34.21205,
    latitude: -119.19452
  },
  {
    zipcode: 93030,
    title: 'BANK OF AMERICA',
    description: '920   N VENTURA RD, Oxnard, CA 93030',
    surcharge: false,
    longitude: 34.21205,
    latitude: -119.19452
  },
  {
    zipcode: 93030,
    title: 'BANK OF AMERICA',
    description: '1855   N OXNARD BLVD, Oxnard, CA 93030',
    surcharge: false,
    longitude: 34.21335,
    latitude: -119.18187
  },
  {
    zipcode: 93030,
    title: 'BANK OF AMERICA',
    description: '1855   N OXNARD BLVD, Oxnard, CA 93030',
    surcharge: false,
    longitude: 34.21335,
    latitude: -119.18187
  },
  {
    zipcode: 93030,
    title: 'BANK OF AMERICA',
    description: '1855   N OXNARD BLVD, Oxnard, CA 93030',
    surcharge: false,
    longitude: 34.21335,
    latitude: -119.18187
  },
  {
    zipcode: 93030,
    title: 'BANK OF AMERICA',
    description: '1855   N OXNARD BLVD, Oxnard, CA 93030',
    surcharge: false,
    longitude: 34.21335,
    latitude: -119.18187
  },
  {
    zipcode: 93012,
    title: 'CARDTRONICS',
    description: '2911    PETIT ST, Camarillo, CA 93012',
    surcharge: true,
    longitude: 34.21497,
    latitude: -119.02907
  },
  {
    zipcode: 93036,
    title: 'MONEYPASS',
    description: '2385   N OXNARD BLVD, Oxnard, CA 93036',
    surcharge: false,
    longitude: 34.21603,
    latitude: -119.1739
  },
  {
    zipcode: 93010,
    title: '1ST ISO PROCESSING',
    description: '2616    VENTURA BLVD, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.21608,
    latitude: -119.03565
  },
  {
    zipcode: 93030,
    title: 'PULSE NETWORK',
    description: '1600   N ROSE AVE, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.21636,
    latitude: -119.15833
  },
  {
    zipcode: 93010,
    title: 'MONEYPASS',
    description: '2245B    VENTURA BLVD, Camarillo, CA 93010',
    surcharge: false,
    longitude: 34.21663,
    latitude: -119.03933
  },
  {
    zipcode: 93010,
    title: 'PULSE NETWORK',
    description: '100   S LAS POSAS RD, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.21674,
    latitude: -119.06964
  },
  {
    zipcode: 93012,
    title: 'CARDTRONICS',
    description: '4870    SANTA ROSA RD, Camarillo, CA 93012',
    surcharge: true,
    longitude: 34.21698,
    latitude: -119.00598
  },
  {
    zipcode: 93010,
    title: 'RBS WorldPay',
    description: '1904    VENTURA BLVD, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.21702,
    latitude: -119.04468
  },
  {
    zipcode: 93010,
    title: '1ST ISO PROCESSING',
    description: '1604    VENTURA BLVD, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.2172,
    latitude: -119.04861
  },
  {
    zipcode: 93036,
    title: 'RBS WorldPay',
    description: '2786    SEAGLASS WAY, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.2172,
    latitude: -119.16134
  },
  {
    zipcode: 93036,
    title: 'CARDTRONICS',
    description: '2850   N OXNARD BLVD, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.2172,
    latitude: -119.16134
  },
  {
    zipcode: 93010,
    title: 'MONEYPASS',
    description: '1727 STE A E DAILY DR, Camarillo, CA 93010',
    surcharge: false,
    longitude: 34.21794,
    latitude: -119.04745
  },
  {
    zipcode: 93010,
    title: 'CARDTRONICS',
    description: '740    VENTURA BLVD, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.21799,
    latitude: -119.06119
  },
  {
    zipcode: 93010,
    title: 'SWITCH COMMERCE INC.',
    description: '740    VENTURA BLVD, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.21799,
    latitude: -119.06119
  },
  {
    zipcode: 93036,
    title: 'WELLS FARGO BANK',
    description: '1700   E GONZALES RD, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.21881,
    latitude: -119.15904
  },
  {
    zipcode: 93036,
    title: 'WELLS FARGO BANK',
    description: '1700   E GONZALES RD, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.21881,
    latitude: -119.15904
  },
  {
    zipcode: 93036,
    title: 'WELLS FARGO BANK',
    description: '1700   E GONZALES RD, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.21881,
    latitude: -119.15904
  },
  {
    zipcode: 93036,
    title: 'RBS WorldPay',
    description: '1901   N ROSE AVE, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.21889,
    latitude: -119.15838
  },
  {
    zipcode: 93030,
    title: 'PULSE NETWORK',
    description: '1860   N VENTURA RD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.21901,
    latitude: -119.19454
  },
  {
    zipcode: 93030,
    title: 'CARDTRONICS',
    description: '1861   N VENTURA RD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.21901,
    latitude: -119.19454
  },
  {
    zipcode: 93010,
    title: 'RBS WorldPay',
    description: '255    ARNEILL RD, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.21901,
    latitude: -119.03916
  },
  {
    zipcode: 93036,
    title: 'MONEYPASS',
    description: '2400   E GONZALES RD, Oxnard, CA 93036',
    surcharge: false,
    longitude: 34.21923,
    latitude: -119.20053
  },
  {
    zipcode: 93036,
    title: 'RBS WorldPay',
    description: '1501 # R W GONZALES RD, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.21934,
    latitude: -119.19418
  },
  {
    zipcode: 93010,
    title: 'PULSE NETWORK',
    description: '305    ARNEILL RD, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.21956,
    latitude: -119.03916
  },
  {
    zipcode: 93030,
    title: 'FIS',
    description: '2323 BLDG  N OXNARD BLVD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.21957,
    latitude: -119.17713
  },
  {
    zipcode: 93036,
    title: 'CARDTRONICS',
    description: '1911   N OXNARD BLVD, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.21979,
    latitude: -119.18464
  },
  {
    zipcode: 93010,
    title: 'CARDTRONICS',
    description: '255    CARMEN DR, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.21984,
    latitude: -119.05078
  },
  {
    zipcode: 93012,
    title: 'UNION BANK',
    description: '4646    ADOLFO RD, Camarillo, CA 93012',
    surcharge: true,
    longitude: 34.21984,
    latitude: -119.00692
  },
  {
    zipcode: 93010,
    title: 'PULSE NETWORK',
    description: '166   N AVIADOR ST, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.22017,
    latitude: -119.09387
  },
  {
    zipcode: 93030,
    title: 'RBS WorldPay',
    description: '200    DEL NORTE BLVD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.22018,
    latitude: -119.12677
  },
  {
    zipcode: 93010,
    title: 'RBS WorldPay',
    description: '305    CARMEN DR, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.22035,
    latitude: -119.05076
  },
  {
    zipcode: 93030,
    title: 'CARDTRONICS',
    description: '1954   N VENTURA RD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.22038,
    latitude: -119.19457
  },
  {
    zipcode: 93033,
    title: 'CARDTRONICS',
    description: '1900   N ROSE AVE, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.22057,
    latitude: -119.15818
  },
  {
    zipcode: 93036,
    title: 'CHASE',
    description: '1950   N ROSE AVE, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.22057,
    latitude: -119.15818
  },
  {
    zipcode: 93036,
    title: 'CHASE',
    description: '1950   N ROSE AVE, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.22057,
    latitude: -119.15818
  },
  {
    zipcode: 93036,
    title: 'CHASE',
    description: '1950   N ROSE AVE, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.22057,
    latitude: -119.15818
  },
  {
    zipcode: 93036,
    title: 'CHASE',
    description: '1950   N ROSE AVE, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.22057,
    latitude: -119.15818
  },
  {
    zipcode: 93036,
    title: 'CHASE',
    description: '1950   N ROSE AVE, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.22057,
    latitude: -119.15818
  },
  {
    zipcode: 93010,
    title: 'CARDTRONICS',
    description: '351B    CARMEN DR, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.22068,
    latitude: -119.05076
  },
  {
    zipcode: 93010,
    title: 'RBS WorldPay',
    description: '107   W VENTURA BLVD, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.22087,
    latitude: -119.10182
  },
  {
    zipcode: 93010,
    title: 'MONEYPASS',
    description: '1150    PASEO CAMARILLO, Camarillo, CA 93010',
    surcharge: false,
    longitude: 34.22088,
    latitude: -119.05468
  },
  {
    zipcode: 93010,
    title: 'CARDTRONICS',
    description: '209   W VENTURA BLVD, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.22101,
    latitude: -119.10104
  },
  {
    zipcode: 93010,
    title: 'PULSE NETWORK',
    description: '275   W VENTURA BLVD, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.22101,
    latitude: -119.10104
  },
  {
    zipcode: 93036,
    title: 'PULSE NETWORK',
    description: '2001   N ROSE AVE, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.22106,
    latitude: -119.15836
  },
  {
    zipcode: 93010,
    title: 'WELLS FARGO BANK',
    description: '487    CARMEN DR, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.22162,
    latitude: -119.05067
  },
  {
    zipcode: 93010,
    title: 'WELLS FARGO BANK',
    description: '487    CARMEN DR, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.22162,
    latitude: -119.05067
  },
  {
    zipcode: 93010,
    title: 'WELLS FARGO BANK',
    description: '487    CARMEN DR, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.22162,
    latitude: -119.05067
  },
  {
    zipcode: 93010,
    title: 'CITIBANK',
    description: '430    ARNEILL RD, Camarillo, CA 93010',
    surcharge: false,
    longitude: 34.22164,
    latitude: -119.03897
  },
  {
    zipcode: 93010,
    title: 'RABOBANK',
    description: '470    ARNEILL RD, Camarillo, CA 93010',
    surcharge: false,
    longitude: 34.22164,
    latitude: -119.03897
  },
  {
    zipcode: 93012,
    title: 'WELLS FARGO BANK',
    description: '5000    SANTA ROSA RD, Camarillo, CA 93012',
    surcharge: true,
    longitude: 34.22187,
    latitude: -119.00024
  },
  {
    zipcode: 93012,
    title: 'WELLS FARGO BANK',
    description: '5000    SANTA ROSA RD, Camarillo, CA 93012',
    surcharge: true,
    longitude: 34.22187,
    latitude: -119.00024
  },
  {
    zipcode: 93010,
    title: 'CHASE',
    description: '502    LAS POSAS RD, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.22216,
    latitude: -119.06967
  },
  {
    zipcode: 93010,
    title: 'CHASE',
    description: '502    LAS POSAS RD, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.22216,
    latitude: -119.06967
  },
  {
    zipcode: 93010,
    title: 'CHASE',
    description: '502    LAS POSAS RD, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.22216,
    latitude: -119.06967
  },
  {
    zipcode: 93010,
    title: 'CHASE',
    description: '502    LAS POSAS RD, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.22216,
    latitude: -119.06967
  },
  {
    zipcode: 93010,
    title: 'RBS WorldPay',
    description: '522    LAS POSAS RD, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.22216,
    latitude: -119.06967
  },
  {
    zipcode: 93030,
    title: 'CARDTRONICS',
    description: '2691   E VENTURA BLVD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.2227,
    latitude: -119.13828
  },
  {
    zipcode: 93030,
    title: 'CARDTRONICS',
    description: '2200   N ROSE AVE, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.22337,
    latitude: -119.15853
  },
  {
    zipcode: 93010,
    title: 'CHASE',
    description: '2300   E PONDEROSA DR, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.22343,
    latitude: -119.03904
  },
  {
    zipcode: 93010,
    title: 'CHASE',
    description: '2300   E PONDEROSA DR, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.22343,
    latitude: -119.03904
  },
  {
    zipcode: 93010,
    title: 'CHASE',
    description: '2300   E PONDEROSA DR, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.22343,
    latitude: -119.03904
  },
  {
    zipcode: 93010,
    title: 'UNION BANK',
    description: '2310   E PONDEROSA DR, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.22343,
    latitude: -119.03893
  },
  {
    zipcode: 93010,
    title: 'RBS WorldPay',
    description: '4418    CENTRAL AVE, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.22348,
    latitude: -119.10313
  },
  {
    zipcode: 93010,
    title: 'BANK OF AMERICA',
    description: '2400   E PONDEROSA DR, Camarillo, CA 93010',
    surcharge: false,
    longitude: 34.22351,
    latitude: -119.03787
  },
  {
    zipcode: 93010,
    title: 'BANK OF AMERICA',
    description: '2400   E PONDEROSA DR, Camarillo, CA 93010',
    surcharge: false,
    longitude: 34.22351,
    latitude: -119.03787
  },
  {
    zipcode: 93010,
    title: 'BANK OF AMERICA',
    description: '2400   E PONDEROSA DR, Camarillo, CA 93010',
    surcharge: false,
    longitude: 34.22351,
    latitude: -119.03787
  },
  {
    zipcode: 93010,
    title: 'WELLS FARGO BANK',
    description: '11   E PONDEROSA DR, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.22357,
    latitude: -119.06968
  },
  {
    zipcode: 93010,
    title: 'WELLS FARGO BANK',
    description: '11   E PONDEROSA DR, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.22357,
    latitude: -119.06968
  },
  {
    zipcode: 93036,
    title: 'RBS WorldPay',
    description: '2101   N ROSE AVE, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.22373,
    latitude: -119.15869
  },
  {
    zipcode: 93036,
    title: 'WESCOM CU',
    description: '1861   E VENTURA BLVD, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.22399,
    latitude: -119.15197
  },
  {
    zipcode: 93036,
    title: 'PULSE NETWORK',
    description: '2401   N ROSE AVE, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.22402,
    latitude: -119.15876
  },
  {
    zipcode: 93036,
    title: 'RBS WorldPay',
    description: '2300   N ROSE AVE, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.22455,
    latitude: -119.15865
  },
  {
    zipcode: 93010,
    title: 'CARDTRONICS',
    description: '760    ARNEILL RD, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.22495,
    latitude: -119.03897
  },
  {
    zipcode: 93036,
    title: 'RBS WorldPay',
    description: '2460    AUTO CENTER DR, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.22508,
    latitude: -119.14219
  },
  {
    zipcode: 93012,
    title: 'BANK OF AMERICA',
    description: '5800    SANTA ROSA RD, Camarillo, CA 93012',
    surcharge: false,
    longitude: 34.22531,
    latitude: -118.98978
  },
  {
    zipcode: 93010,
    title: 'MONEYPASS',
    description: '820    ARNEILL RD, Camarillo, CA 93010',
    surcharge: false,
    longitude: 34.22595,
    latitude: -119.03898
  },
  {
    zipcode: 93010,
    title: 'WELLS FARGO BANK',
    description: '824    ARNEILL RD, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.22595,
    latitude: -119.03898
  },
  {
    zipcode: 93010,
    title: 'WELLS FARGO BANK',
    description: '824    ARNEILL RD, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.22595,
    latitude: -119.03898
  },
  {
    zipcode: 91360,
    title: 'CARDTRONICS',
    description: '3505   N MOORPARK RD, Thousand Oaks, CA 91360',
    surcharge: true,
    longitude: 34.22722,
    latitude: -118.86942
  },
  {
    zipcode: 93012,
    title: 'CARDTRONICS',
    description: '5259    MISSION OAKS BLVD, Camarillo, CA 93012',
    surcharge: true,
    longitude: 34.22847,
    latitude: -118.99792
  },
  {
    zipcode: 93012,
    title: 'WELLS FARGO BANK',
    description: '5275    MISSION OAKS BLVD, Camarillo, CA 93012',
    surcharge: true,
    longitude: 34.22847,
    latitude: -118.99792
  },
  {
    zipcode: 93012,
    title: 'CHASE',
    description: '5291    MISSION OAKS BLVD, Camarillo, CA 93012',
    surcharge: true,
    longitude: 34.22867,
    latitude: -118.99738
  },
  {
    zipcode: 93036,
    title: 'PULSE NETWORK',
    description: '421   W ESPLANADE DR, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.22948,
    latitude: -119.1734
  },
  {
    zipcode: 93036,
    title: 'WELLS FARGO BANK',
    description: '460   E ESPLANADE DR, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.22963,
    latitude: -119.17298
  },
  {
    zipcode: 93036,
    title: 'WELLS FARGO BANK',
    description: '460   E ESPLANADE DR, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.22963,
    latitude: -119.17298
  },
  {
    zipcode: 93036,
    title: 'WELLS FARGO BANK',
    description: '460   E ESPLANADE DR, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.22963,
    latitude: -119.17298
  },
  {
    zipcode: 93030,
    title: 'UNION BANK',
    description: '400   E ESPLANADE DR, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.22964,
    latitude: -119.17364
  },
  {
    zipcode: 93036,
    title: 'CHASE',
    description: '350   E ESPLANADE DR, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.22974,
    latitude: -119.17418
  },
  {
    zipcode: 93036,
    title: 'CHASE',
    description: '350   E ESPLANADE DR, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.22974,
    latitude: -119.17418
  },
  {
    zipcode: 93036,
    title: 'CHASE',
    description: '350   E ESPLANADE DR, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.22974,
    latitude: -119.17418
  },
  {
    zipcode: 93030,
    title: 'RABOBANK',
    description: '300 STE 101 E ESPLANADE DR, Oxnard, CA 93030',
    surcharge: false,
    longitude: 34.23007,
    latitude: -119.1746
  },
  {
    zipcode: 93030,
    title: 'RBS WorldPay',
    description: '2575   E VINEYARD AVE, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.2307,
    latitude: -119.1742
  },
  {
    zipcode: 93036,
    title: 'RBS WorldPay',
    description: '2585   E VINEYARD AVE, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.2307,
    latitude: -119.1742
  },
  {
    zipcode: 93012,
    title: 'PULSE NETWORK',
    description: '4007    ADOLFO RD, Camarillo, CA 93012',
    surcharge: true,
    longitude: 34.23087,
    latitude: -119.01895
  },
  {
    zipcode: 93036,
    title: 'BANK OF THE WEST',
    description: '371   W ESPLANADE DR, Oxnard, CA 93036',
    surcharge: false,
    longitude: 34.2312,
    latitude: -119.17506
  },
  {
    zipcode: 93036,
    title: 'CARDTRONICS',
    description: '150   W ESPLANADE DR, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.23123,
    latitude: -119.17533
  },
  {
    zipcode: 93030,
    title: 'CARDTRONICS',
    description: '2001   E VENTURA BLVD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.23277,
    latitude: -119.15705
  },
  {
    zipcode: 93036,
    title: 'BANK OF AMERICA',
    description: '670    TOWN CENTER DR, Oxnard, CA 93036',
    surcharge: false,
    longitude: 34.23489,
    latitude: -119.18094
  },
  {
    zipcode: 93036,
    title: 'BANK OF AMERICA',
    description: '670    TOWN CENTER DR, Oxnard, CA 93036',
    surcharge: false,
    longitude: 34.23489,
    latitude: -119.18094
  },
  {
    zipcode: 93036,
    title: 'BANK OF AMERICA',
    description: '670    TOWN CENTER DR, Oxnard, CA 93036',
    surcharge: false,
    longitude: 34.23489,
    latitude: -119.18094
  },
  {
    zipcode: 93030,
    title: 'FIS',
    description: '2778   E VINEYARD AVE, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.23643,
    latitude: -119.16971
  },
  {
    zipcode: 93036,
    title: 'RBS WorldPay',
    description: '2765   E VINEYARD AVE, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.23664,
    latitude: -119.16977
  },
  {
    zipcode: 93010,
    title: 'BANK OF AMERICA',
    description: '2400    LAS POSAS RD, Camarillo, CA 93010',
    surcharge: false,
    longitude: 34.23671,
    latitude: -119.03776
  },
  {
    zipcode: 93010,
    title: 'CHASE',
    description: '2510    LAS POSAS RD, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.23683,
    latitude: -119.03727
  },
  {
    zipcode: 93010,
    title: 'CHASE',
    description: '2510    LAS POSAS RD, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.23683,
    latitude: -119.03727
  },
  {
    zipcode: 93010,
    title: 'CHASE',
    description: '2510    LAS POSAS RD, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.23683,
    latitude: -119.03727
  },
  {
    zipcode: 93010,
    title: 'FIS',
    description: '2550    LAS POSAS RD, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.23691,
    latitude: -119.03693
  },
  {
    zipcode: 93036,
    title: 'PULSE NETWORK',
    description: '2851   E VINEYARD AVE, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.2378,
    latitude: -119.1689
  },
  {
    zipcode: 93036,
    title: 'RBS WorldPay',
    description: '3380   E VINEYARD AVE, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.24316,
    latitude: -119.16462
  },
  {
    zipcode: 93036,
    title: 'PULSE NETWORK',
    description: '3402   E VINEYARD AVE, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.24343,
    latitude: -119.16442
  },
  {
    zipcode: 93003,
    title: 'SWITCH COMMERCE INC.',
    description: '2757    JOHNSON DR, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.2502,
    latitude: -119.19652
  },
  {
    zipcode: 93003,
    title: 'CARDTRONICS',
    description: '5669    VALENTINE RD, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.25131,
    latitude: -119.21115
  },
  {
    zipcode: 93065,
    title: 'UNION BANK',
    description: '501    COUNTRY CLUB DR, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.25246,
    latitude: -118.81295
  },
  {
    zipcode: 93065,
    title: 'UNION BANK',
    description: '501    COUNTRY CLUB DR, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.25246,
    latitude: -118.81295
  },
  {
    zipcode: 93003,
    title: 'CARDTRONICS',
    description: '6320    BRISTOL RD, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.25343,
    latitude: -119.20408
  },
  {
    zipcode: 93003,
    title: '1ST ISO PROCESSING',
    description: '2440   S VICTORIA AVE, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.25395,
    latitude: -119.21022
  },
  {
    zipcode: 93003,
    title: 'RBS WorldPay',
    description: '2199   S VICTORIA AVE, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.25491,
    latitude: -119.21021
  },
  {
    zipcode: 93003,
    title: 'PULSE NETWORK',
    description: '5555    WALKER ST, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.25534,
    latitude: -119.21493
  },
  {
    zipcode: 93003,
    title: 'CHASE',
    description: '2075   S VICTORIA AVE, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.25546,
    latitude: -119.21042
  },
  {
    zipcode: 93003,
    title: 'CHASE',
    description: '2075   S VICTORIA AVE, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.25546,
    latitude: -119.21042
  },
  {
    zipcode: 93003,
    title: 'CHASE',
    description: '2075   S VICTORIA AVE, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.25546,
    latitude: -119.21042
  },
  {
    zipcode: 93003,
    title: 'ELAN',
    description: '1788    MESA VERDE AVE, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.25661,
    latitude: -119.21653
  },
  {
    zipcode: 93003,
    title: 'SWITCH COMMERCE INC.',
    description: '4411    MARKET ST, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.25712,
    latitude: -119.23295
  },
  {
    zipcode: 93003,
    title: 'CARDTRONICS',
    description: '1740   S VICTORIA AVE, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.25826,
    latitude: -119.21084
  },
  {
    zipcode: 93003,
    title: 'MONEYPASS',
    description: '1776   S VICTORIA AVE, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.25826,
    latitude: -119.21084
  },
  {
    zipcode: 93003,
    title: 'PULSE NETWORK',
    description: '1739   S VICTORIA AVE, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.25969,
    latitude: -119.21132
  },
  {
    zipcode: 93065,
    title: 'CARDTRONICS',
    description: '2543    ROYAL AVE, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.26093,
    latitude: -118.74734
  },
  {
    zipcode: 93001,
    title: 'CHASE',
    description: '2499    HARBOR BLVD, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.26252,
    latitude: -119.26603
  },
  {
    zipcode: 93001,
    title: 'CHASE',
    description: '2499    HARBOR BLVD, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.26252,
    latitude: -119.26603
  },
  {
    zipcode: 93003,
    title: 'MONEYPASS',
    description: '4360   E MAIN ST, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.26264,
    latitude: -119.23539
  },
  {
    zipcode: 93065,
    title: 'WESCOM CU',
    description: '1268    MADERA RD, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.26281,
    latitude: -118.79618
  },
  {
    zipcode: 93003,
    title: 'MONEYPASS',
    description: '4050 STE A1 E MAIN ST, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.26298,
    latitude: -119.23732
  },
  {
    zipcode: 93001,
    title: 'WELLS FARGO BANK',
    description: '2433    HARBOR BLVD, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.26302,
    latitude: -119.2673
  },
  {
    zipcode: 93001,
    title: 'RBS WorldPay',
    description: '2433    HARBOR BLVD, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.26302,
    latitude: -119.2673
  },
  {
    zipcode: 93001,
    title: 'RBS WorldPay',
    description: '2445    HARBOR BLVD, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.26302,
    latitude: -119.2673
  },
  {
    zipcode: 93003,
    title: 'RABOBANK',
    description: '1171   S VICTORIA AVE, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.26305,
    latitude: -119.21206
  },
  {
    zipcode: 93003,
    title: 'CARDTRONICS',
    description: '1121   S VICTORIA AVE, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.26314,
    latitude: -119.21207
  },
  {
    zipcode: 93001,
    title: 'BANK OF AMERICA',
    description: '4750    TELEPHONE RD, Ventura, CA 93001',
    surcharge: false,
    longitude: 34.2632,
    latitude: -119.22677
  },
  {
    zipcode: 93065,
    title: 'RBS WorldPay',
    description: '1356    ERRINGER RD, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.26321,
    latitude: -118.76127
  },
  {
    zipcode: 93003,
    title: 'WELLS FARGO BANK',
    description: '4731 STE 2  TELEPHONE RD, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.26324,
    latitude: -119.22774
  },
  {
    zipcode: 93065,
    title: 'CARDTRONICS',
    description: '1369    ERRINGER RD, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.26334,
    latitude: -118.76145
  },
  {
    zipcode: 93003,
    title: 'CARDTRONICS',
    description: '4200   E MAIN ST, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.26334,
    latitude: -119.23937
  },
  {
    zipcode: 93021,
    title: 'BANK OF AMERICA',
    description: '4225 STE B  TIERRA REJADA RD, Moorpark, CA 93021',
    surcharge: false,
    longitude: 34.26344,
    latitude: -118.87773
  },
  {
    zipcode: 93065,
    title: 'CHASE',
    description: '1324    MADERA RD, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.26384,
    latitude: -118.79619
  },
  {
    zipcode: 93065,
    title: 'CHASE',
    description: '1324    MADERA RD, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.26384,
    latitude: -118.79619
  },
  {
    zipcode: 93065,
    title: 'CHASE',
    description: '1324    MADERA RD, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.26384,
    latitude: -118.79619
  },
  {
    zipcode: 93001,
    title: 'CARDTRONICS',
    description: '920   S SEAWARD AVE, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.26411,
    latitude: -119.27196
  },
  {
    zipcode: 93003,
    title: 'RBS WorldPay',
    description: '3500   E MAIN ST, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.26444,
    latitude: -119.24472
  },
  {
    zipcode: 93003,
    title: 'CARDTRONICS',
    description: '3506   E MAIN ST, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.26444,
    latitude: -119.24472
  },
  {
    zipcode: 93021,
    title: 'FIS',
    description: '3941    SPRING RD, Moorpark, CA 93021',
    surcharge: true,
    longitude: 34.26464,
    latitude: -118.86564
  },
  {
    zipcode: 93003,
    title: 'CARDTRONICS',
    description: '5688    TELEPHONE RD, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.2649,
    latitude: -119.21495
  },
  {
    zipcode: 93003,
    title: 'FIRST BANK',
    description: '5808    TELEPHONE RD, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.26595,
    latitude: -119.21712
  },
  {
    zipcode: 93001,
    title: 'RBS WorldPay',
    description: '2124    HARBOR BLVD, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.26642,
    latitude: -119.27127
  },
  {
    zipcode: 93001,
    title: '1ST ISO PROCESSING',
    description: '2121    HARBOR BLVD, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.26651,
    latitude: -119.27182
  },
  {
    zipcode: 93003,
    title: 'WELLS FARGO BANK',
    description: '5751    TELEPHONE RD, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.26686,
    latitude: -119.21699
  },
  {
    zipcode: 93003,
    title: 'WELLS FARGO BANK',
    description: '5751    TELEPHONE RD, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.26686,
    latitude: -119.21699
  },
  {
    zipcode: 93003,
    title: 'WELLS FARGO BANK',
    description: '5751    TELEPHONE RD, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.26686,
    latitude: -119.21699
  },
  {
    zipcode: 93001,
    title: 'RBS WorldPay',
    description: '2099    HARBOR BLVD, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.2674,
    latitude: -119.27291
  },
  {
    zipcode: 93003,
    title: 'CITIBANK',
    description: '472   S MILLS RD, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.26792,
    latitude: -119.24654
  },
  {
    zipcode: 93003,
    title: 'CITIBANK',
    description: '472   S MILLS RD, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.26792,
    latitude: -119.24654
  },
  {
    zipcode: 93003,
    title: 'MONEYPASS',
    description: '480   S MILLS RD, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.26792,
    latitude: -119.24654
  },
  {
    zipcode: 93065,
    title: 'PULSE NETWORK',
    description: '1706    ERRINGER RD, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.26847,
    latitude: -118.76127
  },
  {
    zipcode: 93021,
    title: 'CARDTRONICS',
    description: '800    NEW LOS ANGELES AVE, Moorpark, CA 93021',
    surcharge: true,
    longitude: 34.26862,
    latitude: -118.85515
  },
  {
    zipcode: 93003,
    title: 'RABOBANK',
    description: '300   S MILLS RD, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.26895,
    latitude: -119.24676
  },
  {
    zipcode: 93004,
    title: 'RBS WorldPay',
    description: '7841    TELEPHONE RD, Ventura, CA 93004',
    surcharge: true,
    longitude: 34.2692,
    latitude: -119.18651
  },
  {
    zipcode: 93003,
    title: 'UNION BANK',
    description: '250   S MILLS RD, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.26966,
    latitude: -119.24692
  },
  {
    zipcode: 93003,
    title: 'WELLS FARGO BANK',
    description: '270   S MILLS RD, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.26966,
    latitude: -119.24692
  },
  {
    zipcode: 93003,
    title: 'WELLS FARGO BANK',
    description: '270   S MILLS RD, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.26966,
    latitude: -119.24692
  },
  {
    zipcode: 93021,
    title: 'BANK OF AMERICA',
    description: '730    NEW LOS ANGELES AVE, Moorpark, CA 93021',
    surcharge: false,
    longitude: 34.26986,
    latitude: -118.86193
  },
  {
    zipcode: 93021,
    title: 'BANK OF AMERICA',
    description: '730    NEW LOS ANGELES AVE, Moorpark, CA 93021',
    surcharge: false,
    longitude: 34.26986,
    latitude: -118.86193
  },
  {
    zipcode: 93063,
    title: 'BANK OF AMERICA',
    description: '1800    TAPO CANYON RD, Simi Valley, CA 93063',
    surcharge: false,
    longitude: 34.2699,
    latitude: -118.71678
  },
  {
    zipcode: 93003,
    title: 'CARDTRONICS',
    description: '605   S MILLS RD, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.27068,
    latitude: -119.24732
  },
  {
    zipcode: 93063,
    title: 'CARDTRONICS',
    description: '1970    SEQUOIA AVE, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.2713,
    latitude: -118.7304
  },
  {
    zipcode: 93003,
    title: 'BANK OF AMERICA',
    description: '9493    TELEPHONE RD, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.27147,
    latitude: -119.17213
  },
  {
    zipcode: 93065,
    title: 'CARDTRONICS',
    description: '2726   E LOS ANGELES AVE, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27158,
    latitude: -118.74333
  },
  {
    zipcode: 93065,
    title: 'RBS WorldPay',
    description: '1120   E LOS ANGELES AVE, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27162,
    latitude: -118.77811
  },
  {
    zipcode: 93065,
    title: 'PULSE NETWORK',
    description: '1196   E LOS ANGELES AVE, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27162,
    latitude: -118.77811
  },
  {
    zipcode: 93065,
    title: 'WELLS FARGO BANK',
    description: '1200   E LOS ANGELES AVE, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27162,
    latitude: -118.77726
  },
  {
    zipcode: 93065,
    title: 'WELLS FARGO BANK',
    description: '1200   E LOS ANGELES AVE, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27162,
    latitude: -118.77726
  },
  {
    zipcode: 93065,
    title: 'WELLS FARGO BANK',
    description: '1200   E LOS ANGELES AVE, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27162,
    latitude: -118.77726
  },
  {
    zipcode: 93065,
    title: 'RBS WorldPay',
    description: '480   E LOS ANGELES AVE, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27162,
    latitude: -118.788
  },
  {
    zipcode: 93065,
    title: 'PULSE NETWORK',
    description: '510   E LOS ANGELES AVE, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27162,
    latitude: -118.78704
  },
  {
    zipcode: 93065,
    title: 'CHASE',
    description: '660   E LOS ANGELES AVE, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27162,
    latitude: -118.78539
  },
  {
    zipcode: 93065,
    title: 'CHASE',
    description: '660   E LOS ANGELES AVE, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27162,
    latitude: -118.78539
  },
  {
    zipcode: 93065,
    title: 'CHASE',
    description: '660   E LOS ANGELES AVE, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27162,
    latitude: -118.78539
  },
  {
    zipcode: 93065,
    title: 'RBS WorldPay',
    description: '706   E LOS ANGELES AVE, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27162,
    latitude: -118.78396
  },
  {
    zipcode: 93004,
    title: 'ACE CENTER',
    description: '9340    TELEPHONE RD, Ventura, CA 93004',
    surcharge: true,
    longitude: 34.27163,
    latitude: -119.17128
  },
  {
    zipcode: 93063,
    title: 'BANK OF AMERICA',
    description: '5768   E LOS ANGELES AVE, Simi Valley, CA 93063',
    surcharge: false,
    longitude: 34.27164,
    latitude: -118.67909
  },
  {
    zipcode: 93063,
    title: 'BANK OF AMERICA',
    description: '5768   E LOS ANGELES AVE, Simi Valley, CA 93063',
    surcharge: false,
    longitude: 34.27164,
    latitude: -118.67909
  },
  {
    zipcode: 93063,
    title: 'CARDTRONICS',
    description: '5820   E LOS ANGELES AVE, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.27164,
    latitude: -118.67749
  },
  {
    zipcode: 93065,
    title: 'RBS WorldPay',
    description: '1099   E LOS ANGELES AVE, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.2718,
    latitude: -118.77886
  },
  {
    zipcode: 93065,
    title: 'FIS',
    description: '1159   E LOS ANGELES AVE, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.2718,
    latitude: -118.77815
  },
  {
    zipcode: 93065,
    title: 'ACE CENTER',
    description: '1177A   E LOS ANGELES AVE, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.2718,
    latitude: -118.77777
  },
  {
    zipcode: 93065,
    title: 'BANK OF AMERICA',
    description: '1307   E LOS ANGELES AVE, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.2718,
    latitude: -118.77554
  },
  {
    zipcode: 93065,
    title: 'BANK OF AMERICA',
    description: '1307   E LOS ANGELES AVE, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.2718,
    latitude: -118.77554
  },
  {
    zipcode: 93065,
    title: 'BANK OF AMERICA',
    description: '1307   E LOS ANGELES AVE, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.2718,
    latitude: -118.77554
  },
  {
    zipcode: 93065,
    title: 'BANK OF AMERICA',
    description: '1307   E LOS ANGELES AVE, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.2718,
    latitude: -118.77554
  },
  {
    zipcode: 93065,
    title: 'CHASE',
    description: '1377   E LOS ANGELES AVE, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.2718,
    latitude: -118.77431
  },
  {
    zipcode: 93065,
    title: 'CHASE',
    description: '1377   E LOS ANGELES AVE, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.2718,
    latitude: -118.77431
  },
  {
    zipcode: 93065,
    title: 'CHASE',
    description: '1377   E LOS ANGELES AVE, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.2718,
    latitude: -118.77431
  },
  {
    zipcode: 93065,
    title: 'MONEYPASS',
    description: '1445   E LOS ANGELES AVE, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.27181,
    latitude: -118.77222
  },
  {
    zipcode: 93065,
    title: 'UNION BANK',
    description: '1475   E LOS ANGELES AVE, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27181,
    latitude: -118.77108
  },
  {
    zipcode: 93065,
    title: 'UNION BANK',
    description: '1475   E LOS ANGELES AVE, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27181,
    latitude: -118.77108
  },
  {
    zipcode: 93003,
    title: 'CARDTRONICS',
    description: '245   S MILLS RD, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.27181,
    latitude: -119.24756
  },
  {
    zipcode: 93063,
    title: 'CHASE',
    description: '5105   E LOS ANGELES AVE, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.27182,
    latitude: -118.69241
  },
  {
    zipcode: 93063,
    title: 'CHASE',
    description: '5105   E LOS ANGELES AVE, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.27182,
    latitude: -118.69241
  },
  {
    zipcode: 93063,
    title: 'CHASE',
    description: '5105   E LOS ANGELES AVE, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.27182,
    latitude: -118.69241
  },
  {
    zipcode: 93063,
    title: '1ST ISO PROCESSING',
    description: '5803   E LOS ANGELES AVE, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.27182,
    latitude: -118.67775
  },
  {
    zipcode: 93063,
    title: 'WELLS FARGO BANK',
    description: '5805   E LOS ANGELES AVE, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.27182,
    latitude: -118.67775
  },
  {
    zipcode: 93063,
    title: 'MONEYPASS',
    description: '5821   E LOS ANGELES AVE, Simi Valley, CA 93063',
    surcharge: false,
    longitude: 34.27182,
    latitude: -118.67775
  },
  {
    zipcode: 93063,
    title: 'FIS',
    description: '5845   E LOS ANGELES AVE, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.27182,
    latitude: -118.67775
  },
  {
    zipcode: 93004,
    title: 'PULSE NETWORK',
    description: '9460    TELEPHONE RD, Ventura, CA 93004',
    surcharge: true,
    longitude: 34.27189,
    latitude: -119.17081
  },
  {
    zipcode: 93003,
    title: 'MONEYPASS',
    description: '3130    TELEGRAPH RD, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.2721,
    latitude: -119.25386
  },
  {
    zipcode: 93004,
    title: 'CARDTRONICS',
    description: '1001    PETIT AVE, Ventura, CA 93004',
    surcharge: true,
    longitude: 34.27211,
    latitude: -119.17056
  },
  {
    zipcode: 93003,
    title: 'MONEYPASS',
    description: '3260    TELEGRAPH RD, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.27224,
    latitude: -119.25294
  },
  {
    zipcode: 93003,
    title: 'WELLS FARGO BANK',
    description: '2704   E THOMPSON BLVD, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.27227,
    latitude: -119.26022
  },
  {
    zipcode: 93003,
    title: 'WELLS FARGO BANK',
    description: '2704   E THOMPSON BLVD, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.27227,
    latitude: -119.26022
  },
  {
    zipcode: 93003,
    title: 'FIS',
    description: '2738   E THOMPSON BLVD, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.27227,
    latitude: -119.26022
  },
  {
    zipcode: 93003,
    title: 'CARDTRONICS',
    description: '2764   E THOMPSON BLVD, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.27227,
    latitude: -119.26022
  },
  {
    zipcode: 93003,
    title: 'CHASE',
    description: '3498    TELEGRAPH RD, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.27302,
    latitude: -119.24774
  },
  {
    zipcode: 93003,
    title: 'CHASE',
    description: '3498    TELEGRAPH RD, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.27302,
    latitude: -119.24774
  },
  {
    zipcode: 93003,
    title: 'CHASE',
    description: '3498    TELEGRAPH RD, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.27302,
    latitude: -119.24774
  },
  {
    zipcode: 93003,
    title: 'CHASE',
    description: '3498    TELEGRAPH RD, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.27302,
    latitude: -119.24774
  },
  {
    zipcode: 93065,
    title: 'RBS WorldPay',
    description: '1357   E LOS ANGELES AVE, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27303,
    latitude: -118.79987
  },
  {
    zipcode: 93003,
    title: 'RBS WorldPay',
    description: '3477    TELEGRAPH RD, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.27306,
    latitude: -119.24868
  },
  {
    zipcode: 93001,
    title: 'CARDTRONICS',
    description: '2314   E THOMPSON BLVD, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.27337,
    latitude: -119.26576
  },
  {
    zipcode: 93001,
    title: 'RBS WorldPay',
    description: '2292   E THOMPSON BLVD, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.27353,
    latitude: -119.26657
  },
  {
    zipcode: 93063,
    title: 'UNION BANK',
    description: '2092    TAPO ST, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.27363,
    latitude: -118.70885
  },
  {
    zipcode: 93003,
    title: 'BANK OF AMERICA',
    description: '2698   E MAIN ST, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.27384,
    latitude: -119.26012
  },
  {
    zipcode: 93003,
    title: 'BANK OF AMERICA',
    description: '2698   E MAIN ST, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.27384,
    latitude: -119.26012
  },
  {
    zipcode: 93003,
    title: 'BANK OF AMERICA',
    description: '2698   E MAIN ST, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.27384,
    latitude: -119.26012
  },
  {
    zipcode: 93065,
    title: 'CARDTRONICS',
    description: '25    TIERRA REJADA RD, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.2741,
    latitude: -118.80418
  },
  {
    zipcode: 93003,
    title: 'PULSE NETWORK',
    description: '147   N BRENT ST, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.27418,
    latitude: -119.25729
  },
  {
    zipcode: 93003,
    title: 'PULSE NETWORK',
    description: '4111    TELEGRAPH RD, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.27455,
    latitude: -119.23866
  },
  {
    zipcode: 93003,
    title: 'RBS WorldPay',
    description: '2599   E MAIN ST, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.27525,
    latitude: -119.26279
  },
  {
    zipcode: 93065,
    title: 'BANK OF AMERICA',
    description: '450    AMERICAN ST, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.27533,
    latitude: -118.80395
  },
  {
    zipcode: 93063,
    title: 'RBS WorldPay',
    description: '2211    TAPO ST, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.27562,
    latitude: -118.70903
  },
  {
    zipcode: 93003,
    title: 'PULSE NETWORK',
    description: '4667    TELEGRAPH RD, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.27575,
    latitude: -119.23048
  },
  {
    zipcode: 93003,
    title: 'PULSE NETWORK',
    description: '4667    TELEGRAPH RD, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.27575,
    latitude: -119.23048
  },
  {
    zipcode: 93003,
    title: 'FIS',
    description: '4667    TELEGRAPH RD, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.27575,
    latitude: -119.23048
  },
  {
    zipcode: 93003,
    title: 'RBS WorldPay',
    description: '2358   E MAIN ST, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.27602,
    latitude: -119.26447
  },
  {
    zipcode: 93063,
    title: 'PULSE NETWORK',
    description: '2204    TAPO ST, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.27649,
    latitude: -118.70885
  },
  {
    zipcode: 93003,
    title: 'CARDTRONICS',
    description: '50   N ASHWOOD AVE, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.27712,
    latitude: -119.23964
  },
  {
    zipcode: 93063,
    title: 'PULSE NETWORK',
    description: '2340    KUEHNER DR, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.27789,
    latitude: -118.66203
  },
  {
    zipcode: 93003,
    title: 'CARDTRONICS',
    description: '5900    TELEGRAPH RD, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.27791,
    latitude: -119.2146
  },
  {
    zipcode: 93063,
    title: 'RBS WorldPay',
    description: '2390    TAPO ST, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.27793,
    latitude: -118.70885
  },
  {
    zipcode: 93003,
    title: 'MONEYPASS',
    description: '6040    TELEGRAPH RD, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.27809,
    latitude: -119.21334
  },
  {
    zipcode: 93003,
    title: 'CARDTRONICS',
    description: '6040    TELEGRAPH RD, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.27809,
    latitude: -119.21334
  },
  {
    zipcode: 93003,
    title: 'MONEYPASS',
    description: '6128 STE A  TELEGRAPH RD, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.27821,
    latitude: -119.21255
  },
  {
    zipcode: 93001,
    title: 'RBS WorldPay',
    description: '415   E THOMPSON BLVD, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.27835,
    latitude: -119.2941
  },
  {
    zipcode: 93001,
    title: 'RBS WorldPay',
    description: '893   E THOMPSON BLVD, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.27837,
    latitude: -119.28792
  },
  {
    zipcode: 93063,
    title: 'RBS WorldPay',
    description: '2399    TAPO ST, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.2788,
    latitude: -118.70902
  },
  {
    zipcode: 93065,
    title: 'CARDTRONICS',
    description: '2395    ERRINGER RD, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27883,
    latitude: -118.76145
  },
  {
    zipcode: 93065,
    title: 'CARDTRONICS',
    description: '2654    COCHRAN ST, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.2789,
    latitude: -118.7447
  },
  {
    zipcode: 93065,
    title: 'WELLS FARGO BANK',
    description: '2740    COCHRAN ST, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.2789,
    latitude: -118.74298
  },
  {
    zipcode: 93065,
    title: 'WELLS FARGO BANK',
    description: '2740    COCHRAN ST, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.2789,
    latitude: -118.74298
  },
  {
    zipcode: 93065,
    title: 'WELLS FARGO BANK',
    description: '2740    COCHRAN ST, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.2789,
    latitude: -118.74298
  },
  {
    zipcode: 93065,
    title: 'WELLS FARGO BANK',
    description: '2740    COCHRAN ST, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.2789,
    latitude: -118.74298
  },
  {
    zipcode: 93065,
    title: 'BANK OF AMERICA',
    description: '2830    COCHRAN ST, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.2789,
    latitude: -118.74122
  },
  {
    zipcode: 93065,
    title: 'BANK OF AMERICA',
    description: '2830    COCHRAN ST, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.2789,
    latitude: -118.74122
  },
  {
    zipcode: 93065,
    title: 'BANK OF AMERICA',
    description: '2830    COCHRAN ST, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.2789,
    latitude: -118.74122
  },
  {
    zipcode: 93065,
    title: 'RBS WorldPay',
    description: '2832    COCHRAN ST, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.2789,
    latitude: -118.74122
  },
  {
    zipcode: 93065,
    title: 'CITIBANK',
    description: '2860    COCHRAN ST, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.2789,
    latitude: -118.74056
  },
  {
    zipcode: 93065,
    title: 'CITIBANK',
    description: '2860    COCHRAN ST, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.2789,
    latitude: -118.74056
  },
  {
    zipcode: 93065,
    title: 'WELLS FARGO BANK',
    description: '2888    COCHRAN ST, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27891,
    latitude: -118.74028
  },
  {
    zipcode: 93065,
    title: 'WELLS FARGO BANK',
    description: '2888    COCHRAN ST, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27891,
    latitude: -118.74028
  },
  {
    zipcode: 93063,
    title: 'CARDTRONICS',
    description: '3998 STE 1  COCHRAN ST, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.27894,
    latitude: -118.71776
  },
  {
    zipcode: 93065,
    title: 'CHASE',
    description: '2398    SYCAMORE DR, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27897,
    latitude: -118.74371
  },
  {
    zipcode: 93065,
    title: 'CHASE',
    description: '2398    SYCAMORE DR, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27897,
    latitude: -118.74371
  },
  {
    zipcode: 93065,
    title: 'CHASE',
    description: '2398    SYCAMORE DR, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27897,
    latitude: -118.74371
  },
  {
    zipcode: 93001,
    title: 'MONEYPASS',
    description: '101   S CHESTNUT ST, Ventura, CA 93001',
    surcharge: false,
    longitude: 34.27903,
    latitude: -119.29154
  },
  {
    zipcode: 93065,
    title: 'MONEYPASS',
    description: '1855    COCHRAN ST, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.27908,
    latitude: -118.76209
  },
  {
    zipcode: 93065,
    title: 'CARDTRONICS',
    description: '1855    COCHRAN ST, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.27908,
    latitude: -118.76209
  },
  {
    zipcode: 93065,
    title: 'PULSE NETWORK',
    description: '2801    COCHRAN ST, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27908,
    latitude: -118.74142
  },
  {
    zipcode: 93065,
    title: 'CARDTRONICS',
    description: '2825    COCHRAN ST, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27908,
    latitude: -118.74142
  },
  {
    zipcode: 93065,
    title: 'CARDTRONICS',
    description: '2907    COCHRAN ST, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27908,
    latitude: -118.73792
  },
  {
    zipcode: 93063,
    title: 'BANK OF AMERICA',
    description: '3963    COCHRAN ST, Simi Valley, CA 93063',
    surcharge: false,
    longitude: 34.27911,
    latitude: -118.71882
  },
  {
    zipcode: 93065,
    title: 'RBS WorldPay',
    description: '2405    SYCAMORE DR, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.27932,
    latitude: -118.74389
  },
  {
    zipcode: 93065,
    title: 'CARDTRONICS',
    description: '2417    SYCAMORE DR, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27932,
    latitude: -118.74389
  },
  {
    zipcode: 93063,
    title: 'CARDTRONICS',
    description: '2449    STEARNS ST, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.27935,
    latitude: -118.69146
  },
  {
    zipcode: 93063,
    title: 'RBS WorldPay',
    description: '2500    TAPO CANYON RD, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.27988,
    latitude: -118.71775
  },
  {
    zipcode: 93001,
    title: 'RABOBANK',
    description: '304   E MAIN ST, Ventura, CA 93001',
    surcharge: false,
    longitude: 34.28071,
    latitude: -119.29555
  },
  {
    zipcode: 93001,
    title: 'FIS',
    description: '265   E MAIN ST, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.28089,
    latitude: -119.29705
  },
  {
    zipcode: 93001,
    title: 'WELLS FARGO BANK',
    description: '419   E MAIN ST, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.2809,
    latitude: -119.29436
  },
  {
    zipcode: 93001,
    title: 'BANK OF AMERICA',
    description: '507   E MAIN ST, Ventura, CA 93001',
    surcharge: false,
    longitude: 34.2809,
    latitude: -119.29224
  },
  {
    zipcode: 93001,
    title: 'BANK OF AMERICA',
    description: '507   E MAIN ST, Ventura, CA 93001',
    surcharge: false,
    longitude: 34.2809,
    latitude: -119.29224
  },
  {
    zipcode: 93003,
    title: 'CARDTRONICS',
    description: '1007   E MAIN ST, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.28093,
    latitude: -119.28458
  },
  {
    zipcode: 93004,
    title: 'CHASE',
    description: '7730    TELEGRAPH RD, Ventura, CA 93004',
    surcharge: true,
    longitude: 34.28116,
    latitude: -119.19188
  },
  {
    zipcode: 93004,
    title: 'CHASE',
    description: '7730    TELEGRAPH RD, Ventura, CA 93004',
    surcharge: true,
    longitude: 34.28116,
    latitude: -119.19188
  },
  {
    zipcode: 93001,
    title: 'RBS WorldPay',
    description: '67 STE D W MAIN ST, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.28134,
    latitude: -119.30259
  },
  {
    zipcode: 93001,
    title: 'WELLS FARGO BANK',
    description: '115   W MAIN ST, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.28139,
    latitude: -119.30303
  },
  {
    zipcode: 93001,
    title: 'WELLS FARGO BANK',
    description: '115   W MAIN ST, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.28139,
    latitude: -119.30303
  },
  {
    zipcode: 93001,
    title: 'FIS',
    description: '131   W MAIN ST, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.28139,
    latitude: -119.30303
  },
  {
    zipcode: 93004,
    title: 'WELLS FARGO BANK',
    description: '7800    TELEGRAPH RD, Ventura, CA 93004',
    surcharge: true,
    longitude: 34.2814,
    latitude: -119.19013
  },
  {
    zipcode: 93004,
    title: 'WELLS FARGO BANK',
    description: '7800    TELEGRAPH RD, Ventura, CA 93004',
    surcharge: true,
    longitude: 34.2814,
    latitude: -119.19013
  },
  {
    zipcode: 93004,
    title: 'CARDTRONICS',
    description: '7850    TELEGRAPH RD, Ventura, CA 93004',
    surcharge: true,
    longitude: 34.2814,
    latitude: -119.19013
  },
  {
    zipcode: 93065,
    title: 'CARDTRONICS',
    description: '2568    SYCAMORE DR, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.28165,
    latitude: -118.74371
  },
  {
    zipcode: 93021,
    title: 'UNION BANK',
    description: '256   W LOS ANGELES AVE, Moorpark, CA 93021',
    surcharge: true,
    longitude: 34.28193,
    latitude: -118.8035
  },
  {
    zipcode: 93063,
    title: 'RBS WorldPay',
    description: '2627    YOSEMITE AVE, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.28261,
    latitude: -118.67916
  },
  {
    zipcode: 93065,
    title: 'PULSE NETWORK',
    description: '255    COCHRAN ST, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.28299,
    latitude: -118.79851
  },
  {
    zipcode: 93065,
    title: 'RBS WorldPay',
    description: '999    ENCHANTED WAY, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.28339,
    latitude: -118.77916
  },
  {
    zipcode: 93063,
    title: 'CARDTRONICS',
    description: '2660    PARK CENTER DR, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.28347,
    latitude: -118.79725
  },
  {
    zipcode: 93063,
    title: 'WESCOM CU',
    description: '2691 # R  TAPO CANYON RD, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.28351,
    latitude: -118.71783
  },
  {
    zipcode: 93063,
    title: 'WESCOM CU',
    description: '2691 # R  TAPO CANYON RD, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.28351,
    latitude: -118.71783
  },
  {
    zipcode: 93004,
    title: 'RBS WorldPay',
    description: '11065    VIOLETA ST, Ventura, CA 93004',
    surcharge: true,
    longitude: 34.28353,
    latitude: -119.14969
  },
  {
    zipcode: 93065,
    title: 'CARDTRONICS',
    description: '108    COCHRAN ST, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.28358,
    latitude: -118.80057
  },
  {
    zipcode: 93021,
    title: 'RBS WorldPay',
    description: '50    POINDEXTER AVE, Moorpark, CA 93021',
    surcharge: true,
    longitude: 34.28369,
    latitude: -118.89893
  },
  {
    zipcode: 93021,
    title: 'CARDTRONICS',
    description: '140   W LOS ANGELES AVE, Moorpark, CA 93021',
    surcharge: true,
    longitude: 34.28491,
    latitude: -118.80577
  },
  {
    zipcode: 93021,
    title: 'RABOBANK',
    description: '146   W LOS ANGELES AVE, Moorpark, CA 93021',
    surcharge: false,
    longitude: 34.28491,
    latitude: -118.80577
  },
  {
    zipcode: 93021,
    title: 'RABOBANK',
    description: '146   W LOS ANGELES AVE, Moorpark, CA 93021',
    surcharge: false,
    longitude: 34.28491,
    latitude: -118.80577
  },
  {
    zipcode: 93065,
    title: 'WELLS FARGO BANK',
    description: '1403    SIMI TOWN CENTER WAY, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.2853,
    latitude: -118.77189
  },
  {
    zipcode: 93065,
    title: 'WELLS FARGO BANK',
    description: '1403    SIMI TOWN CENTER WAY, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.2853,
    latitude: -118.77189
  },
  {
    zipcode: 93065,
    title: 'WELLS FARGO BANK',
    description: '1403    SIMI TOWN CENTER WAY, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.2853,
    latitude: -118.77189
  },
  {
    zipcode: 93065,
    title: 'UNION BANK',
    description: '1581    SIMI TOWN CENTER WAY, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.2853,
    latitude: -118.77189
  },
  {
    zipcode: 93065,
    title: 'UNION BANK',
    description: '1581    SIMI TOWN CENTER WAY, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.2853,
    latitude: -118.77189
  },
  {
    zipcode: 93063,
    title: 'BANK OF AMERICA',
    description: '2717A    TAPO CANYON RD, Simi Valley, CA 93063',
    surcharge: false,
    longitude: 34.28543,
    latitude: -118.71783
  },
  {
    zipcode: 93063,
    title: 'BANK OF AMERICA',
    description: '2717A    TAPO CANYON RD, Simi Valley, CA 93063',
    surcharge: false,
    longitude: 34.28543,
    latitude: -118.71783
  },
  {
    zipcode: 93021,
    title: 'PULSE NETWORK',
    description: '550   W LOS ANGELES AVE, Moorpark, CA 93021',
    surcharge: true,
    longitude: 34.28578,
    latitude: -118.81462
  },
  {
    zipcode: 93021,
    title: 'CARDTRONICS',
    description: '101   W LOS ANGELES AVE, Moorpark, CA 93021',
    surcharge: true,
    longitude: 34.28596,
    latitude: -118.81335
  },
  {
    zipcode: 93021,
    title: 'CARDTRONICS',
    description: '155   W LOS ANGELES AVE, Moorpark, CA 93021',
    surcharge: true,
    longitude: 34.28597,
    latitude: -118.81358
  },
  {
    zipcode: 93021,
    title: 'CHASE',
    description: '165   W LOS ANGELES AVE, Moorpark, CA 93021',
    surcharge: true,
    longitude: 34.28597,
    latitude: -118.81358
  },
  {
    zipcode: 93021,
    title: 'CHASE',
    description: '165   W LOS ANGELES AVE, Moorpark, CA 93021',
    surcharge: true,
    longitude: 34.28597,
    latitude: -118.81358
  },
  {
    zipcode: 93021,
    title: 'CHASE',
    description: '165   W LOS ANGELES AVE, Moorpark, CA 93021',
    surcharge: true,
    longitude: 34.28597,
    latitude: -118.81358
  },
  {
    zipcode: 93063,
    title: 'CARDTRONICS',
    description: '2780    TAPO CANYON RD, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.28597,
    latitude: -118.71765
  },
  {
    zipcode: 93021,
    title: 'WELLS FARGO BANK',
    description: '515   W LOS ANGELES AVE, Moorpark, CA 93021',
    surcharge: true,
    longitude: 34.28598,
    latitude: -118.81428
  },
  {
    zipcode: 93021,
    title: 'WELLS FARGO BANK',
    description: '515   W LOS ANGELES AVE, Moorpark, CA 93021',
    surcharge: true,
    longitude: 34.28598,
    latitude: -118.81428
  },
  {
    zipcode: 93063,
    title: 'CHASE',
    description: '2790    TAPO CANYON RD, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.28615,
    latitude: -118.71765
  },
  {
    zipcode: 93063,
    title: 'CHASE',
    description: '2790    TAPO CANYON RD, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.28615,
    latitude: -118.71765
  },
  {
    zipcode: 93063,
    title: 'CARDTRONICS',
    description: '4440    ALAMO ST, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.28618,
    latitude: -118.708
  },
  {
    zipcode: 93001,
    title: 'RBS WorldPay',
    description: '505   N VENTURA AVE, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.28748,
    latitude: -119.29903
  },
  {
    zipcode: 93021,
    title: 'RBS WorldPay',
    description: '252   W LOS ANGELES AVE, Moorpark, CA 93021',
    surcharge: true,
    longitude: 34.28751,
    latitude: -118.82544
  },
  {
    zipcode: 93001,
    title: 'RBS WorldPay',
    description: '580   N VENTURA AVE, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.28785,
    latitude: -119.29873
  },
  {
    zipcode: 93021,
    title: 'RBS WorldPay',
    description: '13800    PRINCETON AVE, Moorpark, CA 93021',
    surcharge: true,
    longitude: 34.28827,
    latitude: -118.86394
  },
  {
    zipcode: 93001,
    title: 'PULSE NETWORK',
    description: '591   N VENTURA AVE, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.28827,
    latitude: -119.29879
  },
  {
    zipcode: 93063,
    title: 'UNION BANK',
    description: '2930    TAPO CANYON RD, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.28865,
    latitude: -118.71758
  },
  {
    zipcode: 93063,
    title: 'MONEYPASS',
    description: '2938    TAPO CANYON RD, Simi Valley, CA 93063',
    surcharge: false,
    longitude: 34.28865,
    latitude: -118.71758
  },
  {
    zipcode: 93065,
    title: 'UNION BANK',
    description: '2975    SYCAMORE DR, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.28949,
    latitude: -118.74399
  },
  {
    zipcode: 93001,
    title: 'PULSE NETWORK',
    description: '774   N VENTURA AVE, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.28981,
    latitude: -119.29814
  },
  {
    zipcode: 93001,
    title: 'RBS WorldPay',
    description: '887   N VENTURA AVE, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.29147,
    latitude: -119.29782
  },
  {
    zipcode: 93001,
    title: 'RBS WorldPay',
    description: '995   N VENTURA AVE, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.29205,
    latitude: -119.29765
  },
  {
    zipcode: 93004,
    title: 'CHASE',
    description: '310   S WELLS RD, Ventura, CA 93004',
    surcharge: true,
    longitude: 34.2922,
    latitude: -119.1589
  },
  {
    zipcode: 93004,
    title: 'CHASE',
    description: '310   S WELLS RD, Ventura, CA 93004',
    surcharge: true,
    longitude: 34.2922,
    latitude: -119.1589
  },
  {
    zipcode: 93003,
    title: 'UNION BANK',
    description: '789   S VICTORIA AVE, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.29271,
    latitude: -119.21669
  },
  {
    zipcode: 93003,
    title: 'CITIBANK',
    description: '1011   S VICTORIA AVE, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.29314,
    latitude: -119.21683
  },
  {
    zipcode: 93003,
    title: 'CITIBANK',
    description: '1011   S VICTORIA AVE, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.29314,
    latitude: -119.21683
  },
  {
    zipcode: 93063,
    title: 'RBS WorldPay',
    description: '4371    TOWNSHIP AVE, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.29358,
    latitude: -118.715
  },
  {
    zipcode: 93001,
    title: 'RBS WorldPay',
    description: '1285   N VENTURA AVE, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.29488,
    latitude: -119.29679
  },
  {
    zipcode: 93003,
    title: 'BANK OF AMERICA',
    description: '1130   S VICTORIA AVE, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.295,
    latitude: -119.21761
  },
  {
    zipcode: 93003,
    title: 'BANK OF AMERICA',
    description: '1130   S VICTORIA AVE, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.295,
    latitude: -119.21761
  },
  {
    zipcode: 93003,
    title: 'BANK OF AMERICA',
    description: '1130   S VICTORIA AVE, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.295,
    latitude: -119.21761
  },
  {
    zipcode: 93003,
    title: 'BANK OF AMERICA',
    description: '1130   S VICTORIA AVE, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.295,
    latitude: -119.21761
  },
  {
    zipcode: 93021,
    title: 'RBS WorldPay',
    description: '14711    PRINCETON AVE, Moorpark, CA 93021',
    surcharge: true,
    longitude: 34.29619,
    latitude: -118.85659
  },
  {
    zipcode: 93021,
    title: 'PULSE NETWORK',
    description: '6599    COLLINS DR, Moorpark, CA 93021',
    surcharge: true,
    longitude: 34.29931,
    latitude: -118.84234
  },
  {
    zipcode: 93060,
    title: 'PULSE NETWORK',
    description: '102    HALLOCK DR, Santa Paula, CA 93060',
    surcharge: true,
    longitude: 34.33453,
    latitude: -119.13974
  },
  {
    zipcode: 93060,
    title: 'CARDTRONICS',
    description: '765   W HARVARD BLVD, Santa Paula, CA 93060',
    surcharge: true,
    longitude: 34.34112,
    latitude: -119.08376
  },
  {
    zipcode: 93060,
    title: 'MONEYPASS',
    description: '537   W HARVARD BLVD, Santa Paula, CA 93060',
    surcharge: false,
    longitude: 34.34291,
    latitude: -119.08036
  },
  {
    zipcode: 93060,
    title: 'CHASE',
    description: '539   W HARVARD BLVD, Santa Paula, CA 93060',
    surcharge: true,
    longitude: 34.34291,
    latitude: -119.08036
  },
  {
    zipcode: 93060,
    title: 'CHASE',
    description: '539   W HARVARD BLVD, Santa Paula, CA 93060',
    surcharge: true,
    longitude: 34.34291,
    latitude: -119.08036
  },
  {
    zipcode: 93060,
    title: 'WELLS FARGO BANK',
    description: '576   W MAIN ST, Santa Paula, CA 93060',
    surcharge: true,
    longitude: 34.3444,
    latitude: -119.08362
  },
  {
    zipcode: 93060,
    title: 'WELLS FARGO BANK',
    description: '576   W MAIN ST, Santa Paula, CA 93060',
    surcharge: true,
    longitude: 34.3444,
    latitude: -119.08362
  },
  {
    zipcode: 93060,
    title: 'WELLS FARGO BANK',
    description: '576   W MAIN ST, Santa Paula, CA 93060',
    surcharge: true,
    longitude: 34.3444,
    latitude: -119.08362
  },
  {
    zipcode: 93060,
    title: 'RBS WorldPay',
    description: '592   W MAIN ST, Santa Paula, CA 93060',
    surcharge: true,
    longitude: 34.3444,
    latitude: -119.08362
  },
  {
    zipcode: 93060,
    title: 'CARDTRONICS',
    description: '600   W MAIN ST, Santa Paula, CA 93060',
    surcharge: true,
    longitude: 34.34447,
    latitude: -119.08359
  },
  {
    zipcode: 93060,
    title: 'FIS',
    description: '221   E HARVARD BLVD, Santa Paula, CA 93060',
    surcharge: true,
    longitude: 34.3471,
    latitude: -119.06954
  },
  {
    zipcode: 93060,
    title: 'PULSE NETWORK',
    description: '206   E HARVARD BLVD, Santa Paula, CA 93060',
    surcharge: true,
    longitude: 34.34717,
    latitude: -119.06871
  },
  {
    zipcode: 93060,
    title: 'ACE CENTER',
    description: '284   E HARVARD BLVD, Santa Paula, CA 93060',
    surcharge: true,
    longitude: 34.34717,
    latitude: -119.06871
  },
  {
    zipcode: 93060,
    title: 'ACE CENTER',
    description: '284   E HARVARD BLVD, Santa Paula, CA 93060',
    surcharge: true,
    longitude: 34.34717,
    latitude: -119.06871
  },
  {
    zipcode: 93060,
    title: 'RBS WorldPay',
    description: '320   E HARVARD BLVD, Santa Paula, CA 93060',
    surcharge: true,
    longitude: 34.34742,
    latitude: -119.06791
  },
  {
    zipcode: 93060,
    title: 'CARDTRONICS',
    description: '983   E HARVARD BLVD, Santa Paula, CA 93060',
    surcharge: true,
    longitude: 34.35046,
    latitude: -119.05883
  },
  {
    zipcode: 93060,
    title: 'UNION BANK',
    description: '634   E MAIN ST, Santa Paula, CA 93060',
    surcharge: true,
    longitude: 34.35168,
    latitude: -119.06686
  },
  {
    zipcode: 93060,
    title: 'BANK OF AMERICA',
    description: '715   E MAIN ST, Santa Paula, CA 93060',
    surcharge: false,
    longitude: 34.35233,
    latitude: -119.06537
  },
  {
    zipcode: 93060,
    title: 'BANK OF AMERICA',
    description: '715   E MAIN ST, Santa Paula, CA 93060',
    surcharge: false,
    longitude: 34.35233,
    latitude: -119.06537
  },
  {
    zipcode: 93060,
    title: 'BANK OF AMERICA',
    description: '715   E MAIN ST, Santa Paula, CA 93060',
    surcharge: false,
    longitude: 34.35233,
    latitude: -119.06537
  },
  {
    zipcode: 93060,
    title: 'RBS WorldPay',
    description: '116   S MILL ST, Santa Paula, CA 93060',
    surcharge: true,
    longitude: 34.35324,
    latitude: -119.06104
  },
  {
    zipcode: 93060,
    title: 'BANK OF THE SIERRA',
    description: '901   E MAIN ST, Santa Paula, CA 93060',
    surcharge: true,
    longitude: 34.35373,
    latitude: -119.06092
  },
  {
    zipcode: 93060,
    title: 'FIS',
    description: '700   E SANTA BARBARA ST, Santa Paula, CA 93060',
    surcharge: true,
    longitude: 34.35385,
    latitude: -119.0661
  },
  {
    zipcode: 93001,
    title: 'RBS WorldPay',
    description: '8646   N VENTURA AVE, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.36817,
    latitude: -119.30651
  },
  {
    zipcode: 93015,
    title: 'FIS',
    description: '1107   W VENTURA ST, Fillmore, CA 93015',
    surcharge: true,
    longitude: 34.37416,
    latitude: -118.93333
  },
  {
    zipcode: 93015,
    title: 'CARDTRONICS',
    description: '704   W VENTURA ST, Fillmore, CA 93015',
    surcharge: true,
    longitude: 34.39356,
    latitude: -118.93604
  },
  {
    zipcode: 93022,
    title: 'RBS WorldPay',
    description: '445    VENTURA AVE, Oak View, CA 93022',
    surcharge: true,
    longitude: 34.39439,
    latitude: -119.29987
  },
  {
    zipcode: 93015,
    title: 'CARDTRONICS',
    description: '903   W VENTURA ST, Fillmore, CA 93015',
    surcharge: true,
    longitude: 34.39583,
    latitude: -118.9201
  },
  {
    zipcode: 93015,
    title: 'CARDTRONICS',
    description: '725   W VENTURA ST, Fillmore, CA 93015',
    surcharge: true,
    longitude: 34.39624,
    latitude: -118.91755
  },
  {
    zipcode: 93015,
    title: 'FIS',
    description: '600   W VENTURA ST, Fillmore, CA 93015',
    surcharge: true,
    longitude: 34.39625,
    latitude: -118.91684
  },
  {
    zipcode: 93015,
    title: 'BANK OF AMERICA',
    description: '606   W VENTURA ST, Fillmore, CA 93015',
    surcharge: false,
    longitude: 34.39625,
    latitude: -118.91684
  },
  {
    zipcode: 93015,
    title: 'WELLS FARGO BANK',
    description: '636   W VENTURA ST, Fillmore, CA 93015',
    surcharge: true,
    longitude: 34.39625,
    latitude: -118.91684
  },
  {
    zipcode: 93015,
    title: 'WELLS FARGO BANK',
    description: '636   W VENTURA ST, Fillmore, CA 93015',
    surcharge: true,
    longitude: 34.39625,
    latitude: -118.91684
  },
  {
    zipcode: 93022,
    title: 'RBS WorldPay',
    description: '690    VENTURA AVE, Oak View, CA 93022',
    surcharge: true,
    longitude: 34.39657,
    latitude: -119.29972
  },
  {
    zipcode: 93015,
    title: 'PULSE NETWORK',
    description: '423   W VENTURA ST, Fillmore, CA 93015',
    surcharge: true,
    longitude: 34.3972,
    latitude: -118.91133
  },
  {
    zipcode: 93022,
    title: 'RBS WorldPay',
    description: '795    VENTURA AVE, Oak View, CA 93022',
    surcharge: true,
    longitude: 34.39802,
    latitude: -119.29982
  },
  {
    zipcode: 93001,
    title: '1ST ISO PROCESSING',
    description: '10552    SANTA ANA RD, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.4003,
    latitude: -119.31511
  },
  {
    zipcode: 93015,
    title: 'UNION BANK',
    description: '566    SESPE AVE, Fillmore, CA 93015',
    surcharge: true,
    longitude: 34.40036,
    latitude: -118.91552
  },
  {
    zipcode: 93015,
    title: 'BANK OF THE SIERRA',
    description: '527    SESPE AVE, Fillmore, CA 93015',
    surcharge: true,
    longitude: 34.4005,
    latitude: -118.91579
  },
  {
    zipcode: 93015,
    title: 'SWITCH COMMERCE INC.',
    description: '117   W VENTURA ST, Fillmore, CA 93015',
    surcharge: true,
    longitude: 34.40065,
    latitude: -118.90804
  },
  {
    zipcode: 93022,
    title: 'FIS',
    description: '905    VENTURA AVE, Oak View, CA 93022',
    surcharge: true,
    longitude: 34.40086,
    latitude: -119.29976
  },
  {
    zipcode: 93023,
    title: 'CARDTRONICS',
    description: '11408   N VENTURA AVE, Ojai, CA 93023',
    surcharge: true,
    longitude: 34.42271,
    latitude: -119.28965
  },
  {
    zipcode: 93023,
    title: 'WELLS FARGO BANK',
    description: '11496   N VENTURA AVE, Ojai, CA 93023',
    surcharge: true,
    longitude: 34.42569,
    latitude: -119.28892
  },
  {
    zipcode: 93023,
    title: 'FIS',
    description: '11496   N VENTURA AVE, Ojai, CA 93023',
    surcharge: true,
    longitude: 34.42569,
    latitude: -119.28892
  },
  {
    zipcode: 93023,
    title: 'CARDTRONICS',
    description: '1125    MARICOPA HWY, Ojai, CA 93023',
    surcharge: false,
    longitude: 34.44171,
    latitude: -119.26196
  },
  {
    zipcode: 93023,
    title: 'CHASE',
    description: '1215    MARICOPA HWY, Ojai, CA 93023',
    surcharge: true,
    longitude: 34.44182,
    latitude: -119.26272
  },
  {
    zipcode: 93023,
    title: 'CHASE',
    description: '1215    MARICOPA HWY, Ojai, CA 93023',
    surcharge: true,
    longitude: 34.44182,
    latitude: -119.26272
  },
  {
    zipcode: 93023,
    title: 'CARDTRONICS',
    description: '360   E OJAI AVE, Ojai, CA 93023',
    surcharge: true,
    longitude: 34.44651,
    latitude: -119.2508
  },
  {
    zipcode: 93023,
    title: 'MONEYPASS',
    description: '110   S VENTURA ST, Ojai, CA 93023',
    surcharge: false,
    longitude: 34.44676,
    latitude: -119.24691
  },
  {
    zipcode: 93023,
    title: 'MONEYPASS',
    description: '402   W OJAI AVE, Ojai, CA 93023',
    surcharge: false,
    longitude: 34.44676,
    latitude: -119.2505
  },
  {
    zipcode: 93023,
    title: 'BANK OF AMERICA',
    description: '205   W OJAI AVE, Ojai, CA 93023',
    surcharge: false,
    longitude: 34.44774,
    latitude: -119.24581
  },
  {
    zipcode: 93023,
    title: 'BANK OF AMERICA',
    description: '205   W OJAI AVE, Ojai, CA 93023',
    surcharge: false,
    longitude: 34.44774,
    latitude: -119.24581
  },
  {
    zipcode: 93023,
    title: 'SWITCH COMMERCE INC.',
    description: '616   E OJAI AVE, Ojai, CA 93023',
    surcharge: true,
    longitude: 34.44827,
    latitude: -119.24056
  },
  {
    zipcode: 93023,
    title: 'WELLS FARGO BANK',
    description: '202   E MATILIJA ST, Ojai, CA 93023',
    surcharge: true,
    longitude: 34.44892,
    latitude: -119.24491
  },
  {
    zipcode: 93023,
    title: 'WELLS FARGO BANK',
    description: '202   E MATILIJA ST, Ojai, CA 93023',
    surcharge: true,
    longitude: 34.44892,
    latitude: -119.24491
  },
  {
    zipcode: 94134,
    title: 'PULSE NETWORK',
    description: '2600    BAY SHORE BLVD, San Francisco, CA 94134',
    surcharge: true,
    longitude: 37.70828,
    latitude: -122.4055
  },
  {
    zipcode: 94134,
    title: 'RBS WorldPay',
    description: '2203    GENEVA AVE, San Francisco, CA 94134',
    surcharge: true,
    longitude: 37.70838,
    latitude: -122.41925
  },
  {
    zipcode: 94134,
    title: 'PULSE NETWORK',
    description: '2145    GENEVA AVE, San Francisco, CA 94134',
    surcharge: true,
    longitude: 37.70865,
    latitude: -122.42076
  },
  {
    zipcode: 94112,
    title: 'CARDTRONICS',
    description: '5898    MISSION ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.70914,
    latitude: -122.45195
  },
  {
    zipcode: 94112,
    title: 'CARDTRONICS',
    description: '3080    SAN JOSE AVE, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.70952,
    latitude: -122.45782
  },
  {
    zipcode: 94132,
    title: 'CHASE',
    description: '3981    ALEMANY BLVD, San Francisco, CA 94132',
    surcharge: true,
    longitude: 37.71059,
    latitude: -122.46897
  },
  {
    zipcode: 94132,
    title: 'CHASE',
    description: '3981    ALEMANY BLVD, San Francisco, CA 94132',
    surcharge: true,
    longitude: 37.71059,
    latitude: -122.46897
  },
  {
    zipcode: 94134,
    title: 'BANK OF AMERICA',
    description: '6    LELAND AVE, San Francisco, CA 94134',
    surcharge: false,
    longitude: 37.7113,
    latitude: -122.40373
  },
  {
    zipcode: 94134,
    title: 'BANK OF AMERICA',
    description: '6    LELAND AVE, San Francisco, CA 94134',
    surcharge: false,
    longitude: 37.7113,
    latitude: -122.40373
  },
  {
    zipcode: 94134,
    title: 'PULSE NETWORK',
    description: '1450    SUNNYDALE AVE, San Francisco, CA 94134',
    surcharge: true,
    longitude: 37.71182,
    latitude: -122.41533
  },
  {
    zipcode: 94112,
    title: 'CARDTRONICS',
    description: '2998    SAN JOSE AVE, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.71194,
    latitude: -122.45517
  },
  {
    zipcode: 94112,
    title: 'RBS WorldPay',
    description: '5501    MISSION ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.71201,
    latitude: -122.44525
  },
  {
    zipcode: 94134,
    title: 'CARDTRONICS',
    description: '2200    BAY SHORE BLVD, San Francisco, CA 94134',
    surcharge: true,
    longitude: 37.71222,
    latitude: -122.40283
  },
  {
    zipcode: 94112,
    title: 'RBS WorldPay',
    description: '5488    MISSION ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.71289,
    latitude: -122.44458
  },
  {
    zipcode: 94112,
    title: 'RBS WorldPay',
    description: '105    BROAD ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.71309,
    latitude: -122.4575
  },
  {
    zipcode: 94132,
    title: 'PULSE NETWORK',
    description: '295    ORIZABA AVE, San Francisco, CA 94132',
    surcharge: true,
    longitude: 37.71349,
    latitude: -122.46265
  },
  {
    zipcode: 94112,
    title: 'PULSE NETWORK',
    description: '1231    GENEVA AVE, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.71391,
    latitude: -122.4353
  },
  {
    zipcode: 94112,
    title: 'PULSE NETWORK',
    description: '5201    MISSION ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.71501,
    latitude: -122.44207
  },
  {
    zipcode: 94112,
    title: 'RBS WorldPay',
    description: '5229    MISSION ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.71501,
    latitude: -122.44207
  },
  {
    zipcode: 94112,
    title: 'CARDTRONICS',
    description: '965    GENEVA AVE, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.71602,
    latitude: -122.43988
  },
  {
    zipcode: 94112,
    title: 'BANK OF AMERICA',
    description: '5150    MISSION ST, San Francisco, CA 94112',
    surcharge: false,
    longitude: 37.71615,
    latitude: -122.44136
  },
  {
    zipcode: 94112,
    title: 'BANK OF AMERICA',
    description: '5150    MISSION ST, San Francisco, CA 94112',
    surcharge: false,
    longitude: 37.71615,
    latitude: -122.44136
  },
  {
    zipcode: 94112,
    title: 'PULSE NETWORK',
    description: '901    GENEVA AVE, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.71627,
    latitude: -122.44044
  },
  {
    zipcode: 94112,
    title: 'WELLS FARGO BANK',
    description: '901 # 921  GENEVA AVE, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.71627,
    latitude: -122.44044
  },
  {
    zipcode: 94132,
    title: 'PULSE NETWORK',
    description: '111    CAMBON DR, San Francisco, CA 94132',
    surcharge: true,
    longitude: 37.717,
    latitude: -122.4742
  },
  {
    zipcode: 94112,
    title: 'FIS',
    description: '5090    MISSION ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.71707,
    latitude: -122.44065
  },
  {
    zipcode: 94112,
    title: 'RBS WorldPay',
    description: '5098    MISSION ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.71707,
    latitude: -122.44065
  },
  {
    zipcode: 94132,
    title: 'WELLS FARGO BANK',
    description: '35    CAMBON DR, San Francisco, CA 94132',
    surcharge: true,
    longitude: 37.71799,
    latitude: -122.47437
  },
  {
    zipcode: 94132,
    title: 'FIS',
    description: '57    CAMBON DR, San Francisco, CA 94132',
    surcharge: true,
    longitude: 37.71799,
    latitude: -122.47437
  },
  {
    zipcode: 94132,
    title: 'PULSE NETWORK',
    description: '1101    JUNIPERO SERRA BLVD, San Francisco, CA 94132',
    surcharge: true,
    longitude: 37.71882,
    latitude: -122.47229
  },
  {
    zipcode: 94112,
    title: 'CARDTRONICS',
    description: '4950    MISSION ST, San Francisco, CA 94112',
    surcharge: false,
    longitude: 37.71885,
    latitude: -122.43936
  },
  {
    zipcode: 94132,
    title: 'WELLS FARGO BANK',
    description: '1650    HOLLOWAY AVE, San Francisco, CA 94132',
    surcharge: true,
    longitude: 37.72093,
    latitude: -122.4766
  },
  {
    zipcode: 94132,
    title: 'WELLS FARGO BANK',
    description: '1650    HOLLOWAY AVE, San Francisco, CA 94132',
    surcharge: true,
    longitude: 37.72093,
    latitude: -122.4766
  },
  {
    zipcode: 94132,
    title: 'BANK OF AMERICA',
    description: '1650    HOLLOWAY AVE, San Francisco, CA 94132',
    surcharge: false,
    longitude: 37.72093,
    latitude: -122.4766
  },
  {
    zipcode: 94132,
    title: 'BANK OF AMERICA',
    description: '1650    HOLLOWAY AVE, San Francisco, CA 94132',
    surcharge: false,
    longitude: 37.72093,
    latitude: -122.4766
  },
  {
    zipcode: 94112,
    title: 'FIS',
    description: '4837    MISSION ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.72108,
    latitude: -122.43741
  },
  {
    zipcode: 94112,
    title: 'PULSE NETWORK',
    description: '2275    SAN JOSE AVE, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.72125,
    latitude: -122.44604
  },
  {
    zipcode: 94124,
    title: 'RBS WorldPay',
    description: '6275    3RD ST, San Francisco, CA 94124',
    surcharge: true,
    longitude: 37.72126,
    latitude: -122.39598
  },
  {
    zipcode: 94124,
    title: 'FIS',
    description: '2830    INGALLS ST, San Francisco, CA 94124',
    surcharge: true,
    longitude: 37.72154,
    latitude: -122.39091
  },
  {
    zipcode: 94112,
    title: 'PULSE NETWORK',
    description: '845    HOLLOWAY AVE, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.72173,
    latitude: -122.46154
  },
  {
    zipcode: 94112,
    title: 'RBS WorldPay',
    description: '150    HOLLOWAY AVE, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.72194,
    latitude: -122.45438
  },
  {
    zipcode: 94112,
    title: 'FIS',
    description: '4701    MISSION ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.72228,
    latitude: -122.43649
  },
  {
    zipcode: 94124,
    title: 'FIS',
    description: '1300    FITZGERALD AVE, San Francisco, CA 94124',
    surcharge: true,
    longitude: 37.72233,
    latitude: -122.39351
  },
  {
    zipcode: 94132,
    title: 'CARDTRONICS',
    description: '750    FONT BLVD, San Francisco, CA 94132',
    surcharge: true,
    longitude: 37.72246,
    latitude: -122.48289
  },
  {
    zipcode: 94132,
    title: 'MONEYPASS',
    description: '750 BLDG C  FONT BLVD, San Francisco, CA 94132',
    surcharge: false,
    longitude: 37.72246,
    latitude: -122.48289
  },
  {
    zipcode: 94112,
    title: 'RBS WorldPay',
    description: '999    OCEAN AVE, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.72304,
    latitude: -122.45275
  },
  {
    zipcode: 94112,
    title: 'RBS WorldPay',
    description: '1015    OCEAN AVE, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.72319,
    latitude: -122.45344
  },
  {
    zipcode: 94112,
    title: 'FIS',
    description: '1039    OCEAN AVE, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.72319,
    latitude: -122.45344
  },
  {
    zipcode: 94134,
    title: 'BANK OF THE WEST',
    description: '2675    SAN BRUNO AVE, San Francisco, CA 94134',
    surcharge: false,
    longitude: 37.72341,
    latitude: -122.40175
  },
  {
    zipcode: 94134,
    title: 'BANK OF THE WEST',
    description: '2675    SAN BRUNO AVE, San Francisco, CA 94134',
    surcharge: false,
    longitude: 37.72341,
    latitude: -122.40175
  },
  {
    zipcode: 94134,
    title: 'PULSE NETWORK',
    description: '2695    SAN BRUNO AVE, San Francisco, CA 94134',
    surcharge: true,
    longitude: 37.72341,
    latitude: -122.40175
  },
  {
    zipcode: 94134,
    title: 'PULSE NETWORK',
    description: '3004    SAN BRUNO AVE, San Francisco, CA 94134',
    surcharge: true,
    longitude: 37.72341,
    latitude: -122.40195
  },
  {
    zipcode: 94112,
    title: 'CARDTRONICS',
    description: '4645    MISSION ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.7236,
    latitude: -122.4355
  },
  {
    zipcode: 94112,
    title: 'CHASE',
    description: '4669    MISSION ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.7236,
    latitude: -122.4355
  },
  {
    zipcode: 94112,
    title: 'CHASE',
    description: '4669    MISSION ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.7236,
    latitude: -122.4355
  },
  {
    zipcode: 94112,
    title: 'CHASE',
    description: '4669    MISSION ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.7236,
    latitude: -122.4355
  },
  {
    zipcode: 94112,
    title: 'BANK OF AMERICA',
    description: '15    OCEAN AVE, San Francisco, CA 94112',
    surcharge: false,
    longitude: 37.72376,
    latitude: -122.43587
  },
  {
    zipcode: 94112,
    title: 'BANK OF AMERICA',
    description: '15    OCEAN AVE, San Francisco, CA 94112',
    surcharge: false,
    longitude: 37.72376,
    latitude: -122.43587
  },
  {
    zipcode: 94112,
    title: 'BANK OF AMERICA',
    description: '15    OCEAN AVE, San Francisco, CA 94112',
    surcharge: false,
    longitude: 37.72376,
    latitude: -122.43587
  },
  {
    zipcode: 94134,
    title: 'BANK OF AMERICA',
    description: '2485    SAN BRUNO AVE, San Francisco, CA 94134',
    surcharge: false,
    longitude: 37.72389,
    latitude: -122.40195
  },
  {
    zipcode: 94134,
    title: 'BANK OF AMERICA',
    description: '2485    SAN BRUNO AVE, San Francisco, CA 94134',
    surcharge: false,
    longitude: 37.72389,
    latitude: -122.40195
  },
  {
    zipcode: 94112,
    title: 'RBS WorldPay',
    description: '544    EXCELSIOR AVE, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.72411,
    latitude: -122.42939
  },
  {
    zipcode: 94112,
    title: 'CITIBANK',
    description: '4638    MISSION ST, San Francisco, CA 94112',
    surcharge: false,
    longitude: 37.72424,
    latitude: -122.43524
  },
  {
    zipcode: 94112,
    title: 'CITIBANK',
    description: '4638    MISSION ST, San Francisco, CA 94112',
    surcharge: false,
    longitude: 37.72424,
    latitude: -122.43524
  },
  {
    zipcode: 94112,
    title: 'WELLS FARGO BANK',
    description: '4648    MISSION ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.72424,
    latitude: -122.43524
  },
  {
    zipcode: 94112,
    title: 'WELLS FARGO BANK',
    description: '4648    MISSION ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.72424,
    latitude: -122.43524
  },
  {
    zipcode: 94112,
    title: 'WELLS FARGO BANK',
    description: '4648    MISSION ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.72424,
    latitude: -122.43524
  },
  {
    zipcode: 94112,
    title: 'RBS WorldPay',
    description: '1501    OCEAN AVE, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.72427,
    latitude: -122.45857
  },
  {
    zipcode: 94112,
    title: 'RBS WorldPay',
    description: '1521    OCEAN AVE, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.72427,
    latitude: -122.45857
  },
  {
    zipcode: 94112,
    title: 'WELLS FARGO BANK',
    description: '50    PHELAN AVE, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.72432,
    latitude: -122.45225
  },
  {
    zipcode: 94112,
    title: 'WELLS FARGO BANK',
    description: '50    PHELAN AVE, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.72432,
    latitude: -122.45225
  },
  {
    zipcode: 94112,
    title: 'MONEYPASS',
    description: '4610    MISSION ST, San Francisco, CA 94112',
    surcharge: false,
    longitude: 37.72448,
    latitude: -122.43506
  },
  {
    zipcode: 94112,
    title: 'CHASE',
    description: '1649    OCEAN AVE, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.7245,
    latitude: -122.45964
  },
  {
    zipcode: 94112,
    title: 'CHASE',
    description: '1649    OCEAN AVE, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.7245,
    latitude: -122.45964
  },
  {
    zipcode: 94112,
    title: 'BANK OF AMERICA',
    description: '1649    OCEAN AVE, San Francisco, CA 94112',
    surcharge: false,
    longitude: 37.7245,
    latitude: -122.45964
  },
  {
    zipcode: 94112,
    title: 'BANK OF AMERICA',
    description: '1649    OCEAN AVE, San Francisco, CA 94112',
    surcharge: false,
    longitude: 37.7245,
    latitude: -122.45964
  },
  {
    zipcode: 94112,
    title: 'RBS WorldPay',
    description: '1799    OCEAN AVE, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.72468,
    latitude: -122.46051
  },
  {
    zipcode: 94112,
    title: 'CARDTRONICS',
    description: '1760    OCEAN AVE, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.72482,
    latitude: -122.46005
  },
  {
    zipcode: 94134,
    title: 'RBS WorldPay',
    description: '2985    SAN BRUNO AVE, San Francisco, CA 94134',
    surcharge: true,
    longitude: 37.72518,
    latitude: -122.40248
  },
  {
    zipcode: 94112,
    title: 'CARDTRONICS',
    description: '1830    OCEAN AVE, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.72521,
    latitude: -122.46164
  },
  {
    zipcode: 94112,
    title: 'PULSE NETWORK',
    description: '4501    MISSION ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.72547,
    latitude: -122.43408
  },
  {
    zipcode: 94134,
    title: 'PULSE NETWORK',
    description: '2890    SAN BRUNO AVE, San Francisco, CA 94134',
    surcharge: true,
    longitude: 37.72581,
    latitude: -122.40293
  },
  {
    zipcode: 94127,
    title: 'CARDTRONICS',
    description: '2000    OCEAN AVE, San Francisco, CA 94127',
    surcharge: true,
    longitude: 37.72643,
    latitude: -122.46499
  },
  {
    zipcode: 94112,
    title: 'RBS WorldPay',
    description: '4499    MISSION ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.72665,
    latitude: -122.43319
  },
  {
    zipcode: 94132,
    title: 'BANK OF AMERICA',
    description: '245    WINSTON DR, San Francisco, CA 94132',
    surcharge: false,
    longitude: 37.72689,
    latitude: -122.4757
  },
  {
    zipcode: 94132,
    title: 'BANK OF AMERICA',
    description: '245    WINSTON DR, San Francisco, CA 94132',
    surcharge: false,
    longitude: 37.72689,
    latitude: -122.4757
  },
  {
    zipcode: 94132,
    title: 'BANK OF AMERICA',
    description: '245    WINSTON DR, San Francisco, CA 94132',
    surcharge: false,
    longitude: 37.72689,
    latitude: -122.4757
  },
  {
    zipcode: 94132,
    title: 'CHASE',
    description: '265    WINSTON DR, San Francisco, CA 94132',
    surcharge: true,
    longitude: 37.72689,
    latitude: -122.4757
  },
  {
    zipcode: 94132,
    title: 'CHASE',
    description: '265    WINSTON DR, San Francisco, CA 94132',
    surcharge: true,
    longitude: 37.72689,
    latitude: -122.4757
  },
  {
    zipcode: 94134,
    title: 'RBS WorldPay',
    description: '153    BACON ST, San Francisco, CA 94134',
    surcharge: true,
    longitude: 37.72742,
    latitude: -122.40404
  },
  {
    zipcode: 94112,
    title: 'PULSE NETWORK',
    description: '4300    MISSION ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.72782,
    latitude: -122.43238
  },
  {
    zipcode: 94112,
    title: 'PULSE NETWORK',
    description: '4304    MISSION ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.72782,
    latitude: -122.43238
  },
  {
    zipcode: 94132,
    title: 'CARDTRONICS',
    description: '3251    20TH AVE, San Francisco, CA 94132',
    surcharge: true,
    longitude: 37.72807,
    latitude: -122.47559
  },
  {
    zipcode: 94132,
    title: 'CARDTRONICS',
    description: '3251    20TH AVE, San Francisco, CA 94132',
    surcharge: true,
    longitude: 37.72807,
    latitude: -122.47559
  },
  {
    zipcode: 94132,
    title: 'CARDTRONICS',
    description: '3251    20TH AVE, San Francisco, CA 94132',
    surcharge: true,
    longitude: 37.72807,
    latitude: -122.47559
  },
  {
    zipcode: 94134,
    title: 'FIS',
    description: '2698    SAN BRUNO AVE, San Francisco, CA 94134',
    surcharge: true,
    longitude: 37.72809,
    latitude: -122.40388
  },
  {
    zipcode: 94132,
    title: 'WELLS FARGO BANK',
    description: '599    BUCKINGHAM WAY, San Francisco, CA 94132',
    surcharge: true,
    longitude: 37.72828,
    latitude: -122.47874
  },
  {
    zipcode: 94132,
    title: 'WELLS FARGO BANK',
    description: '599    BUCKINGHAM WAY, San Francisco, CA 94132',
    surcharge: true,
    longitude: 37.72828,
    latitude: -122.47874
  },
  {
    zipcode: 94132,
    title: 'WELLS FARGO BANK',
    description: '599    BUCKINGHAM WAY, San Francisco, CA 94132',
    surcharge: true,
    longitude: 37.72828,
    latitude: -122.47874
  },
  {
    zipcode: 94112,
    title: 'PULSE NETWORK',
    description: '499    SILVER AVE, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.72867,
    latitude: -122.42707
  },
  {
    zipcode: 94124,
    title: 'RBS WorldPay',
    description: '1499    THOMAS AVE, San Francisco, CA 94124',
    surcharge: true,
    longitude: 37.72875,
    latitude: -122.38854
  },
  {
    zipcode: 94134,
    title: 'RBS WorldPay',
    description: '790    SILVER AVE, San Francisco, CA 94134',
    surcharge: true,
    longitude: 37.72888,
    latitude: -122.42006
  },
  {
    zipcode: 94124,
    title: 'CARDTRONICS',
    description: '5300    3RD ST, San Francisco, CA 94124',
    surcharge: true,
    longitude: 37.72927,
    latitude: -122.39274
  },
  {
    zipcode: 94112,
    title: 'PULSE NETWORK',
    description: '4298    MISSION ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.72928,
    latitude: -122.43088
  },
  {
    zipcode: 94112,
    title: 'PULSE NETWORK',
    description: '4199    MISSION ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.72984,
    latitude: -122.43007
  },
  {
    zipcode: 94132,
    title: 'CITIBANK',
    description: '3146    20TH AVE, San Francisco, CA 94132',
    surcharge: false,
    longitude: 37.73031,
    latitude: -122.47584
  },
  {
    zipcode: 94127,
    title: 'CITIBANK',
    description: '2499    OCEAN AVE, San Francisco, CA 94127',
    surcharge: false,
    longitude: 37.73041,
    latitude: -122.47069
  },
  {
    zipcode: 94127,
    title: 'CITIBANK',
    description: '2499    OCEAN AVE, San Francisco, CA 94127',
    surcharge: false,
    longitude: 37.73041,
    latitude: -122.47069
  },
  {
    zipcode: 94124,
    title: 'RBS WorldPay',
    description: '2190    CARROLL AVE, San Francisco, CA 94124',
    surcharge: true,
    longitude: 37.7307,
    latitude: -122.40329
  },
  {
    zipcode: 94134,
    title: 'CARDTRONICS',
    description: '2494    SAN BRUNO AVE, San Francisco, CA 94134',
    surcharge: true,
    longitude: 37.73076,
    latitude: -122.40498
  },
  {
    zipcode: 94124,
    title: 'RBS WorldPay',
    description: '5201    3RD ST, San Francisco, CA 94124',
    surcharge: true,
    longitude: 37.7312,
    latitude: -122.39179
  },
  {
    zipcode: 94127,
    title: 'RBS WorldPay',
    description: '600    MONTEREY BLVD, San Francisco, CA 94127',
    surcharge: true,
    longitude: 37.73166,
    latitude: -122.45097
  },
  {
    zipcode: 94134,
    title: 'FIS',
    description: '2400    SAN BRUNO AVE, San Francisco, CA 94134',
    surcharge: true,
    longitude: 37.7317,
    latitude: -122.40538
  },
  {
    zipcode: 94132,
    title: 'BANK OF THE WEST',
    description: '2606    OCEAN AVE, San Francisco, CA 94132',
    surcharge: false,
    longitude: 37.73195,
    latitude: -122.47361
  },
  {
    zipcode: 94132,
    title: 'MONEYPASS',
    description: '2656    OCEAN AVE, San Francisco, CA 94132',
    surcharge: false,
    longitude: 37.73195,
    latitude: -122.47361
  },
  {
    zipcode: 94124,
    title: 'PULSE NETWORK',
    description: '975    BAY SHORE BLVD, San Francisco, CA 94124',
    surcharge: true,
    longitude: 37.73228,
    latitude: -122.40421
  },
  {
    zipcode: 94124,
    title: 'RBS WorldPay',
    description: '5001    3RD ST, San Francisco, CA 94124',
    surcharge: true,
    longitude: 37.73318,
    latitude: -122.39115
  },
  {
    zipcode: 94124,
    title: 'RBS WorldPay',
    description: '5001    3RD ST, San Francisco, CA 94124',
    surcharge: true,
    longitude: 37.73318,
    latitude: -122.39115
  },
  {
    zipcode: 94124,
    title: 'BANK OF AMERICA',
    description: '5000    3RD ST, San Francisco, CA 94124',
    surcharge: false,
    longitude: 37.73324,
    latitude: -122.39133
  },
  {
    zipcode: 94134,
    title: 'PULSE NETWORK',
    description: '2380    SAN BRUNO AVE, San Francisco, CA 94134',
    surcharge: true,
    longitude: 37.73354,
    latitude: -122.40634
  },
  {
    zipcode: 94124,
    title: 'RBS WorldPay',
    description: '4919    3RD ST, San Francisco, CA 94124',
    surcharge: true,
    longitude: 37.73383,
    latitude: -122.39087
  },
  {
    zipcode: 94131,
    title: 'WELLS FARGO BANK',
    description: '2815    DIAMOND ST, San Francisco, CA 94131',
    surcharge: true,
    longitude: 37.7339,
    latitude: -122.43395
  },
  {
    zipcode: 94131,
    title: 'CITIBANK',
    description: '2895    DIAMOND ST, San Francisco, CA 94131',
    surcharge: false,
    longitude: 37.7339,
    latitude: -122.43395
  },
  {
    zipcode: 94132,
    title: 'BANK OF AMERICA',
    description: '1515    SLOAT BLVD, San Francisco, CA 94132',
    surcharge: false,
    longitude: 37.73397,
    latitude: -122.48847
  },
  {
    zipcode: 94132,
    title: 'BANK OF AMERICA',
    description: '1515    SLOAT BLVD, San Francisco, CA 94132',
    surcharge: false,
    longitude: 37.73397,
    latitude: -122.48847
  },
  {
    zipcode: 94132,
    title: 'WELLS FARGO BANK',
    description: '1595    SLOAT BLVD, San Francisco, CA 94132',
    surcharge: true,
    longitude: 37.73397,
    latitude: -122.48847
  },
  {
    zipcode: 94132,
    title: 'WELLS FARGO BANK',
    description: '1595    SLOAT BLVD, San Francisco, CA 94132',
    surcharge: true,
    longitude: 37.73397,
    latitude: -122.48847
  },
  {
    zipcode: 94132,
    title: 'WELLS FARGO BANK',
    description: '1595    SLOAT BLVD, San Francisco, CA 94132',
    surcharge: true,
    longitude: 37.73397,
    latitude: -122.48847
  },
  {
    zipcode: 94131,
    title: 'BANK OF AMERICA',
    description: '2810    DIAMOND ST, San Francisco, CA 94131',
    surcharge: false,
    longitude: 37.73427,
    latitude: -122.43403
  },
  {
    zipcode: 94131,
    title: 'BANK OF AMERICA',
    description: '2810    DIAMOND ST, San Francisco, CA 94131',
    surcharge: false,
    longitude: 37.73427,
    latitude: -122.43403
  },
  {
    zipcode: 94131,
    title: 'PULSE NETWORK',
    description: '696    CHENERY ST, San Francisco, CA 94131',
    surcharge: true,
    longitude: 37.73459,
    latitude: -122.43332
  },
  {
    zipcode: 94124,
    title: 'RBS WorldPay',
    description: '4700    3RD ST, San Francisco, CA 94124',
    surcharge: true,
    longitude: 37.73543,
    latitude: -122.39063
  },
  {
    zipcode: 94116,
    title: 'FIS',
    description: '2560    SLOAT BLVD, San Francisco, CA 94116',
    surcharge: true,
    longitude: 37.73545,
    latitude: -122.50125
  },
  {
    zipcode: 94110,
    title: 'RBS WorldPay',
    description: '648    ANDOVER ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.73594,
    latitude: -122.41682
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '3798    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.73634,
    latitude: -122.42446
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '3701    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.73688,
    latitude: -122.42408
  },
  {
    zipcode: 94110,
    title: 'RBS WorldPay',
    description: '3717    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.73688,
    latitude: -122.42408
  },
  {
    zipcode: 94107,
    title: 'FIS',
    description: '4517    3RD ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.73699,
    latitude: -122.38976
  },
  {
    zipcode: 94127,
    title: 'FIRST REPUBLIC BANK',
    description: '279    WEST PORTAL AVE, San Francisco, CA 94127',
    surcharge: true,
    longitude: 37.73844,
    latitude: -122.46831
  },
  {
    zipcode: 94127,
    title: 'BANK OF AMERICA',
    description: '288    WEST PORTAL AVE, San Francisco, CA 94127',
    surcharge: false,
    longitude: 37.73856,
    latitude: -122.46856
  },
  {
    zipcode: 94127,
    title: 'BANK OF AMERICA',
    description: '288    WEST PORTAL AVE, San Francisco, CA 94127',
    surcharge: false,
    longitude: 37.73856,
    latitude: -122.46856
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '820    CORTLAND AVE, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.7388,
    latitude: -122.41442
  },
  {
    zipcode: 94127,
    title: 'WELLS FARGO BANK',
    description: '145    WEST PORTAL AVE, San Francisco, CA 94127',
    surcharge: true,
    longitude: 37.73924,
    latitude: -122.46737
  },
  {
    zipcode: 94127,
    title: 'WELLS FARGO BANK',
    description: '145    WEST PORTAL AVE, San Francisco, CA 94127',
    surcharge: true,
    longitude: 37.73924,
    latitude: -122.46737
  },
  {
    zipcode: 94127,
    title: 'WELLS FARGO BANK',
    description: '145    WEST PORTAL AVE, San Francisco, CA 94127',
    surcharge: true,
    longitude: 37.73924,
    latitude: -122.46737
  },
  {
    zipcode: 94110,
    title: 'BANK OF AMERICA',
    description: '433    CORTLAND AVE, San Francisco, CA 94110',
    surcharge: false,
    longitude: 37.73924,
    latitude: -122.41748
  },
  {
    zipcode: 94110,
    title: 'BANK OF AMERICA',
    description: '433    CORTLAND AVE, San Francisco, CA 94110',
    surcharge: false,
    longitude: 37.73924,
    latitude: -122.41748
  },
  {
    zipcode: 94127,
    title: 'CITIBANK',
    description: '130    WEST PORTAL AVE, San Francisco, CA 94127',
    surcharge: false,
    longitude: 37.73937,
    latitude: -122.46759
  },
  {
    zipcode: 94127,
    title: 'CITIBANK',
    description: '130    WEST PORTAL AVE, San Francisco, CA 94127',
    surcharge: false,
    longitude: 37.73937,
    latitude: -122.46759
  },
  {
    zipcode: 94127,
    title: 'CHASE',
    description: '98    WEST PORTAL AVE, San Francisco, CA 94127',
    surcharge: true,
    longitude: 37.73998,
    latitude: -122.46687
  },
  {
    zipcode: 94127,
    title: 'CHASE',
    description: '98    WEST PORTAL AVE, San Francisco, CA 94127',
    surcharge: true,
    longitude: 37.73998,
    latitude: -122.46687
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '3550    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.7403,
    latitude: -122.42341
  },
  {
    zipcode: 94124,
    title: 'SWITCH COMMERCE INC.',
    description: '300    BAY SHORE BLVD, San Francisco, CA 94124',
    surcharge: true,
    longitude: 37.74123,
    latitude: -122.40674
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '3499    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.74133,
    latitude: -122.42253
  },
  {
    zipcode: 94116,
    title: 'CARDTRONICS',
    description: '3001    TARAVAL ST, San Francisco, CA 94116',
    surcharge: true,
    longitude: 37.74194,
    latitude: -122.49855
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '3400    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.74196,
    latitude: -122.42234
  },
  {
    zipcode: 94116,
    title: 'PULSE NETWORK',
    description: '3350    TARAVAL ST, San Francisco, CA 94116',
    surcharge: true,
    longitude: 37.74197,
    latitude: -122.50189
  },
  {
    zipcode: 94124,
    title: 'PULSE NETWORK',
    description: '319    BAY SHORE BLVD, San Francisco, CA 94124',
    surcharge: true,
    longitude: 37.74222,
    latitude: -122.40564
  },
  {
    zipcode: 94116,
    title: 'FIS',
    description: '2139    TARAVAL ST, San Francisco, CA 94116',
    surcharge: true,
    longitude: 37.74238,
    latitude: -122.48878
  },
  {
    zipcode: 94116,
    title: 'FIS',
    description: '2139    TARAVAL ST, San Francisco, CA 94116',
    surcharge: true,
    longitude: 37.74238,
    latitude: -122.48878
  },
  {
    zipcode: 94116,
    title: 'CARDTRONICS',
    description: '2222    TARAVAL ST, San Francisco, CA 94116',
    surcharge: true,
    longitude: 37.7425,
    latitude: -122.49006
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '3391    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.74264,
    latitude: -122.42168
  },
  {
    zipcode: 94124,
    title: 'WELLS FARGO BANK',
    description: '3801 STE 116  3RD ST, San Francisco, CA 94124',
    surcharge: true,
    longitude: 37.74266,
    latitude: -122.38783
  },
  {
    zipcode: 94124,
    title: 'WELLS FARGO BANK',
    description: '3801 STE 116  3RD ST, San Francisco, CA 94124',
    surcharge: true,
    longitude: 37.74266,
    latitude: -122.38783
  },
  {
    zipcode: 94116,
    title: 'CARDTRONICS',
    description: '1201    TARAVAL ST, San Francisco, CA 94116',
    surcharge: true,
    longitude: 37.7428,
    latitude: -122.4792
  },
  {
    zipcode: 94116,
    title: 'BANK OF AMERICA',
    description: '1007    TARAVAL ST, San Francisco, CA 94116',
    surcharge: false,
    longitude: 37.74289,
    latitude: -122.47719
  },
  {
    zipcode: 94116,
    title: 'BANK OF AMERICA',
    description: '1007    TARAVAL ST, San Francisco, CA 94116',
    surcharge: false,
    longitude: 37.74289,
    latitude: -122.47719
  },
  {
    zipcode: 94116,
    title: 'CITIBANK',
    description: '2400    19TH AVE, San Francisco, CA 94116',
    surcharge: false,
    longitude: 37.74304,
    latitude: -122.47554
  },
  {
    zipcode: 94116,
    title: 'CITIBANK',
    description: '2400    19TH AVE, San Francisco, CA 94116',
    surcharge: false,
    longitude: 37.74304,
    latitude: -122.47554
  },
  {
    zipcode: 94116,
    title: 'FIRST BANK',
    description: '1000    TARAVAL ST, San Francisco, CA 94116',
    surcharge: false,
    longitude: 37.74307,
    latitude: -122.47707
  },
  {
    zipcode: 94116,
    title: 'CHASE',
    description: '926    TARAVAL ST, San Francisco, CA 94116',
    surcharge: true,
    longitude: 37.74311,
    latitude: -122.47621
  },
  {
    zipcode: 94116,
    title: 'WELLS FARGO BANK',
    description: '730    TARAVAL ST, San Francisco, CA 94116',
    surcharge: true,
    longitude: 37.74321,
    latitude: -122.47388
  },
  {
    zipcode: 94109,
    title: 'SWITCH COMMERCE INC.',
    description: '3346    MISSION ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.74348,
    latitude: -122.42136
  },
  {
    zipcode: 94110,
    title: 'WELLS FARGO BANK',
    description: '3350    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.74348,
    latitude: -122.42136
  },
  {
    zipcode: 94110,
    title: 'WELLS FARGO BANK',
    description: '3350    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.74348,
    latitude: -122.42136
  },
  {
    zipcode: 94110,
    title: 'CARDTRONICS',
    description: '3398    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.74348,
    latitude: -122.42136
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '78    29TH ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.74404,
    latitude: -122.42244
  },
  {
    zipcode: 94127,
    title: 'PULSE NETWORK',
    description: '755    PORTOLA DR, San Francisco, CA 94127',
    surcharge: true,
    longitude: 37.74426,
    latitude: -122.4536
  },
  {
    zipcode: 94131,
    title: 'BANK OF AMERICA',
    description: '5268    DIAMOND HEIGHTS BLVD, San Francisco, CA 94131',
    surcharge: false,
    longitude: 37.74456,
    latitude: -122.43962
  },
  {
    zipcode: 94131,
    title: 'BANK OF AMERICA',
    description: '5268    DIAMOND HEIGHTS BLVD, San Francisco, CA 94131',
    surcharge: false,
    longitude: 37.74456,
    latitude: -122.43962
  },
  {
    zipcode: 94131,
    title: 'CARDTRONICS',
    description: '5290    DIAMOND HEIGHTS BLVD, San Francisco, CA 94131',
    surcharge: false,
    longitude: 37.74456,
    latitude: -122.43962
  },
  {
    zipcode: 94124,
    title: 'FIS',
    description: '150    TOLAND ST, San Francisco, CA 94124',
    surcharge: true,
    longitude: 37.74458,
    latitude: -122.39842
  },
  {
    zipcode: 94112,
    title: 'PULSE NETWORK',
    description: '3211    MISSION ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.74463,
    latitude: -122.42039
  },
  {
    zipcode: 94124,
    title: 'RBS WorldPay',
    description: '101    BAY SHORE BLVD, San Francisco, CA 94124',
    surcharge: true,
    longitude: 37.74485,
    latitude: -122.40355
  },
  {
    zipcode: 94110,
    title: 'BANK OF AMERICA',
    description: '3250    MISSION ST, San Francisco, CA 94110',
    surcharge: false,
    longitude: 37.74507,
    latitude: -122.42032
  },
  {
    zipcode: 94110,
    title: 'BANK OF AMERICA',
    description: '3250    MISSION ST, San Francisco, CA 94110',
    surcharge: false,
    longitude: 37.74507,
    latitude: -122.42032
  },
  {
    zipcode: 94131,
    title: 'RBS WorldPay',
    description: '598    PORTOLA DR, San Francisco, CA 94131',
    surcharge: true,
    longitude: 37.74557,
    latitude: -122.4517
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '35    PRECITA AVE, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.74684,
    latitude: -122.4189
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '580    PRECITA AVE, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.7472,
    latitude: -122.41011
  },
  {
    zipcode: 94110,
    title: 'CARDTRONICS',
    description: '3400    CESAR CHAVEZ, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.74819,
    latitude: -122.41855
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '3000    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.74883,
    latitude: -122.4182
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '3353    26TH ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.74899,
    latitude: -122.4174
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '2801    BRYANT ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.74907,
    latitude: -122.40868
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '3300    26TH ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.74924,
    latitude: -122.4163
  },
  {
    zipcode: 94110,
    title: 'CHASE',
    description: '2900    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.74936,
    latitude: -122.41825
  },
  {
    zipcode: 94110,
    title: 'CHASE',
    description: '2900    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.74936,
    latitude: -122.41825
  },
  {
    zipcode: 94110,
    title: 'CHASE',
    description: '2900    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.74936,
    latitude: -122.41825
  },
  {
    zipcode: 94110,
    title: 'CHASE',
    description: '2900    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.74936,
    latitude: -122.41825
  },
  {
    zipcode: 94110,
    title: 'CHASE',
    description: '2900    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.74936,
    latitude: -122.41825
  },
  {
    zipcode: 94124,
    title: 'SWITCH COMMERCE INC.',
    description: '1850    CESAR CHAVEZ, San Francisco, CA 94124',
    surcharge: true,
    longitude: 37.74988,
    latitude: -122.39541
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '2997    FOLSOM ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75028,
    latitude: -122.41377
  },
  {
    zipcode: 94107,
    title: 'FIRST REPUBLIC BANK',
    description: '1200    MISSISSIPPI ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.75048,
    latitude: -122.39348
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '2839    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75127,
    latitude: -122.41825
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '2899    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75127,
    latitude: -122.41825
  },
  {
    zipcode: 94114,
    title: 'WELLS FARGO BANK',
    description: '4045    24TH ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.75128,
    latitude: -122.43286
  },
  {
    zipcode: 94114,
    title: 'WELLS FARGO BANK',
    description: '4045    24TH ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.75128,
    latitude: -122.43286
  },
  {
    zipcode: 94114,
    title: 'WELLS FARGO BANK',
    description: '4045    24TH ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.75128,
    latitude: -122.43286
  },
  {
    zipcode: 94110,
    title: 'BANK OF THE WEST',
    description: '2812    MISSION ST, San Francisco, CA 94110',
    surcharge: false,
    longitude: 37.75134,
    latitude: -122.41844
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '2830    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75134,
    latitude: -122.41844
  },
  {
    zipcode: 94114,
    title: 'BANK OF AMERICA',
    description: '4098    24TH ST, San Francisco, CA 94114',
    surcharge: false,
    longitude: 37.75146,
    latitude: -122.43292
  },
  {
    zipcode: 94114,
    title: 'BANK OF AMERICA',
    description: '4098    24TH ST, San Francisco, CA 94114',
    surcharge: false,
    longitude: 37.75146,
    latitude: -122.43292
  },
  {
    zipcode: 94114,
    title: 'BANK OF AMERICA',
    description: '4098    24TH ST, San Francisco, CA 94114',
    surcharge: false,
    longitude: 37.75146,
    latitude: -122.43292
  },
  {
    zipcode: 94114,
    title: 'BANK OF AMERICA',
    description: '4098    24TH ST, San Francisco, CA 94114',
    surcharge: false,
    longitude: 37.75146,
    latitude: -122.43292
  },
  {
    zipcode: 94114,
    title: 'PULSE NETWORK',
    description: '3807    24TH ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.75158,
    latitude: -122.42798
  },
  {
    zipcode: 94114,
    title: 'UMPQUA BANK',
    description: '3938    24TH ST, San Francisco, CA 94114',
    surcharge: false,
    longitude: 37.7516,
    latitude: -122.43052
  },
  {
    zipcode: 94114,
    title: 'CHASE',
    description: '3998    24TH ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.7516,
    latitude: -122.43052
  },
  {
    zipcode: 94114,
    title: 'CHASE',
    description: '3998    24TH ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.7516,
    latitude: -122.43052
  },
  {
    zipcode: 94110,
    title: 'SWITCH COMMERCE INC.',
    description: '1300    VALENCIA ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75163,
    latitude: -122.4207
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '3347    24TH ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.7521,
    latitude: -122.41924
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '1298    POTRERO AVE, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75218,
    latitude: -122.40635
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '3231    24TH ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75222,
    latitude: -122.41727
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '3033    24TH ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75249,
    latitude: -122.41285
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '3198    24TH ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.7525,
    latitude: -122.41563
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '3098    24TH ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75262,
    latitude: -122.41353
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '2899    24TH ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75268,
    latitude: -122.40951
  },
  {
    zipcode: 94110,
    title: 'SWITCH COMMERCE INC.',
    description: '3004    24TH ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75268,
    latitude: -122.41256
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '1200    VALENCIA ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75271,
    latitude: -122.42081
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '2950    24TH ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75275,
    latitude: -122.41128
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '2751    24TH ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75278,
    latitude: -122.40784
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '2799    24TH ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75278,
    latitude: -122.40784
  },
  {
    zipcode: 94110,
    title: 'BANK OF AMERICA',
    description: '2850    24TH ST, San Francisco, CA 94110',
    surcharge: false,
    longitude: 37.75286,
    latitude: -122.40952
  },
  {
    zipcode: 94110,
    title: 'BANK OF AMERICA',
    description: '2850    24TH ST, San Francisco, CA 94110',
    surcharge: false,
    longitude: 37.75286,
    latitude: -122.40952
  },
  {
    zipcode: 94122,
    title: 'PULSE NETWORK',
    description: '3845    NORIEGA ST, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.75291,
    latitude: -122.50448
  },
  {
    zipcode: 94110,
    title: 'SWITCH COMMERCE INC.',
    description: '2790    24TH ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75298,
    latitude: -122.40756
  },
  {
    zipcode: 94110,
    title: 'SWITCH COMMERCE INC.',
    description: '2798    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75304,
    latitude: -122.41861
  },
  {
    zipcode: 94110,
    title: 'BANK OF AMERICA',
    description: '2701    MISSION ST, San Francisco, CA 94110',
    surcharge: false,
    longitude: 37.75306,
    latitude: -122.41843
  },
  {
    zipcode: 94110,
    title: 'BANK OF AMERICA',
    description: '2701    MISSION ST, San Francisco, CA 94110',
    surcharge: false,
    longitude: 37.75306,
    latitude: -122.41843
  },
  {
    zipcode: 94110,
    title: 'BANK OF AMERICA',
    description: '2701    MISSION ST, San Francisco, CA 94110',
    surcharge: false,
    longitude: 37.75306,
    latitude: -122.41843
  },
  {
    zipcode: 94110,
    title: 'BANK OF AMERICA',
    description: '2701    MISSION ST, San Francisco, CA 94110',
    surcharge: false,
    longitude: 37.75306,
    latitude: -122.41843
  },
  {
    zipcode: 94122,
    title: 'CHASE',
    description: '1811    19TH AVE, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.75319,
    latitude: -122.4765
  },
  {
    zipcode: 94122,
    title: 'CHASE',
    description: '1811    19TH AVE, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.75319,
    latitude: -122.4765
  },
  {
    zipcode: 94122,
    title: 'MONEYPASS',
    description: '2533    NORIEGA ST, San Francisco, CA 94122',
    surcharge: false,
    longitude: 37.75352,
    latitude: -122.49074
  },
  {
    zipcode: 94122,
    title: 'MONEYPASS',
    description: '2301    NORIEGA ST, San Francisco, CA 94122',
    surcharge: false,
    longitude: 37.75361,
    latitude: -122.48852
  },
  {
    zipcode: 94122,
    title: 'BANK OF AMERICA',
    description: '2325    NORIEGA ST, San Francisco, CA 94122',
    surcharge: false,
    longitude: 37.75361,
    latitude: -122.48852
  },
  {
    zipcode: 94122,
    title: 'BANK OF AMERICA',
    description: '2325    NORIEGA ST, San Francisco, CA 94122',
    surcharge: false,
    longitude: 37.75361,
    latitude: -122.48852
  },
  {
    zipcode: 94122,
    title: 'WELLS FARGO BANK',
    description: '2454    NORIEGA ST, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.75374,
    latitude: -122.48974
  },
  {
    zipcode: 94122,
    title: 'WELLS FARGO BANK',
    description: '2454    NORIEGA ST, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.75374,
    latitude: -122.48974
  },
  {
    zipcode: 94122,
    title: 'CARDTRONICS',
    description: '2350    NORIEGA ST, San Francisco, CA 94122',
    surcharge: false,
    longitude: 37.75378,
    latitude: -122.4888
  },
  {
    zipcode: 94122,
    title: 'CITIBANK',
    description: '1900    NORIEGA ST, San Francisco, CA 94122',
    surcharge: false,
    longitude: 37.75397,
    latitude: -122.48463
  },
  {
    zipcode: 94110,
    title: 'CARDTRONICS',
    description: '1189    POTRERO AVE, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75399,
    latitude: -122.40633
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '1125    VALENCIA ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75407,
    latitude: -122.42075
  },
  {
    zipcode: 94122,
    title: 'CARDTRONICS',
    description: '1750    NORIEGA ST, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.75407,
    latitude: -122.48216
  },
  {
    zipcode: 94122,
    title: 'MONEYPASS',
    description: '1301    NORIEGA ST, San Francisco, CA 94122',
    surcharge: false,
    longitude: 37.7541,
    latitude: -122.47755
  },
  {
    zipcode: 94122,
    title: 'BANK OF AMERICA',
    description: '1450    NORIEGA ST, San Francisco, CA 94122',
    surcharge: false,
    longitude: 37.75422,
    latitude: -122.47886
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '2950    23RD ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75435,
    latitude: -122.41147
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '2449    23RD ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75436,
    latitude: -122.40358
  },
  {
    zipcode: 94107,
    title: 'PULSE NETWORK',
    description: '2250    23RD ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.75464,
    latitude: -122.40177
  },
  {
    zipcode: 94110,
    title: 'CARDTRONICS',
    description: '2690    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75477,
    latitude: -122.41877
  },
  {
    zipcode: 94107,
    title: 'FIS',
    description: '1800    23RD ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.75491,
    latitude: -122.39774
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '2601    FOLSOM ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75511,
    latitude: -122.41424
  },
  {
    zipcode: 94110,
    title: 'RBS WorldPay',
    description: '1000    POTRERO AVE, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75519,
    latitude: -122.40668
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '3239    22ND ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75529,
    latitude: -122.41947
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '3282    22ND ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75539,
    latitude: -122.42077
  },
  {
    zipcode: 94110,
    title: 'WELLS FARGO BANK',
    description: '2595    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75551,
    latitude: -122.41866
  },
  {
    zipcode: 94110,
    title: 'WELLS FARGO BANK',
    description: '2595    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75551,
    latitude: -122.41866
  },
  {
    zipcode: 94110,
    title: 'WELLS FARGO BANK',
    description: '2595    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75551,
    latitude: -122.41866
  },
  {
    zipcode: 94110,
    title: 'WELLS FARGO BANK',
    description: '2595    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75551,
    latitude: -122.41866
  },
  {
    zipcode: 94110,
    title: 'WELLS FARGO BANK',
    description: '2595    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75551,
    latitude: -122.41866
  },
  {
    zipcode: 94110,
    title: 'CHASE',
    description: '2500    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75637,
    latitude: -122.41892
  },
  {
    zipcode: 94110,
    title: 'CHASE',
    description: '2500    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75637,
    latitude: -122.41892
  },
  {
    zipcode: 94110,
    title: 'CHASE',
    description: '2500    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75637,
    latitude: -122.41892
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '2524    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75637,
    latitude: -122.41892
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '2524    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75637,
    latitude: -122.41892
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '2301    BRYANT ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75678,
    latitude: -122.40943
  },
  {
    zipcode: 94110,
    title: 'GOLDEN 1 CREDIT UNION',
    description: '1001    POTRERO AVE, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75682,
    latitude: -122.40659
  },
  {
    zipcode: 94110,
    title: 'RBS WorldPay',
    description: '2950    21ST ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75742,
    latitude: -122.41386
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '2750    21ST ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75766,
    latitude: -122.4099
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '999    VALENCIA ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75766,
    latitude: -122.4211
  },
  {
    zipcode: 94107,
    title: 'CARDTRONICS',
    description: '728    22ND ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.75801,
    latitude: -122.38851
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '2201    BRYANT ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75862,
    latitude: -122.40958
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '896    VALENCIA ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75884,
    latitude: -122.42139
  },
  {
    zipcode: 94107,
    title: 'FIS',
    description: '858    RHODE ISLAND ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.75901,
    latitude: -122.4021
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '2317    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75929,
    latitude: -122.41902
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '2361    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75929,
    latitude: -122.41902
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '2397    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75929,
    latitude: -122.41902
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '701    GUERRERO ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75929,
    latitude: -122.42343
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '2300    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75944,
    latitude: -122.41922
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '2348    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75944,
    latitude: -122.41922
  },
  {
    zipcode: 94110,
    title: 'CHASE',
    description: '804    VALENCIA ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75971,
    latitude: -122.42147
  },
  {
    zipcode: 94110,
    title: 'SWITCH COMMERCE INC.',
    description: '898   S VAN NESS AVE, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75973,
    latitude: -122.41705
  },
  {
    zipcode: 94107,
    title: 'PULSE NETWORK',
    description: '1601    20TH ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.75986,
    latitude: -122.39738
  },
  {
    zipcode: 94107,
    title: 'PULSE NETWORK',
    description: '1607    20TH ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.75986,
    latitude: -122.39738
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '401    CAPP ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75997,
    latitude: -122.41799
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '2307    FOLSOM ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76004,
    latitude: -122.4147
  },
  {
    zipcode: 94110,
    title: 'RBS WorldPay',
    description: '2399    FOLSOM ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76004,
    latitude: -122.4147
  },
  {
    zipcode: 94114,
    title: 'BANK OF AMERICA',
    description: '501    CASTRO ST, San Francisco, CA 94114',
    surcharge: false,
    longitude: 37.76017,
    latitude: -122.43484
  },
  {
    zipcode: 94114,
    title: 'BANK OF AMERICA',
    description: '501    CASTRO ST, San Francisco, CA 94114',
    surcharge: false,
    longitude: 37.76017,
    latitude: -122.43484
  },
  {
    zipcode: 94114,
    title: 'BANK OF AMERICA',
    description: '501    CASTRO ST, San Francisco, CA 94114',
    surcharge: false,
    longitude: 37.76017,
    latitude: -122.43484
  },
  {
    zipcode: 94114,
    title: 'BANK OF AMERICA',
    description: '501    CASTRO ST, San Francisco, CA 94114',
    surcharge: false,
    longitude: 37.76017,
    latitude: -122.43484
  },
  {
    zipcode: 94114,
    title: 'BANK OF AMERICA',
    description: '501    CASTRO ST, San Francisco, CA 94114',
    surcharge: false,
    longitude: 37.76017,
    latitude: -122.43484
  },
  {
    zipcode: 94114,
    title: 'BANK OF AMERICA',
    description: '501    CASTRO ST, San Francisco, CA 94114',
    surcharge: false,
    longitude: 37.76017,
    latitude: -122.43484
  },
  {
    zipcode: 94114,
    title: 'WELLS FARGO BANK',
    description: '557    CASTRO ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.76017,
    latitude: -122.43484
  },
  {
    zipcode: 94114,
    title: 'WELLS FARGO BANK',
    description: '557    CASTRO ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.76017,
    latitude: -122.43484
  },
  {
    zipcode: 94122,
    title: 'PULSE NETWORK',
    description: '4099    JUDAH ST, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.76036,
    latitude: -122.5052
  },
  {
    zipcode: 94114,
    title: 'CHASE',
    description: '4201    18TH ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.7607,
    latitude: -122.43659
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '2200    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76071,
    latitude: -122.41934
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '2268    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76071,
    latitude: -122.41934
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '2288    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76071,
    latitude: -122.41934
  },
  {
    zipcode: 94122,
    title: 'FIS',
    description: '2601    JUDAH ST, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.76103,
    latitude: -122.49011
  },
  {
    zipcode: 94114,
    title: 'CARDTRONICS',
    description: '3998    18TH ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.76116,
    latitude: -122.43189
  },
  {
    zipcode: 94122,
    title: 'PULSE NETWORK',
    description: '1400    8TH AVE, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.76123,
    latitude: -122.46495
  },
  {
    zipcode: 94122,
    title: 'CARDTRONICS',
    description: '1388    46TH AVE, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.76141,
    latitude: -122.5059
  },
  {
    zipcode: 94114,
    title: 'FIS',
    description: '426    CASTRO ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.76164,
    latitude: -122.43516
  },
  {
    zipcode: 94114,
    title: 'CITIBANK',
    description: '444    CASTRO ST, San Francisco, CA 94114',
    surcharge: false,
    longitude: 37.76164,
    latitude: -122.43516
  },
  {
    zipcode: 94114,
    title: 'CITIBANK',
    description: '444    CASTRO ST, San Francisco, CA 94114',
    surcharge: false,
    longitude: 37.76164,
    latitude: -122.43516
  },
  {
    zipcode: 94114,
    title: 'CITIBANK',
    description: '444    CASTRO ST, San Francisco, CA 94114',
    surcharge: false,
    longitude: 37.76164,
    latitude: -122.43516
  },
  {
    zipcode: 94114,
    title: 'WELLS FARGO BANK',
    description: '498    CASTRO ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.76164,
    latitude: -122.43516
  },
  {
    zipcode: 94114,
    title: 'MONEYPASS',
    description: '443    CASTRO ST, San Francisco, CA 94114',
    surcharge: false,
    longitude: 37.76187,
    latitude: -122.435
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '599    GUERRERO ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76209,
    latitude: -122.42371
  },
  {
    zipcode: 94122,
    title: 'PULSE NETWORK',
    description: '401A    JUDAH ST, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.76211,
    latitude: -122.46663
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '665    VALENCIA ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76212,
    latitude: -122.42152
  },
  {
    zipcode: 94107,
    title: 'PULSE NETWORK',
    description: '1301    18TH ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.76253,
    latitude: -122.39579
  },
  {
    zipcode: 94107,
    title: 'CARDTRONICS',
    description: '1135    18TH ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.76266,
    latitude: -122.39367
  },
  {
    zipcode: 94114,
    title: 'SWITCH COMMERCE INC.',
    description: '3900    17TH ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.76266,
    latitude: -122.43369
  },
  {
    zipcode: 94114,
    title: 'BANK OF THE WEST',
    description: '2299    MARKET ST, San Francisco, CA 94114',
    surcharge: false,
    longitude: 37.76278,
    latitude: -122.43305
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '2128    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76287,
    latitude: -122.41954
  },
  {
    zipcode: 94110,
    title: 'RBS WorldPay',
    description: '2169    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76298,
    latitude: -122.41937
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '601   S VAN NESS AVE, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76305,
    latitude: -122.41719
  },
  {
    zipcode: 94122,
    title: 'CHASE',
    description: '2323    IRVING ST, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.76322,
    latitude: -122.48283
  },
  {
    zipcode: 94122,
    title: 'CHASE',
    description: '2323    IRVING ST, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.76322,
    latitude: -122.48283
  },
  {
    zipcode: 94122,
    title: 'CHASE',
    description: '2323    IRVING ST, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.76322,
    latitude: -122.48283
  },
  {
    zipcode: 94122,
    title: 'MONEYPASS',
    description: '2219    IRVING ST, San Francisco, CA 94122',
    surcharge: false,
    longitude: 37.76326,
    latitude: -122.4818
  },
  {
    zipcode: 94122,
    title: 'HSBC BANK',
    description: '2257    IRVING ST, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.76326,
    latitude: -122.4818
  },
  {
    zipcode: 94122,
    title: 'MONEYPASS',
    description: '2001    IRVING ST, San Francisco, CA 94122',
    surcharge: false,
    longitude: 37.76336,
    latitude: -122.47961
  },
  {
    zipcode: 94122,
    title: 'RBS WorldPay',
    description: '1200    LA PLAYA ST, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.76338,
    latitude: -122.50926
  },
  {
    zipcode: 94122,
    title: 'WELLS FARGO BANK',
    description: '2300    IRVING ST, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.7634,
    latitude: -122.48279
  },
  {
    zipcode: 94122,
    title: 'WELLS FARGO BANK',
    description: '2300    IRVING ST, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.7634,
    latitude: -122.48279
  },
  {
    zipcode: 94122,
    title: 'WELLS FARGO BANK',
    description: '2300    IRVING ST, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.7634,
    latitude: -122.48279
  },
  {
    zipcode: 94122,
    title: 'PULSE NETWORK',
    description: '1399    9TH AVE, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.76341,
    latitude: -122.46635
  },
  {
    zipcode: 94122,
    title: 'BANK OF AMERICA',
    description: '1945    IRVING ST, San Francisco, CA 94122',
    surcharge: false,
    longitude: 37.76341,
    latitude: -122.47851
  },
  {
    zipcode: 94122,
    title: 'BANK OF AMERICA',
    description: '1945    IRVING ST, San Francisco, CA 94122',
    surcharge: false,
    longitude: 37.76341,
    latitude: -122.47851
  },
  {
    zipcode: 94122,
    title: 'BANK OF AMERICA',
    description: '1945    IRVING ST, San Francisco, CA 94122',
    surcharge: false,
    longitude: 37.76341,
    latitude: -122.47851
  },
  {
    zipcode: 94110,
    title: 'SWITCH COMMERCE INC.',
    description: '398    DOLORES ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76344,
    latitude: -122.42644
  },
  {
    zipcode: 94122,
    title: 'FIS',
    description: '1815    IRVING ST, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.76345,
    latitude: -122.47746
  },
  {
    zipcode: 94122,
    title: 'CITIBANK',
    description: '2000    IRVING ST, San Francisco, CA 94122',
    surcharge: false,
    longitude: 37.76354,
    latitude: -122.47955
  },
  {
    zipcode: 94122,
    title: 'CITIBANK',
    description: '2000    IRVING ST, San Francisco, CA 94122',
    surcharge: false,
    longitude: 37.76354,
    latitude: -122.47955
  },
  {
    zipcode: 94122,
    title: 'FIS',
    description: '1914    IRVING ST, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.76358,
    latitude: -122.47854
  },
  {
    zipcode: 94122,
    title: 'MONEYPASS',
    description: '1850    IRVING ST, San Francisco, CA 94122',
    surcharge: false,
    longitude: 37.76363,
    latitude: -122.47742
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '401    POTRERO AVE, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76372,
    latitude: -122.40726
  },
  {
    zipcode: 94122,
    title: 'WELLS FARGO BANK',
    description: '1200    IRVING ST, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.76393,
    latitude: -122.4706
  },
  {
    zipcode: 94122,
    title: 'CITIBANK',
    description: '701    IRVING ST, San Francisco, CA 94122',
    surcharge: false,
    longitude: 37.76397,
    latitude: -122.46556
  },
  {
    zipcode: 94122,
    title: 'WELLS FARGO BANK',
    description: '725    IRVING ST, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.76397,
    latitude: -122.46556
  },
  {
    zipcode: 94122,
    title: 'WELLS FARGO BANK',
    description: '725    IRVING ST, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.76397,
    latitude: -122.46556
  },
  {
    zipcode: 94122,
    title: 'WELLS FARGO BANK',
    description: '725    IRVING ST, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.76397,
    latitude: -122.46556
  },
  {
    zipcode: 94122,
    title: 'WELLS FARGO BANK',
    description: '725    IRVING ST, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.76397,
    latitude: -122.46556
  },
  {
    zipcode: 94122,
    title: 'FIRST REPUBLIC BANK',
    description: '653    IRVING ST, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.76402,
    latitude: -122.46445
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '400    GUERRERO ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76407,
    latitude: -122.42417
  },
  {
    zipcode: 94122,
    title: 'BANK OF AMERICA',
    description: '800    IRVING ST, San Francisco, CA 94122',
    surcharge: false,
    longitude: 37.76412,
    latitude: -122.46632
  },
  {
    zipcode: 94122,
    title: 'BANK OF AMERICA',
    description: '800    IRVING ST, San Francisco, CA 94122',
    surcharge: false,
    longitude: 37.76412,
    latitude: -122.46632
  },
  {
    zipcode: 94122,
    title: 'BANK OF AMERICA',
    description: '800    IRVING ST, San Francisco, CA 94122',
    surcharge: false,
    longitude: 37.76412,
    latitude: -122.46632
  },
  {
    zipcode: 94110,
    title: 'RBS WorldPay',
    description: '2007    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76413,
    latitude: -122.41949
  },
  {
    zipcode: 94110,
    title: 'RBS WorldPay',
    description: '2034    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76414,
    latitude: -122.41967
  },
  {
    zipcode: 94110,
    title: 'ACE CENTER',
    description: '2038    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76414,
    latitude: -122.41967
  },
  {
    zipcode: 94110,
    title: 'ACE CENTER',
    description: '2038    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76414,
    latitude: -122.41967
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '2074    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76414,
    latitude: -122.41967
  },
  {
    zipcode: 94110,
    title: 'SWITCH COMMERCE INC.',
    description: '2092    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76414,
    latitude: -122.41967
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '505   S VAN NESS AVE, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76414,
    latitude: -122.41729
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '599   S VAN NESS AVE, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76414,
    latitude: -122.41729
  },
  {
    zipcode: 94117,
    title: 'BANK OF AMERICA',
    description: '350    PARNASSUS AVE, San Francisco, CA 94117',
    surcharge: false,
    longitude: 37.76415,
    latitude: -122.45582
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '521    VALENCIA ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76419,
    latitude: -122.42172
  },
  {
    zipcode: 94122,
    title: 'PULSE NETWORK',
    description: '1200    19TH AVE, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.76429,
    latitude: -122.47716
  },
  {
    zipcode: 94117,
    title: 'CARDTRONICS',
    description: '199    PARNASSUS AVE, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.76451,
    latitude: -122.45182
  },
  {
    zipcode: 94107,
    title: 'UMPQUA BANK',
    description: '415    DE HARO ST, San Francisco, CA 94107',
    surcharge: false,
    longitude: 37.76466,
    latitude: -122.40149
  },
  {
    zipcode: 94103,
    title: 'FIS',
    description: '3147    16TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76476,
    latitude: -122.42297
  },
  {
    zipcode: 94103,
    title: 'RBS WorldPay',
    description: '3177    16TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76476,
    latitude: -122.42297
  },
  {
    zipcode: 94110,
    title: 'BANK OF AMERICA',
    description: '2017    MISSION ST, San Francisco, CA 94110',
    surcharge: false,
    longitude: 37.76478,
    latitude: -122.41955
  },
  {
    zipcode: 94110,
    title: 'BANK OF AMERICA',
    description: '2017    MISSION ST, San Francisco, CA 94110',
    surcharge: false,
    longitude: 37.76478,
    latitude: -122.41955
  },
  {
    zipcode: 94110,
    title: 'PULSE NETWORK',
    description: '500    VALENCIA ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76483,
    latitude: -122.42196
  },
  {
    zipcode: 94103,
    title: 'WELLS FARGO BANK',
    description: '3027    16TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76491,
    latitude: -122.42046
  },
  {
    zipcode: 94103,
    title: 'WELLS FARGO BANK',
    description: '3027    16TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76491,
    latitude: -122.42046
  },
  {
    zipcode: 94103,
    title: 'WELLS FARGO BANK',
    description: '3027    16TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76491,
    latitude: -122.42046
  },
  {
    zipcode: 94103,
    title: 'WELLS FARGO BANK',
    description: '3027    16TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76491,
    latitude: -122.42046
  },
  {
    zipcode: 94103,
    title: 'RBS WorldPay',
    description: '3186    16TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76493,
    latitude: -122.42314
  },
  {
    zipcode: 94110,
    title: 'RBS WorldPay',
    description: '3100    16TH ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76498,
    latitude: -122.42221
  },
  {
    zipcode: 94103,
    title: 'FIS',
    description: '3036    16TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76511,
    latitude: -122.42012
  },
  {
    zipcode: 94103,
    title: 'SWITCH COMMERCE INC.',
    description: '2799    16TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76525,
    latitude: -122.41482
  },
  {
    zipcode: 94103,
    title: 'CITIBANK',
    description: '350    RHODE ISLAND ST, San Francisco, CA 94103',
    surcharge: false,
    longitude: 37.7654,
    latitude: -122.40271
  },
  {
    zipcode: 94103,
    title: 'CITIBANK',
    description: '350    RHODE ISLAND ST, San Francisco, CA 94103',
    surcharge: false,
    longitude: 37.7654,
    latitude: -122.40271
  },
  {
    zipcode: 94122,
    title: 'GOLDEN 1 CREDIT UNION',
    description: '501    PARNASSUS AVE, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.76542,
    latitude: -122.45813
  },
  {
    zipcode: 94103,
    title: 'WELLS FARGO BANK',
    description: '2300    16TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76577,
    latitude: -122.4092
  },
  {
    zipcode: 94103,
    title: 'WELLS FARGO BANK',
    description: '2300    16TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76577,
    latitude: -122.4092
  },
  {
    zipcode: 94103,
    title: 'WELLS FARGO BANK',
    description: '2300    16TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76577,
    latitude: -122.4092
  },
  {
    zipcode: 94103,
    title: 'CHASE',
    description: '2300    16TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76577,
    latitude: -122.4092
  },
  {
    zipcode: 94103,
    title: 'CHASE',
    description: '2300    16TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76577,
    latitude: -122.4092
  },
  {
    zipcode: 94103,
    title: 'CHASE',
    description: '2300 STE 290  16TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76577,
    latitude: -122.4092
  },
  {
    zipcode: 94114,
    title: 'SWITCH COMMERCE INC.',
    description: '2177    MARKET ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.76579,
    latitude: -122.43089
  },
  {
    zipcode: 94122,
    title: 'PULSE NETWORK',
    description: '601    LINCOLN WAY, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.76585,
    latitude: -122.46478
  },
  {
    zipcode: 94114,
    title: 'SWITCH COMMERCE INC.',
    description: '300    CHURCH ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.76594,
    latitude: -122.42889
  },
  {
    zipcode: 94103,
    title: 'RBS WorldPay',
    description: '1939    MISSION ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76598,
    latitude: -122.41966
  },
  {
    zipcode: 94103,
    title: 'CARDTRONICS',
    description: '1979    MISSION ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76598,
    latitude: -122.41966
  },
  {
    zipcode: 94114,
    title: 'CHASE',
    description: '2112    15TH ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.766,
    latitude: -122.43235
  },
  {
    zipcode: 94114,
    title: 'CHASE',
    description: '2112    15TH ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.766,
    latitude: -122.43235
  },
  {
    zipcode: 94103,
    title: 'WELLS FARGO BANK',
    description: '300    DE HARO ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76611,
    latitude: -122.40181
  },
  {
    zipcode: 94117,
    title: 'FIS',
    description: '501    FREDERICK ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.76618,
    latitude: -122.4537
  },
  {
    zipcode: 94114,
    title: 'PULSE NETWORK',
    description: '260    CHURCH ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.76668,
    latitude: -122.42896
  },
  {
    zipcode: 94114,
    title: 'CARDTRONICS',
    description: '2145    MARKET ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.76696,
    latitude: -122.42934
  },
  {
    zipcode: 94103,
    title: 'PULSE NETWORK',
    description: '298    GUERRERO ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76703,
    latitude: -122.42445
  },
  {
    zipcode: 94103,
    title: 'RBS WorldPay',
    description: '399    VALENCIA ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76716,
    latitude: -122.42201
  },
  {
    zipcode: 94114,
    title: 'FIS',
    description: '723    14TH ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.76761,
    latitude: -122.42943
  },
  {
    zipcode: 94103,
    title: 'RBS WorldPay',
    description: '269    14TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76821,
    latitude: -122.41942
  },
  {
    zipcode: 94121,
    title: 'PULSE NETWORK',
    description: '1000    GREAT HWY, San Francisco, CA 94121',
    surcharge: true,
    longitude: 37.76828,
    latitude: -122.51041
  },
  {
    zipcode: 94103,
    title: 'FIS',
    description: '290    VALENCIA ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.7684,
    latitude: -122.42231
  },
  {
    zipcode: 94103,
    title: 'CARDTRONICS',
    description: '1800    FOLSOM ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76852,
    latitude: -122.4157
  },
  {
    zipcode: 94103,
    title: 'CHASE',
    description: '299    VALENCIA ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76853,
    latitude: -122.42214
  },
  {
    zipcode: 94103,
    title: 'CHASE',
    description: '299    VALENCIA ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76853,
    latitude: -122.42214
  },
  {
    zipcode: 94103,
    title: 'CHASE',
    description: '299    VALENCIA ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76853,
    latitude: -122.42214
  },
  {
    zipcode: 94114,
    title: 'BANK OF AMERICA',
    description: '45    CASTRO ST, San Francisco, CA 94114',
    surcharge: false,
    longitude: 37.76862,
    latitude: -122.43566
  },
  {
    zipcode: 94114,
    title: 'FIS',
    description: '136    CHURCH ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.76883,
    latitude: -122.42915
  },
  {
    zipcode: 94114,
    title: 'WELLS FARGO BANK',
    description: '2020    MARKET ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.76894,
    latitude: -122.42738
  },
  {
    zipcode: 94114,
    title: 'WELLS FARGO BANK',
    description: '2020    MARKET ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.76894,
    latitude: -122.42738
  },
  {
    zipcode: 94114,
    title: 'WELLS FARGO BANK',
    description: '2020    MARKET ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.76894,
    latitude: -122.42738
  },
  {
    zipcode: 94114,
    title: 'WELLS FARGO BANK',
    description: '2020    MARKET ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.76894,
    latitude: -122.42738
  },
  {
    zipcode: 94158,
    title: 'GOLDEN 1 CREDIT UNION',
    description: '550    GENE FRIEND WAY, San Francisco, CA 94158',
    surcharge: true,
    longitude: 37.76907,
    latitude: -122.39242
  },
  {
    zipcode: 94117,
    title: 'FIS',
    description: '609    COLE ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.76912,
    latitude: -122.45072
  },
  {
    zipcode: 94117,
    title: 'PULSE NETWORK',
    description: '1827    HAIGHT ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.76917,
    latitude: -122.45277
  },
  {
    zipcode: 94103,
    title: 'PULSE NETWORK',
    description: '1700    MISSION ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76926,
    latitude: -122.42012
  },
  {
    zipcode: 94103,
    title: 'PULSE NETWORK',
    description: '1710    MISSION ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76926,
    latitude: -122.42012
  },
  {
    zipcode: 94103,
    title: 'RBS WorldPay',
    description: '1798    MISSION ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76926,
    latitude: -122.42012
  },
  {
    zipcode: 94117,
    title: 'WELLS FARGO BANK',
    description: '1726    HAIGHT ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.76948,
    latitude: -122.45175
  },
  {
    zipcode: 94117,
    title: 'WELLS FARGO BANK',
    description: '1726    HAIGHT ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.76948,
    latitude: -122.45175
  },
  {
    zipcode: 94117,
    title: 'WELLS FARGO BANK',
    description: '1726    HAIGHT ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.76948,
    latitude: -122.45175
  },
  {
    zipcode: 94117,
    title: 'SWITCH COMMERCE INC.',
    description: '1794    HAIGHT ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.76948,
    latitude: -122.45175
  },
  {
    zipcode: 94117,
    title: 'CHASE',
    description: '1653    HAIGHT ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.76949,
    latitude: -122.45021
  },
  {
    zipcode: 94117,
    title: 'CHASE',
    description: '1653    HAIGHT ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.76949,
    latitude: -122.45021
  },
  {
    zipcode: 94158,
    title: 'MONEYPASS',
    description: '1600    OWENS ST, San Francisco, CA 94158',
    surcharge: false,
    longitude: 37.7697,
    latitude: -122.39658
  },
  {
    zipcode: 94103,
    title: 'SWITCH COMMERCE INC.',
    description: '178    VALENCIA ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76996,
    latitude: -122.42246
  },
  {
    zipcode: 94103,
    title: 'RBS WorldPay',
    description: '1001    BRANNAN ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76997,
    latitude: -122.40695
  },
  {
    zipcode: 94117,
    title: 'RBS WorldPay',
    description: '1530    HAIGHT ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.76999,
    latitude: -122.44778
  },
  {
    zipcode: 94103,
    title: 'BANK OF AMERICA',
    description: '699    8TH ST, San Francisco, CA 94103',
    surcharge: false,
    longitude: 37.77013,
    latitude: -122.40382
  },
  {
    zipcode: 94117,
    title: 'RBS WorldPay',
    description: '1416    HAIGHT ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.7702,
    latitude: -122.44613
  },
  {
    zipcode: 94103,
    title: 'SWITCH COMMERCE INC.',
    description: '428    11TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77022,
    latitude: -122.4121
  },
  {
    zipcode: 94118,
    title: 'WELLS FARGO BANK',
    description: '55    MUSIC CONCOURSE DR, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.77025,
    latitude: -122.46932
  },
  {
    zipcode: 94118,
    title: 'FIRST REPUBLIC BANK',
    description: '55    MUSIC CONCOURSE DR, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.77025,
    latitude: -122.46932
  },
  {
    zipcode: 94103,
    title: 'WELLS FARGO BANK',
    description: '555    9TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77067,
    latitude: -122.40763
  },
  {
    zipcode: 94103,
    title: 'CHASE',
    description: '555    9TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77067,
    latitude: -122.40763
  },
  {
    zipcode: 94103,
    title: 'CHASE',
    description: '555    9TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77067,
    latitude: -122.40763
  },
  {
    zipcode: 94103,
    title: 'CARDTRONICS',
    description: '450    10TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77088,
    latitude: -122.41054
  },
  {
    zipcode: 94103,
    title: 'PULSE NETWORK',
    description: '1859    MARKET ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77103,
    latitude: -122.42425
  },
  {
    zipcode: 94102,
    title: 'PULSE NETWORK',
    description: '1874    MARKET ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.77104,
    latitude: -122.4247
  },
  {
    zipcode: 94117,
    title: 'FIS',
    description: '901    HAIGHT ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77112,
    latitude: -122.43747
  },
  {
    zipcode: 94103,
    title: 'UNION BANK',
    description: '640    TOWNSEND ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77117,
    latitude: -122.40262
  },
  {
    zipcode: 94103,
    title: 'PULSE NETWORK',
    description: '1829    MARKET ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77122,
    latitude: -122.42401
  },
  {
    zipcode: 94117,
    title: 'FIS',
    description: '783    HAIGHT ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77147,
    latitude: -122.43469
  },
  {
    zipcode: 94103,
    title: 'FIS',
    description: '1525    FOLSOM ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77149,
    latitude: -122.41429
  },
  {
    zipcode: 94158,
    title: 'CHASE',
    description: '1375    3RD ST, San Francisco, CA 94158',
    surcharge: true,
    longitude: 37.77175,
    latitude: -122.3895
  },
  {
    zipcode: 94158,
    title: 'CHASE',
    description: '1375    3RD ST, San Francisco, CA 94158',
    surcharge: true,
    longitude: 37.77175,
    latitude: -122.3895
  },
  {
    zipcode: 94117,
    title: 'SWITCH COMMERCE INC.',
    description: '593    HAIGHT ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77188,
    latitude: -122.4315
  },
  {
    zipcode: 94117,
    title: 'PULSE NETWORK',
    description: '688    HAIGHT ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77191,
    latitude: -122.43264
  },
  {
    zipcode: 94103,
    title: 'RBS WorldPay',
    description: '1707    MARKET ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77198,
    latitude: -122.42214
  },
  {
    zipcode: 94117,
    title: 'PULSE NETWORK',
    description: '508    HAIGHT ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77209,
    latitude: -122.43122
  },
  {
    zipcode: 94117,
    title: 'RBS WorldPay',
    description: '540    HAIGHT ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77209,
    latitude: -122.43122
  },
  {
    zipcode: 94117,
    title: 'SWITCH COMMERCE INC.',
    description: '588    HAIGHT ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77209,
    latitude: -122.43122
  },
  {
    zipcode: 94117,
    title: 'CARDTRONICS',
    description: '499    HAIGHT ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77216,
    latitude: -122.42926
  },
  {
    zipcode: 94102,
    title: 'PULSE NETWORK',
    description: '399    HAIGHT ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.77229,
    latitude: -122.42821
  },
  {
    zipcode: 94121,
    title: 'WELLS FARGO BANK',
    description: '850    LA PLAYA ST, San Francisco, CA 94121',
    surcharge: true,
    longitude: 37.77231,
    latitude: -122.50987
  },
  {
    zipcode: 94121,
    title: 'WELLS FARGO BANK',
    description: '850    LA PLAYA ST, San Francisco, CA 94121',
    surcharge: true,
    longitude: 37.77231,
    latitude: -122.50987
  },
  {
    zipcode: 94103,
    title: 'PULSE NETWORK',
    description: '16    VALENCIA ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77242,
    latitude: -122.42271
  },
  {
    zipcode: 94103,
    title: 'SWITCH COMMERCE INC.',
    description: '8    VALENCIA ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77242,
    latitude: -122.42271
  },
  {
    zipcode: 94103,
    title: 'PULSE NETWORK',
    description: '1530    HOWARD ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77263,
    latitude: -122.41623
  },
  {
    zipcode: 94103,
    title: 'PULSE NETWORK',
    description: '1201    HARRISON ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77267,
    latitude: -122.40974
  },
  {
    zipcode: 94103,
    title: 'FIS',
    description: '1659    MARKET ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77278,
    latitude: -122.42203
  },
  {
    zipcode: 94117,
    title: 'FIS',
    description: '378    FILLMORE ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77284,
    latitude: -122.43049
  },
  {
    zipcode: 94117,
    title: 'CHASE',
    description: '401    DIVISADERO ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77323,
    latitude: -122.43758
  },
  {
    zipcode: 94117,
    title: 'CHASE',
    description: '401    DIVISADERO ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77323,
    latitude: -122.43758
  },
  {
    zipcode: 94103,
    title: 'FIS',
    description: '798    BRANNAN ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77329,
    latitude: -122.40304
  },
  {
    zipcode: 94117,
    title: 'PULSE NETWORK',
    description: '999    OAK ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77332,
    latitude: -122.43516
  },
  {
    zipcode: 94117,
    title: 'WELLS FARGO BANK',
    description: '425    DIVISADERO ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77333,
    latitude: -122.4376
  },
  {
    zipcode: 94117,
    title: 'RBS WorldPay',
    description: '1070    OAK ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77336,
    latitude: -122.43634
  },
  {
    zipcode: 94117,
    title: 'PULSE NETWORK',
    description: '2084    HAYES ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77344,
    latitude: -122.45064
  },
  {
    zipcode: 94103,
    title: 'PULSE NETWORK',
    description: '1551    MISSION ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77384,
    latitude: -122.41751
  },
  {
    zipcode: 94117,
    title: 'BANK OF AMERICA',
    description: '1275    FELL ST, San Francisco, CA 94117',
    surcharge: false,
    longitude: 37.77392,
    latitude: -122.43794
  },
  {
    zipcode: 94117,
    title: 'BANK OF AMERICA',
    description: '1275    FELL ST, San Francisco, CA 94117',
    surcharge: false,
    longitude: 37.77392,
    latitude: -122.43794
  },
  {
    zipcode: 94117,
    title: 'BANK OF AMERICA',
    description: '1275    FELL ST, San Francisco, CA 94117',
    surcharge: false,
    longitude: 37.77392,
    latitude: -122.43794
  },
  {
    zipcode: 94103,
    title: 'FIS',
    description: '299    9TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77396,
    latitude: -122.41171
  },
  {
    zipcode: 94102,
    title: 'FIS',
    description: '144    PAGE ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.77407,
    latitude: -122.42322
  },
  {
    zipcode: 94118,
    title: 'CARDTRONICS',
    description: '735    7TH AVE, San Francisco, CA 94118',
    surcharge: false,
    longitude: 37.77408,
    latitude: -122.46494
  },
  {
    zipcode: 94117,
    title: 'PULSE NETWORK',
    description: '501    FILLMORE ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.7742,
    latitude: -122.43096
  },
  {
    zipcode: 94103,
    title: 'PULSE NETWORK',
    description: '282    9TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77428,
    latitude: -122.41241
  },
  {
    zipcode: 94117,
    title: 'PULSE NETWORK',
    description: '1600    HAYES ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77437,
    latitude: -122.4433
  },
  {
    zipcode: 94117,
    title: 'FIS',
    description: '535    SCOTT ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77437,
    latitude: -122.43605
  },
  {
    zipcode: 94102,
    title: 'PULSE NETWORK',
    description: '497    OAK ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.77441,
    latitude: -122.42662
  },
  {
    zipcode: 94103,
    title: 'SWITCH COMMERCE INC.',
    description: '1237    FOLSOM ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77447,
    latitude: -122.41057
  },
  {
    zipcode: 94117,
    title: 'CARDTRONICS',
    description: '450    STANYAN ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77453,
    latitude: -122.45452
  },
  {
    zipcode: 94102,
    title: 'RBS WorldPay',
    description: '47    FRANKLIN ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.77481,
    latitude: -122.42096
  },
  {
    zipcode: 94103,
    title: 'RBS WorldPay',
    description: '130    10TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77498,
    latitude: -122.41569
  },
  {
    zipcode: 94117,
    title: 'FIS',
    description: '667    FILLMORE ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77519,
    latitude: -122.43116
  },
  {
    zipcode: 94103,
    title: 'BANK OF AMERICA',
    description: '1525    MARKET ST, San Francisco, CA 94103',
    surcharge: false,
    longitude: 37.77536,
    latitude: -122.41875
  },
  {
    zipcode: 94103,
    title: 'BANK OF AMERICA',
    description: '1525    MARKET ST, San Francisco, CA 94103',
    surcharge: false,
    longitude: 37.77536,
    latitude: -122.41875
  },
  {
    zipcode: 94103,
    title: 'BANK OF AMERICA',
    description: '1525    MARKET ST, San Francisco, CA 94103',
    surcharge: false,
    longitude: 37.77536,
    latitude: -122.41875
  },
  {
    zipcode: 94103,
    title: 'BANK OF AMERICA',
    description: '1525    MARKET ST, San Francisco, CA 94103',
    surcharge: false,
    longitude: 37.77536,
    latitude: -122.41875
  },
  {
    zipcode: 94103,
    title: 'BANK OF AMERICA',
    description: '1525    MARKET ST, San Francisco, CA 94103',
    surcharge: false,
    longitude: 37.77536,
    latitude: -122.41875
  },
  {
    zipcode: 94103,
    title: 'BANK OF AMERICA',
    description: '1525    MARKET ST, San Francisco, CA 94103',
    surcharge: false,
    longitude: 37.77536,
    latitude: -122.41875
  },
  {
    zipcode: 94121,
    title: 'BANK OF AMERICA',
    description: '3701    BALBOA ST, San Francisco, CA 94121',
    surcharge: false,
    longitude: 37.77555,
    latitude: -122.49875
  },
  {
    zipcode: 94121,
    title: 'BANK OF AMERICA',
    description: '3701    BALBOA ST, San Francisco, CA 94121',
    surcharge: false,
    longitude: 37.77555,
    latitude: -122.49875
  },
  {
    zipcode: 94102,
    title: 'PULSE NETWORK',
    description: '1500    MARKET ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.7756,
    latitude: -122.4189
  },
  {
    zipcode: 94121,
    title: 'MONEYPASS',
    description: '3601    BALBOA ST, San Francisco, CA 94121',
    surcharge: false,
    longitude: 37.7756,
    latitude: -122.49768
  },
  {
    zipcode: 94121,
    title: 'FIS',
    description: '3950    BALBOA ST, San Francisco, CA 94121',
    surcharge: true,
    longitude: 37.77564,
    latitude: -122.50091
  },
  {
    zipcode: 94117,
    title: 'FIS',
    description: '801    HAYES ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77581,
    latitude: -122.43064
  },
  {
    zipcode: 94121,
    title: 'RBS WorldPay',
    description: '3149    BALBOA ST, San Francisco, CA 94121',
    surcharge: true,
    longitude: 37.77585,
    latitude: -122.49231
  },
  {
    zipcode: 94121,
    title: 'FIS',
    description: '3434    BALBOA ST, San Francisco, CA 94121',
    surcharge: true,
    longitude: 37.77588,
    latitude: -122.49546
  },
  {
    zipcode: 94117,
    title: 'RBS WorldPay',
    description: '1326    GROVE ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77589,
    latitude: -122.43895
  },
  {
    zipcode: 94103,
    title: 'CARDTRONICS',
    description: '1298    HOWARD ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77591,
    latitude: -122.41214
  },
  {
    zipcode: 94102,
    title: 'CARDTRONICS',
    description: '300    GOUGH ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.77597,
    latitude: -122.4227
  },
  {
    zipcode: 94117,
    title: 'PULSE NETWORK',
    description: '1601    FULTON ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77603,
    latitude: -122.44389
  },
  {
    zipcode: 94117,
    title: 'CHASE',
    description: '1720    FULTON ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77604,
    latitude: -122.44531
  },
  {
    zipcode: 94117,
    title: 'CHASE',
    description: '1720    FULTON ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77604,
    latitude: -122.44531
  },
  {
    zipcode: 94117,
    title: 'WELLS FARGO BANK',
    description: '1750    FULTON ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77604,
    latitude: -122.44531
  },
  {
    zipcode: 94102,
    title: 'FIS',
    description: '191    FRANKLIN ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.77608,
    latitude: -122.42122
  },
  {
    zipcode: 94117,
    title: 'FIS',
    description: '711    FILLMORE ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.7761,
    latitude: -122.43134
  },
  {
    zipcode: 94103,
    title: 'CARDTRONICS',
    description: '1201 STE   HOWARD ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77614,
    latitude: -122.41155
  },
  {
    zipcode: 94103,
    title: 'PULSE NETWORK',
    description: '98    9TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77626,
    latitude: -122.4149
  },
  {
    zipcode: 94103,
    title: 'SWITCH COMMERCE INC.',
    description: '1141    FOLSOM ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77631,
    latitude: -122.40823
  },
  {
    zipcode: 94103,
    title: 'SWITCH COMMERCE INC.',
    description: '1126    FOLSOM ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77632,
    latitude: -122.40851
  },
  {
    zipcode: 94102,
    title: 'CARDTRONICS',
    description: '1496    MARKET ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.77634,
    latitude: -122.41796
  },
  {
    zipcode: 94102,
    title: 'RBS WorldPay',
    description: '698    HAYES ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.77642,
    latitude: -122.42731
  },
  {
    zipcode: 94102,
    title: 'FIS',
    description: '559    HAYES ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.77648,
    latitude: -122.42541
  },
  {
    zipcode: 94117,
    title: 'PULSE NETWORK',
    description: '793    DIVISADERO ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77664,
    latitude: -122.43818
  },
  {
    zipcode: 94102,
    title: 'REDWOOD CREDIT UNION',
    description: '1390    MARKET ST, San Francisco, CA 94102',
    surcharge: false,
    longitude: 37.77669,
    latitude: -122.4175
  },
  {
    zipcode: 94103,
    title: 'PULSE NETWORK',
    description: '1270    MISSION ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77675,
    latitude: -122.41419
  },
  {
    zipcode: 94103,
    title: 'CARDTRONICS',
    description: '1301    MARKET ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77685,
    latitude: -122.41687
  },
  {
    zipcode: 94103,
    title: 'FIRST REPUBLIC BANK',
    description: '1355    MARKET ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77685,
    latitude: -122.41687
  },
  {
    zipcode: 94103,
    title: 'RBS WorldPay',
    description: '99    9TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77687,
    latitude: -122.41537
  },
  {
    zipcode: 94107,
    title: 'CHASE',
    description: '255    KING ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.77696,
    latitude: -122.39288
  },
  {
    zipcode: 94107,
    title: 'CHASE',
    description: '255    KING ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.77696,
    latitude: -122.39288
  },
  {
    zipcode: 94107,
    title: 'BANK OF AMERICA',
    description: '700    4TH ST, San Francisco, CA 94107',
    surcharge: false,
    longitude: 37.77701,
    latitude: -122.39503
  },
  {
    zipcode: 94117,
    title: 'PULSE NETWORK',
    description: '867    FILLMORE ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77705,
    latitude: -122.43153
  },
  {
    zipcode: 94117,
    title: 'SWITCH COMMERCE INC.',
    description: '800    DIVISADERO ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77715,
    latitude: -122.43809
  },
  {
    zipcode: 94118,
    title: 'BANK OF AMERICA',
    description: '2345    GOLDEN GATE AVE, San Francisco, CA 94118',
    surcharge: false,
    longitude: 37.77727,
    latitude: -122.44919
  },
  {
    zipcode: 94103,
    title: 'CARDTRONICS',
    description: '1000    HARRISON ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77732,
    latitude: -122.40415
  },
  {
    zipcode: 94107,
    title: 'WELLS FARGO BANK',
    description: '286    KING ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.77745,
    latitude: -122.39297
  },
  {
    zipcode: 94107,
    title: 'WELLS FARGO BANK',
    description: '286    KING ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.77745,
    latitude: -122.39297
  },
  {
    zipcode: 94107,
    title: 'CARDTRONICS',
    description: '298    KING ST, San Francisco, CA 94107',
    surcharge: false,
    longitude: 37.77745,
    latitude: -122.39297
  },
  {
    zipcode: 94107,
    title: 'CARDTRONICS',
    description: '298    KING ST, San Francisco, CA 94107',
    surcharge: false,
    longitude: 37.77745,
    latitude: -122.39297
  },
  {
    zipcode: 94107,
    title: 'CARDTRONICS',
    description: '670    4TH ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.77757,
    latitude: -122.39573
  },
  {
    zipcode: 94118,
    title: 'RBS WorldPay',
    description: '2101    GOLDEN GATE AVE, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.7777,
    latitude: -122.44586
  },
  {
    zipcode: 94103,
    title: 'CHASE',
    description: '1201    MARKET ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77805,
    latitude: -122.41535
  },
  {
    zipcode: 94103,
    title: 'CHASE',
    description: '1201    MARKET ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77805,
    latitude: -122.41535
  },
  {
    zipcode: 94103,
    title: 'CHASE',
    description: '1201    MARKET ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77805,
    latitude: -122.41535
  },
  {
    zipcode: 94103,
    title: 'CHASE',
    description: '1201    MARKET ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77805,
    latitude: -122.41535
  },
  {
    zipcode: 94103,
    title: 'ACFN',
    description: '50    8TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77813,
    latitude: -122.41415
  },
  {
    zipcode: 94103,
    title: 'PULSE NETWORK',
    description: '180    7TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77815,
    latitude: -122.40975
  },
  {
    zipcode: 94103,
    title: 'ACFN',
    description: '1231    MARKET ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77823,
    latitude: -122.41513
  },
  {
    zipcode: 94107,
    title: 'BANK OF AMERICA',
    description: '501    BRANNAN ST, San Francisco, CA 94107',
    surcharge: false,
    longitude: 37.77824,
    latitude: -122.39648
  },
  {
    zipcode: 94107,
    title: 'BANK OF AMERICA',
    description: '501    BRANNAN ST, San Francisco, CA 94107',
    surcharge: false,
    longitude: 37.77824,
    latitude: -122.39648
  },
  {
    zipcode: 94107,
    title: 'BANK OF AMERICA',
    description: '501    BRANNAN ST, San Francisco, CA 94107',
    surcharge: false,
    longitude: 37.77824,
    latitude: -122.39648
  },
  {
    zipcode: 94107,
    title: 'BANK OF AMERICA',
    description: '501    BRANNAN ST, San Francisco, CA 94107',
    surcharge: false,
    longitude: 37.77824,
    latitude: -122.39648
  },
  {
    zipcode: 94102,
    title: 'WELLS FARGO BANK',
    description: '1266    MARKET ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.77852,
    latitude: -122.4156
  },
  {
    zipcode: 94102,
    title: 'WELLS FARGO BANK',
    description: '1266    MARKET ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.77852,
    latitude: -122.4156
  },
  {
    zipcode: 94102,
    title: 'WELLS FARGO BANK',
    description: '1266    MARKET ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.77852,
    latitude: -122.4156
  },
  {
    zipcode: 94102,
    title: 'WELLS FARGO BANK',
    description: '1266    MARKET ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.77852,
    latitude: -122.4156
  },
  {
    zipcode: 94102,
    title: 'WELLS FARGO BANK',
    description: '1266    MARKET ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.77852,
    latitude: -122.4156
  },
  {
    zipcode: 94107,
    title: 'WELLS FARGO BANK',
    description: '737    3RD ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.77858,
    latitude: -122.39226
  },
  {
    zipcode: 94107,
    title: 'FIS',
    description: '747    3RD ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.77858,
    latitude: -122.39226
  },
  {
    zipcode: 94107,
    title: 'FIS',
    description: '747    3RD ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.77858,
    latitude: -122.39226
  },
  {
    zipcode: 94107,
    title: 'FREMONT BANK',
    description: '200    TOWNSEND ST, San Francisco, CA 94107',
    surcharge: false,
    longitude: 37.77888,
    latitude: -122.3933
  },
  {
    zipcode: 94103,
    title: 'ACFN',
    description: '121    7TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77895,
    latitude: -122.41046
  },
  {
    zipcode: 94107,
    title: 'BANK OF AMERICA',
    description: '24    WILLIE MAYS PLZ, San Francisco, CA 94107',
    surcharge: false,
    longitude: 37.77896,
    latitude: -122.38944
  },
  {
    zipcode: 94107,
    title: 'BANK OF AMERICA',
    description: '24    WILLIE MAYS PLZ, San Francisco, CA 94107',
    surcharge: false,
    longitude: 37.77896,
    latitude: -122.38944
  },
  {
    zipcode: 94107,
    title: 'BANK OF AMERICA',
    description: '24    WILLIE MAYS PLZ, San Francisco, CA 94107',
    surcharge: false,
    longitude: 37.77896,
    latitude: -122.38944
  },
  {
    zipcode: 94107,
    title: 'BANK OF AMERICA',
    description: '24    WILLIE MAYS PLZ, San Francisco, CA 94107',
    surcharge: false,
    longitude: 37.77896,
    latitude: -122.38944
  },
  {
    zipcode: 94107,
    title: 'BANK OF AMERICA',
    description: '24    WILLIE MAYS PLZ, San Francisco, CA 94107',
    surcharge: false,
    longitude: 37.77896,
    latitude: -122.38944
  },
  {
    zipcode: 94107,
    title: 'BANK OF AMERICA',
    description: '24    WILLIE MAYS PLZ, San Francisco, CA 94107',
    surcharge: false,
    longitude: 37.77896,
    latitude: -122.38944
  },
  {
    zipcode: 94107,
    title: 'BANK OF AMERICA',
    description: '24    WILLIE MAYS PLZ, San Francisco, CA 94107',
    surcharge: false,
    longitude: 37.77896,
    latitude: -122.38944
  },
  {
    zipcode: 94107,
    title: 'BANK OF AMERICA',
    description: '24    WILLIE MAYS PLZ, San Francisco, CA 94107',
    surcharge: false,
    longitude: 37.77896,
    latitude: -122.38944
  },
  {
    zipcode: 94107,
    title: 'BANK OF AMERICA',
    description: '24    WILLIE MAYS PLZ, San Francisco, CA 94107',
    surcharge: false,
    longitude: 37.77896,
    latitude: -122.38944
  },
  {
    zipcode: 94121,
    title: 'FIS',
    description: '902    POINT LOBOS AVE, San Francisco, CA 94121',
    surcharge: true,
    longitude: 37.77903,
    latitude: -122.51307
  },
  {
    zipcode: 94107,
    title: 'WELLS FARGO BANK',
    description: '490    BRANNAN ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.77906,
    latitude: -122.39574
  },
  {
    zipcode: 94107,
    title: 'WELLS FARGO BANK',
    description: '490    BRANNAN ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.77906,
    latitude: -122.39574
  },
  {
    zipcode: 94107,
    title: 'WELLS FARGO BANK',
    description: '490    BRANNAN ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.77906,
    latitude: -122.39574
  },
  {
    zipcode: 94107,
    title: 'WELLS FARGO BANK',
    description: '490    BRANNAN ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.77906,
    latitude: -122.39574
  },
  {
    zipcode: 94107,
    title: 'PULSE NETWORK',
    description: '399    5TH ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.7791,
    latitude: -122.40179
  },
  {
    zipcode: 94103,
    title: 'PULSE NETWORK',
    description: '201    6TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77953,
    latitude: -122.40676
  },
  {
    zipcode: 94121,
    title: 'CARDTRONICS',
    description: '25    POINT LOBOS AVE, San Francisco, CA 94121',
    surcharge: true,
    longitude: 37.77954,
    latitude: -122.50324
  },
  {
    zipcode: 94102,
    title: 'FIS',
    description: '691    MCALLISTER ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.77961,
    latitude: -122.42332
  },
  {
    zipcode: 94103,
    title: 'CARDTRONICS',
    description: '1101    MARKET ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77968,
    latitude: -122.41329
  },
  {
    zipcode: 94115,
    title: 'PULSE NETWORK',
    description: '1101    FILLMORE ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.7797,
    latitude: -122.43207
  },
  {
    zipcode: 94118,
    title: 'BANK OF AMERICA',
    description: '281    MASONIC AVE, San Francisco, CA 94118',
    surcharge: false,
    longitude: 37.77978,
    latitude: -122.4474
  },
  {
    zipcode: 94103,
    title: 'PULSE NETWORK',
    description: '1000    HOWARD ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.7798,
    latitude: -122.40722
  },
  {
    zipcode: 94121,
    title: 'RBS WorldPay',
    description: '6900    GEARY BLVD, San Francisco, CA 94121',
    surcharge: true,
    longitude: 37.77983,
    latitude: -122.4935
  },
  {
    zipcode: 94107,
    title: 'PULSE NETWORK',
    description: '300    5TH ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.77988,
    latitude: -122.40306
  },
  {
    zipcode: 94107,
    title: 'PULSE NETWORK',
    description: '330    5TH ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.77988,
    latitude: -122.40306
  },
  {
    zipcode: 94105,
    title: 'PULSE NETWORK',
    description: '174    6TH ST, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.77994,
    latitude: -122.40756
  },
  {
    zipcode: 94121,
    title: 'FIRST REPUBLIC BANK',
    description: '6001    GEARY BLVD, San Francisco, CA 94121',
    surcharge: true,
    longitude: 37.78004,
    latitude: -122.48402
  },
  {
    zipcode: 94102,
    title: 'PULSE NETWORK',
    description: '10    UNITED NATIONS PLZ, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78006,
    latitude: -122.41364
  },
  {
    zipcode: 94107,
    title: 'PULSE NETWORK',
    description: '301    5TH ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.78022,
    latitude: -122.40318
  },
  {
    zipcode: 94121,
    title: 'PULSE NETWORK',
    description: '5615    GEARY BLVD, San Francisco, CA 94121',
    surcharge: true,
    longitude: 37.78023,
    latitude: -122.47996
  },
  {
    zipcode: 94121,
    title: 'CHASE',
    description: '5655    GEARY BLVD, San Francisco, CA 94121',
    surcharge: true,
    longitude: 37.78023,
    latitude: -122.47996
  },
  {
    zipcode: 94121,
    title: 'CHASE',
    description: '5655    GEARY BLVD, San Francisco, CA 94121',
    surcharge: true,
    longitude: 37.78023,
    latitude: -122.47996
  },
  {
    zipcode: 94121,
    title: 'CITIBANK',
    description: '6100    GEARY BLVD, San Francisco, CA 94121',
    surcharge: false,
    longitude: 37.78023,
    latitude: -122.48502
  },
  {
    zipcode: 94107,
    title: 'CARDTRONICS',
    description: '598    BRYANT ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.78027,
    latitude: -122.3973
  },
  {
    zipcode: 94121,
    title: 'MONEYPASS',
    description: '5501    GEARY BLVD, San Francisco, CA 94121',
    surcharge: false,
    longitude: 37.78029,
    latitude: -122.4786
  },
  {
    zipcode: 94121,
    title: 'WELLS FARGO BANK',
    description: '5455    GEARY BLVD, San Francisco, CA 94121',
    surcharge: true,
    longitude: 37.78033,
    latitude: -122.47782
  },
  {
    zipcode: 94121,
    title: 'WELLS FARGO BANK',
    description: '5455    GEARY BLVD, San Francisco, CA 94121',
    surcharge: true,
    longitude: 37.78033,
    latitude: -122.47782
  },
  {
    zipcode: 94121,
    title: 'WELLS FARGO BANK',
    description: '5455    GEARY BLVD, San Francisco, CA 94121',
    surcharge: true,
    longitude: 37.78033,
    latitude: -122.47782
  },
  {
    zipcode: 94121,
    title: 'WELLS FARGO BANK',
    description: '5455    GEARY BLVD, San Francisco, CA 94121',
    surcharge: true,
    longitude: 37.78033,
    latitude: -122.47782
  },
  {
    zipcode: 94102,
    title: 'CHASE',
    description: '500    VAN NESS AVE, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.7804,
    latitude: -122.42012
  },
  {
    zipcode: 94102,
    title: 'CHASE',
    description: '500    VAN NESS AVE, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.7804,
    latitude: -122.42012
  },
  {
    zipcode: 94121,
    title: 'BANK OF AMERICA',
    description: '5500    GEARY BLVD, San Francisco, CA 94121',
    surcharge: false,
    longitude: 37.78052,
    latitude: -122.47871
  },
  {
    zipcode: 94121,
    title: 'BANK OF AMERICA',
    description: '5500    GEARY BLVD, San Francisco, CA 94121',
    surcharge: false,
    longitude: 37.78052,
    latitude: -122.47871
  },
  {
    zipcode: 94121,
    title: 'BANK OF AMERICA',
    description: '5500    GEARY BLVD, San Francisco, CA 94121',
    surcharge: false,
    longitude: 37.78052,
    latitude: -122.47871
  },
  {
    zipcode: 94102,
    title: 'GOLDEN 1 CREDIT UNION',
    description: '505    VAN NESS AVE, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78058,
    latitude: -122.42051
  },
  {
    zipcode: 94118,
    title: 'CARDTRONICS',
    description: '5280    GEARY BLVD, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78065,
    latitude: -122.47577
  },
  {
    zipcode: 94118,
    title: 'FIS',
    description: '4715    GEARY BLVD, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78069,
    latitude: -122.46997
  },
  {
    zipcode: 94118,
    title: 'CARDTRONICS',
    description: '5100    GEARY BLVD, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78072,
    latitude: -122.4743
  },
  {
    zipcode: 94118,
    title: 'MONEYPASS',
    description: '5160    GEARY BLVD, San Francisco, CA 94118',
    surcharge: false,
    longitude: 37.78072,
    latitude: -122.4743
  },
  {
    zipcode: 94107,
    title: 'PULSE NETWORK',
    description: '551    3RD ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.78076,
    latitude: -122.395
  },
  {
    zipcode: 94115,
    title: 'PULSE NETWORK',
    description: '1201    DIVISADERO ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78078,
    latitude: -122.43911
  },
  {
    zipcode: 94118,
    title: 'CITIBANK',
    description: '4455    GEARY BLVD, San Francisco, CA 94118',
    surcharge: false,
    longitude: 37.78084,
    latitude: -122.4666
  },
  {
    zipcode: 94118,
    title: 'CITIBANK',
    description: '4455    GEARY BLVD, San Francisco, CA 94118',
    surcharge: false,
    longitude: 37.78084,
    latitude: -122.4666
  },
  {
    zipcode: 94103,
    title: 'PULSE NETWORK',
    description: '118    6TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78086,
    latitude: -122.40872
  },
  {
    zipcode: 94102,
    title: 'FIS',
    description: '136    MCALLISTER ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78087,
    latitude: -122.41478
  },
  {
    zipcode: 94118,
    title: 'MONEYPASS',
    description: '4355    GEARY BLVD, San Francisco, CA 94118',
    surcharge: false,
    longitude: 37.78087,
    latitude: -122.46594
  },
  {
    zipcode: 94118,
    title: 'CARDTRONICS',
    description: '4850    GEARY BLVD, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78087,
    latitude: -122.47094
  },
  {
    zipcode: 94118,
    title: 'BANK OF AMERICA',
    description: '4141    GEARY BLVD, San Francisco, CA 94118',
    surcharge: false,
    longitude: 37.78097,
    latitude: -122.46363
  },
  {
    zipcode: 94102,
    title: 'SWITCH COMMERCE INC.',
    description: '601    VAN NESS AVE, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.781,
    latitude: -122.42053
  },
  {
    zipcode: 94102,
    title: 'BANK OF AMERICA',
    description: '601    VAN NESS AVE, San Francisco, CA 94102',
    surcharge: false,
    longitude: 37.781,
    latitude: -122.42053
  },
  {
    zipcode: 94102,
    title: 'BANK OF AMERICA',
    description: '601    VAN NESS AVE, San Francisco, CA 94102',
    surcharge: false,
    longitude: 37.781,
    latitude: -122.42053
  },
  {
    zipcode: 94102,
    title: 'SWITCH COMMERCE INC.',
    description: '601    VAN NESS AVE, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.781,
    latitude: -122.42053
  },
  {
    zipcode: 94102,
    title: 'SWITCH COMMERCE INC.',
    description: '86    MCALLISTER ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78101,
    latitude: -122.41366
  },
  {
    zipcode: 94115,
    title: 'PULSE NETWORK',
    description: '1200    FILLMORE ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78108,
    latitude: -122.43216
  },
  {
    zipcode: 94103,
    title: 'FIS',
    description: '431    NATOMA ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78108,
    latitude: -122.40638
  },
  {
    zipcode: 94118,
    title: 'PULSE NETWORK',
    description: '3801    GEARY BLVD, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78113,
    latitude: -122.46017
  },
  {
    zipcode: 94118,
    title: 'CARDTRONICS',
    description: '3675    GEARY BLVD, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78121,
    latitude: -122.45844
  },
  {
    zipcode: 94102,
    title: 'GOLDEN 1 CREDIT UNION',
    description: '500    GOLDEN GATE AVE, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78132,
    latitude: -122.41882
  },
  {
    zipcode: 94103,
    title: 'PULSE NETWORK',
    description: '1003    MARKET ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78133,
    latitude: -122.4112
  },
  {
    zipcode: 94103,
    title: 'CARDTRONICS',
    description: '1075    MARKET ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78133,
    latitude: -122.4112
  },
  {
    zipcode: 94103,
    title: 'PULSE NETWORK',
    description: '1083B    MARKET ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78133,
    latitude: -122.4112
  },
  {
    zipcode: 94103,
    title: 'PULSE NETWORK',
    description: '65    6TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78141,
    latitude: -122.40911
  },
  {
    zipcode: 94102,
    title: 'MONEYPASS',
    description: '450    GOLDEN GATE AVE, San Francisco, CA 94102',
    surcharge: false,
    longitude: 37.78142,
    latitude: -122.418
  },
  {
    zipcode: 94118,
    title: 'CHASE',
    description: '3301    GEARY BLVD, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78144,
    latitude: -122.45477
  },
  {
    zipcode: 94118,
    title: 'WELLS FARGO BANK',
    description: '3624    GEARY BLVD, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78145,
    latitude: -122.45801
  },
  {
    zipcode: 94118,
    title: 'WELLS FARGO BANK',
    description: '3624    GEARY BLVD, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78145,
    latitude: -122.45801
  },
  {
    zipcode: 94118,
    title: 'WELLS FARGO BANK',
    description: '3624    GEARY BLVD, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78145,
    latitude: -122.45801
  },
  {
    zipcode: 94118,
    title: 'WELLS FARGO BANK',
    description: '3624    GEARY BLVD, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78145,
    latitude: -122.45801
  },
  {
    zipcode: 94103,
    title: 'RBS WorldPay',
    description: '40    6TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78147,
    latitude: -122.40948
  },
  {
    zipcode: 94103,
    title: 'PULSE NETWORK',
    description: '42    6TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78147,
    latitude: -122.40948
  },
  {
    zipcode: 94118,
    title: 'MONEYPASS',
    description: '3550    GEARY BLVD, San Francisco, CA 94118',
    surcharge: false,
    longitude: 37.78151,
    latitude: -122.45685
  },
  {
    zipcode: 94102,
    title: 'PULSE NETWORK',
    description: '390    GOLDEN GATE AVE, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78156,
    latitude: -122.41696
  },
  {
    zipcode: 94107,
    title: 'RBS WorldPay',
    description: '471    3RD ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.78156,
    latitude: -122.396
  },
  {
    zipcode: 94107,
    title: 'FIS',
    description: '475    3RD ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.78156,
    latitude: -122.396
  },
  {
    zipcode: 94102,
    title: 'PULSE NETWORK',
    description: '1010    MARKET ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78163,
    latitude: -122.41126
  },
  {
    zipcode: 94102,
    title: 'FIS',
    description: '1072A    MARKET ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78163,
    latitude: -122.41126
  },
  {
    zipcode: 94103,
    title: 'SWITCH COMMERCE INC.',
    description: '24    6TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78163,
    latitude: -122.40968
  },
  {
    zipcode: 94103,
    title: 'SWITCH COMMERCE INC.',
    description: '24    6TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78163,
    latitude: -122.40968
  },
  {
    zipcode: 94103,
    title: 'PULSE NETWORK',
    description: '6    6TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78163,
    latitude: -122.40968
  },
  {
    zipcode: 94112,
    title: 'FIS',
    description: '250    GOLDEN GATE AVE, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.78178,
    latitude: -122.41515
  },
  {
    zipcode: 94107,
    title: 'FIS',
    description: '598    2ND ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.78178,
    latitude: -122.39214
  },
  {
    zipcode: 94115,
    title: 'CARDTRONICS',
    description: '1363    DIVISADERO ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78181,
    latitude: -122.43931
  },
  {
    zipcode: 94102,
    title: 'RBS WorldPay',
    description: '112    HYDE ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78186,
    latitude: -122.41545
  },
  {
    zipcode: 94103,
    title: 'ACFN',
    description: '888    HOWARD ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78199,
    latitude: -122.40445
  },
  {
    zipcode: 94121,
    title: 'FIS',
    description: '2147    CLEMENT ST, San Francisco, CA 94121',
    surcharge: true,
    longitude: 37.78205,
    latitude: -122.4819
  },
  {
    zipcode: 94121,
    title: 'CARDTRONICS',
    description: '377    32ND AVE, San Francisco, CA 94121',
    surcharge: true,
    longitude: 37.78205,
    latitude: -122.49249
  },
  {
    zipcode: 94102,
    title: 'SWITCH COMMERCE INC.',
    description: '161    HYDE ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78207,
    latitude: -122.41568
  },
  {
    zipcode: 94118,
    title: 'BANK OF AMERICA',
    description: '2835    GEARY BLVD, San Francisco, CA 94118',
    surcharge: false,
    longitude: 37.78207,
    latitude: -122.44968
  },
  {
    zipcode: 94118,
    title: 'BANK OF AMERICA',
    description: '2835    GEARY BLVD, San Francisco, CA 94118',
    surcharge: false,
    longitude: 37.78207,
    latitude: -122.44968
  },
  {
    zipcode: 94102,
    title: 'MONEYPASS',
    description: '711    VAN NESS AVE, San Francisco, CA 94102',
    surcharge: false,
    longitude: 37.78207,
    latitude: -122.42083
  },
  {
    zipcode: 94102,
    title: 'PULSE NETWORK',
    description: '748    VAN NESS AVE, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78211,
    latitude: -122.42048
  },
  {
    zipcode: 94102,
    title: 'CARDTRONICS',
    description: '790    VAN NESS AVE, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78211,
    latitude: -122.42048
  },
  {
    zipcode: 94118,
    title: 'RBS WorldPay',
    description: '2675    GEARY BLVD, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78225,
    latitude: -122.447
  },
  {
    zipcode: 94118,
    title: 'CARDTRONICS',
    description: '2675    GEARY BLVD, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78225,
    latitude: -122.447
  },
  {
    zipcode: 94102,
    title: 'FIS',
    description: '124    JONES ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78232,
    latitude: -122.41218
  },
  {
    zipcode: 94102,
    title: 'PULSE NETWORK',
    description: '479    TURK ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78238,
    latitude: -122.41652
  },
  {
    zipcode: 94115,
    title: 'PULSE NETWORK',
    description: '1440    FILLMORE ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78248,
    latitude: -122.43245
  },
  {
    zipcode: 94118,
    title: 'FIS',
    description: '1019    CLEMENT ST, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78258,
    latitude: -122.47025
  },
  {
    zipcode: 94118,
    title: 'MONEYPASS',
    description: '317    6TH AVE, San Francisco, CA 94118',
    surcharge: false,
    longitude: 37.78261,
    latitude: -122.46449
  },
  {
    zipcode: 94118,
    title: 'MONEYPASS',
    description: '919    CLEMENT ST, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78266,
    latitude: -122.46871
  },
  {
    zipcode: 94102,
    title: 'FIS',
    description: '301    TURK ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78267,
    latitude: -122.41428
  },
  {
    zipcode: 94102,
    title: 'PULSE NETWORK',
    description: '500    LARKIN ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.7827,
    latitude: -122.41731
  },
  {
    zipcode: 94102,
    title: 'PULSE NETWORK',
    description: '570    LARKIN ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.7827,
    latitude: -122.41731
  },
  {
    zipcode: 94118,
    title: 'BANK OF THE WEST',
    description: '801    CLEMENT ST, San Francisco, CA 94118',
    surcharge: false,
    longitude: 37.7827,
    latitude: -122.46778
  },
  {
    zipcode: 94109,
    title: 'FIS',
    description: '904    EDDY ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78273,
    latitude: -122.42274
  },
  {
    zipcode: 94118,
    title: 'CARDTRONICS',
    description: '745    CLEMENT ST, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78275,
    latitude: -122.46675
  },
  {
    zipcode: 94102,
    title: 'RBS WorldPay',
    description: '352    TURK ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78277,
    latitude: -122.41493
  },
  {
    zipcode: 94103,
    title: 'PULSE NETWORK',
    description: '85    5TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78281,
    latitude: -122.40643
  },
  {
    zipcode: 94118,
    title: 'WELLS FARGO BANK',
    description: '599    CLEMENT ST, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78283,
    latitude: -122.46464
  },
  {
    zipcode: 94118,
    title: 'WELLS FARGO BANK',
    description: '599    CLEMENT ST, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78283,
    latitude: -122.46464
  },
  {
    zipcode: 94102,
    title: 'SWITCH COMMERCE INC.',
    description: '201A    TURK ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78285,
    latitude: -122.41287
  },
  {
    zipcode: 94103,
    title: 'PULSE NETWORK',
    description: '200    4TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.7829,
    latitude: -122.40241
  },
  {
    zipcode: 94102,
    title: 'RBS WorldPay',
    description: '201    TURK ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78291,
    latitude: -122.4124
  },
  {
    zipcode: 94118,
    title: 'CHASE',
    description: '301    CLEMENT ST, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78293,
    latitude: -122.46262
  },
  {
    zipcode: 94118,
    title: 'CHASE',
    description: '301    CLEMENT ST, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78293,
    latitude: -122.46262
  },
  {
    zipcode: 94118,
    title: 'BANK OF AMERICA',
    description: '600    CLEMENT ST, San Francisco, CA 94118',
    surcharge: false,
    longitude: 37.78296,
    latitude: -122.46586
  },
  {
    zipcode: 94118,
    title: 'BANK OF AMERICA',
    description: '600    CLEMENT ST, San Francisco, CA 94118',
    surcharge: false,
    longitude: 37.78296,
    latitude: -122.46586
  },
  {
    zipcode: 94102,
    title: 'PULSE NETWORK',
    description: '225    LEAVENWORTH ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.783,
    latitude: -122.41418
  },
  {
    zipcode: 94102,
    title: 'RBS WorldPay',
    description: '253    LEAVENWORTH ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.783,
    latitude: -122.41418
  },
  {
    zipcode: 94115,
    title: 'WELLS FARGO BANK',
    description: '1335    WEBSTER ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78301,
    latitude: -122.43106
  },
  {
    zipcode: 94115,
    title: 'WELLS FARGO BANK',
    description: '1335    WEBSTER ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78301,
    latitude: -122.43106
  },
  {
    zipcode: 94115,
    title: 'WELLS FARGO BANK',
    description: '1335    WEBSTER ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78301,
    latitude: -122.43106
  },
  {
    zipcode: 94118,
    title: 'PULSE NETWORK',
    description: '500    CLEMENT ST, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78301,
    latitude: -122.46467
  },
  {
    zipcode: 94118,
    title: 'MONEYPASS',
    description: '498    CLEMENT ST, San Francisco, CA 94118',
    surcharge: false,
    longitude: 37.78303,
    latitude: -122.46442
  },
  {
    zipcode: 94115,
    title: 'FIS',
    description: '2338    GEARY BLVD, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78314,
    latitude: -122.44202
  },
  {
    zipcode: 94115,
    title: 'FIS',
    description: '2338    GEARY BLVD, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78314,
    latitude: -122.44202
  },
  {
    zipcode: 94102,
    title: 'SWITCH COMMERCE INC.',
    description: '200    LEAVENWORTH ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78319,
    latitude: -122.41404
  },
  {
    zipcode: 94102,
    title: 'PULSE NETWORK',
    description: '201    JONES ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78319,
    latitude: -122.41254
  },
  {
    zipcode: 94103,
    title: 'RBS WorldPay',
    description: '800    HOWARD ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78332,
    latitude: -122.40277
  },
  {
    zipcode: 94102,
    title: 'RBS WorldPay',
    description: '62    TURK ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78339,
    latitude: -122.41008
  },
  {
    zipcode: 94102,
    title: 'RBS WorldPay',
    description: '84 # 90  TURK ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78339,
    latitude: -122.41008
  },
  {
    zipcode: 94102,
    title: 'RBS WorldPay',
    description: '84 # 90  TURK ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78339,
    latitude: -122.41008
  },
  {
    zipcode: 94105,
    title: 'BANK OF AMERICA',
    description: '345    3RD ST, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.7834,
    latitude: -122.39831
  },
  {
    zipcode: 94103,
    title: 'RBS WorldPay',
    description: '48    5TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78345,
    latitude: -122.40753
  },
  {
    zipcode: 94102,
    title: 'SWITCH COMMERCE INC.',
    description: '954    MARKET ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78345,
    latitude: -122.4088
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '499    EDDY ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78355,
    latitude: -122.41487
  },
  {
    zipcode: 94109,
    title: 'FIS',
    description: '500    EDDY ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.7836,
    latitude: -122.4159
  },
  {
    zipcode: 94103,
    title: 'PULSE NETWORK',
    description: '991    MARKET ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78361,
    latitude: -122.40831
  },
  {
    zipcode: 94102,
    title: 'SWITCH COMMERCE INC.',
    description: '39    MASON ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78365,
    latitude: -122.40926
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '995    ELLIS ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78365,
    latitude: -122.42163
  },
  {
    zipcode: 94115,
    title: 'PULSE NETWORK',
    description: '1567    FILLMORE ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78369,
    latitude: -122.43287
  },
  {
    zipcode: 94103,
    title: 'CHASE',
    description: '101    4TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78372,
    latitude: -122.40315
  },
  {
    zipcode: 94103,
    title: 'BANK OF AMERICA',
    description: '101    4TH ST, San Francisco, CA 94103',
    surcharge: false,
    longitude: 37.78372,
    latitude: -122.40315
  },
  {
    zipcode: 94102,
    title: 'SWITCH COMMERCE INC.',
    description: '345    EDDY ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78372,
    latitude: -122.41353
  },
  {
    zipcode: 94102,
    title: 'FIS',
    description: '399    EDDY ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78372,
    latitude: -122.41353
  },
  {
    zipcode: 94103,
    title: 'PULSE NETWORK',
    description: '801    MISSION ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78376,
    latitude: -122.40502
  },
  {
    zipcode: 94103,
    title: 'WELLS FARGO BANK',
    description: '833    MISSION ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78376,
    latitude: -122.40502
  },
  {
    zipcode: 94103,
    title: 'WELLS FARGO BANK',
    description: '833    MISSION ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78376,
    latitude: -122.40502
  },
  {
    zipcode: 94103,
    title: 'CHASE',
    description: '833    MISSION ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78376,
    latitude: -122.40502
  },
  {
    zipcode: 94102,
    title: 'RBS WorldPay',
    description: '289    EDDY ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78391,
    latitude: -122.41203
  },
  {
    zipcode: 94115,
    title: 'PULSE NETWORK',
    description: '2401    POST ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78392,
    latitude: -122.44207
  },
  {
    zipcode: 94102,
    title: 'SWITCH COMMERCE INC.',
    description: '10    MASON ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78394,
    latitude: -122.40913
  },
  {
    zipcode: 94109,
    title: 'SWITCH COMMERCE INC.',
    description: '684    LARKIN ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78396,
    latitude: -122.41756
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '302    HYDE ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78406,
    latitude: -122.4159
  },
  {
    zipcode: 94102,
    title: 'RBS WorldPay',
    description: '200    EDDY ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78408,
    latitude: -122.41208
  },
  {
    zipcode: 94103,
    title: 'RBS WorldPay',
    description: '747    HOWARD ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78412,
    latitude: -122.40146
  },
  {
    zipcode: 94102,
    title: 'PULSE NETWORK',
    description: '123    EDDY ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78416,
    latitude: -122.41004
  },
  {
    zipcode: 94102,
    title: 'RBS WorldPay',
    description: '199    EDDY ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78416,
    latitude: -122.41004
  },
  {
    zipcode: 94115,
    title: 'PULSE NETWORK',
    description: '1401    BAKER ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78425,
    latitude: -122.44315
  },
  {
    zipcode: 94109,
    title: 'RBS WorldPay',
    description: '920    VAN NESS AVE, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.7843,
    latitude: -122.42092
  },
  {
    zipcode: 94102,
    title: '1ST ISO PROCESSING',
    description: '333    JONES ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78433,
    latitude: -122.41276
  },
  {
    zipcode: 94102,
    title: 'PULSE NETWORK',
    description: '335    JONES ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78433,
    latitude: -122.41276
  },
  {
    zipcode: 94102,
    title: 'SWITCH COMMERCE INC.',
    description: '128    EDDY ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78437,
    latitude: -122.40981
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '595    ELLIS ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78439,
    latitude: -122.41576
  },
  {
    zipcode: 94115,
    title: 'MONEYPASS',
    description: '1469    WEBSTER ST, San Francisco, CA 94115',
    surcharge: false,
    longitude: 37.78447,
    latitude: -122.43121
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '709    LARKIN ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78451,
    latitude: -122.41785
  },
  {
    zipcode: 94103,
    title: 'CHASE',
    description: '865    MARKET ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78457,
    latitude: -122.4071
  },
  {
    zipcode: 94103,
    title: 'CHASE',
    description: '865    MARKET ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78457,
    latitude: -122.4071
  },
  {
    zipcode: 94103,
    title: 'BANK OF AMERICA',
    description: '865    MARKET ST, San Francisco, CA 94103',
    surcharge: false,
    longitude: 37.78457,
    latitude: -122.4071
  },
  {
    zipcode: 94115,
    title: 'FIS',
    description: '2601    SUTTER ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78458,
    latitude: -122.44434
  },
  {
    zipcode: 94109,
    title: 'SWITCH COMMERCE INC.',
    description: '500    ELLIS ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78469,
    latitude: -122.41482
  },
  {
    zipcode: 94102,
    title: 'RBS WorldPay',
    description: '402    ELLIS ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.7848,
    latitude: -122.41387
  },
  {
    zipcode: 94102,
    title: 'PULSE NETWORK',
    description: '468    ELLIS ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.7848,
    latitude: -122.41387
  },
  {
    zipcode: 94115,
    title: 'FIS',
    description: '1661    DIVISADERO ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78481,
    latitude: -122.43992
  },
  {
    zipcode: 94115,
    title: 'FIS',
    description: '1661    DIVISADERO ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78481,
    latitude: -122.43992
  },
  {
    zipcode: 94115,
    title: 'FIS',
    description: '1661    DIVISADERO ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78481,
    latitude: -122.43992
  },
  {
    zipcode: 94115,
    title: 'FIS',
    description: '1661    DIVISADERO ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78481,
    latitude: -122.43992
  },
  {
    zipcode: 94115,
    title: 'FIS',
    description: '1661    DIVISADERO ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78481,
    latitude: -122.43992
  },
  {
    zipcode: 94115,
    title: 'FIS',
    description: '1661    DIVISADERO ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78481,
    latitude: -122.43992
  },
  {
    zipcode: 94115,
    title: 'FIS',
    description: '1661    DIVISADERO ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78481,
    latitude: -122.43992
  },
  {
    zipcode: 94103,
    title: 'CARDTRONICS',
    description: '789    MISSION ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78486,
    latitude: -122.40362
  },
  {
    zipcode: 94102,
    title: 'BANK OF AMERICA',
    description: '1    POWELL ST, San Francisco, CA 94102',
    surcharge: false,
    longitude: 37.78494,
    latitude: -122.40783
  },
  {
    zipcode: 94102,
    title: 'BANK OF AMERICA',
    description: '1    POWELL ST, San Francisco, CA 94102',
    surcharge: false,
    longitude: 37.78494,
    latitude: -122.40783
  },
  {
    zipcode: 94102,
    title: 'BANK OF AMERICA',
    description: '1    POWELL ST, San Francisco, CA 94102',
    surcharge: false,
    longitude: 37.78494,
    latitude: -122.40783
  },
  {
    zipcode: 94102,
    title: 'BANK OF AMERICA',
    description: '1    POWELL ST, San Francisco, CA 94102',
    surcharge: false,
    longitude: 37.78494,
    latitude: -122.40783
  },
  {
    zipcode: 94102,
    title: 'BANK OF AMERICA',
    description: '1    POWELL ST, San Francisco, CA 94102',
    surcharge: false,
    longitude: 37.78494,
    latitude: -122.40783
  },
  {
    zipcode: 94102,
    title: 'BANK OF AMERICA',
    description: '1    POWELL ST, San Francisco, CA 94102',
    surcharge: false,
    longitude: 37.78494,
    latitude: -122.40783
  },
  {
    zipcode: 94102,
    title: 'BANK OF AMERICA',
    description: '1    POWELL ST, San Francisco, CA 94102',
    surcharge: false,
    longitude: 37.78494,
    latitude: -122.40783
  },
  {
    zipcode: 94102,
    title: 'PULSE NETWORK',
    description: '35    POWELL ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78494,
    latitude: -122.40783
  },
  {
    zipcode: 94102,
    title: 'PULSE NETWORK',
    description: '398    ELLIS ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78497,
    latitude: -122.41262
  },
  {
    zipcode: 94103,
    title: 'PULSE NETWORK',
    description: '55    4TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78505,
    latitude: -122.40483
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '888 STE 105  OFARRELL ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78507,
    latitude: -122.41938
  },
  {
    zipcode: 94103,
    title: 'WELLS FARGO BANK',
    description: '201    3RD ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78509,
    latitude: -122.4004
  },
  {
    zipcode: 94103,
    title: 'WELLS FARGO BANK',
    description: '201    3RD ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78509,
    latitude: -122.4004
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '701    OFARRELL ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78513,
    latitude: -122.41741
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '701    OFARRELL ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78513,
    latitude: -122.41741
  },
  {
    zipcode: 94109,
    title: 'RBS WorldPay',
    description: '799    OFARRELL ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78513,
    latitude: -122.41741
  },
  {
    zipcode: 94115,
    title: 'FIS',
    description: '2498    SUTTER ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78516,
    latitude: -122.44127
  },
  {
    zipcode: 94115,
    title: 'BANK OF AMERICA',
    description: '1700    FILLMORE ST, San Francisco, CA 94115',
    surcharge: false,
    longitude: 37.78528,
    latitude: -122.43301
  },
  {
    zipcode: 94118,
    title: 'RBS WorldPay',
    description: '4101    CALIFORNIA ST, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78528,
    latitude: -122.46155
  },
  {
    zipcode: 94109,
    title: 'RBS WorldPay',
    description: '784    OFARRELL ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78531,
    latitude: -122.41743
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '1050    VAN NESS AVE, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78536,
    latitude: -122.42115
  },
  {
    zipcode: 94102,
    title: 'PULSE NETWORK',
    description: '154    ELLIS ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78544,
    latitude: -122.40896
  },
  {
    zipcode: 94115,
    title: 'WELLS FARGO BANK',
    description: '1750    DIVISADERO ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.7855,
    latitude: -122.43978
  },
  {
    zipcode: 94115,
    title: 'WELLS FARGO BANK',
    description: '1750    DIVISADERO ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.7855,
    latitude: -122.43978
  },
  {
    zipcode: 94103,
    title: 'ELAN',
    description: '835 STE   MARKET ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.7855,
    latitude: -122.4059
  },
  {
    zipcode: 94102,
    title: 'FIS',
    description: '517    OFARRELL ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78554,
    latitude: -122.41422
  },
  {
    zipcode: 94102,
    title: 'PULSE NETWORK',
    description: '599    OFARRELL ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78554,
    latitude: -122.41422
  },
  {
    zipcode: 94109,
    title: 'CARDTRONICS',
    description: '1101    GEARY BLVD, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78556,
    latitude: -122.42162
  },
  {
    zipcode: 94107,
    title: 'WELLS FARGO BANK',
    description: '303    2ND ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.78557,
    latitude: -122.3966
  },
  {
    zipcode: 94107,
    title: 'WELLS FARGO BANK',
    description: '303    2ND ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.78557,
    latitude: -122.3966
  },
  {
    zipcode: 94115,
    title: 'UNION BANK',
    description: '1675    POST ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78564,
    latitude: -122.42854
  },
  {
    zipcode: 94115,
    title: 'UNION BANK',
    description: '1675    POST ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78564,
    latitude: -122.42854
  },
  {
    zipcode: 94115,
    title: 'PULSE NETWORK',
    description: '1600    POST ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78565,
    latitude: -122.42978
  },
  {
    zipcode: 94103,
    title: 'CARDTRONICS',
    description: '825    MARKET ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78565,
    latitude: -122.40579
  },
  {
    zipcode: 94115,
    title: 'SWITCH COMMERCE INC.',
    description: '2199    SUTTER ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78567,
    latitude: -122.43576
  },
  {
    zipcode: 94102,
    title: 'PULSE NETWORK',
    description: '118    POWELL ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78568,
    latitude: -122.40779
  },
  {
    zipcode: 94102,
    title: 'PULSE NETWORK',
    description: '596    OFARRELL ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78578,
    latitude: -122.41373
  },
  {
    zipcode: 94102,
    title: 'PULSE NETWORK',
    description: '411    OFARRELL ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78581,
    latitude: -122.41202
  },
  {
    zipcode: 94102,
    title: 'SWITCH COMMERCE INC.',
    description: '453    OFARRELL ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78581,
    latitude: -122.41202
  },
  {
    zipcode: 94109,
    title: 'RBS WorldPay',
    description: '986    POLK ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78586,
    latitude: -122.41964
  },
  {
    zipcode: 94109,
    title: 'FIS',
    description: '901    GEARY ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78593,
    latitude: -122.41868
  },
  {
    zipcode: 94102,
    title: 'CARDTRONICS',
    description: '135    POWELL ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78594,
    latitude: -122.40803
  },
  {
    zipcode: 94102,
    title: 'CARDTRONICS',
    description: '333    OFARRELL ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78604,
    latitude: -122.41021
  },
  {
    zipcode: 94105,
    title: 'FIS',
    description: '390    1ST ST, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.78609,
    latitude: -122.3931
  },
  {
    zipcode: 94109,
    title: 'CITIBANK',
    description: '1399    POST ST, San Francisco, CA 94109',
    surcharge: false,
    longitude: 37.7861,
    latitude: -122.42483
  },
  {
    zipcode: 94102,
    title: 'FIS',
    description: '525    JONES ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78611,
    latitude: -122.41312
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '920    GEARY ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78612,
    latitude: -122.4186
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '928    GEARY ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78612,
    latitude: -122.4186
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '958    GEARY ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78612,
    latitude: -122.4186
  },
  {
    zipcode: 94118,
    title: 'FIRST REPUBLIC BANK',
    description: '3700 # 1F  CALIFORNIA ST, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78619,
    latitude: -122.45588
  },
  {
    zipcode: 94102,
    title: 'BANK OF AMERICA',
    description: '213    OFARRELL ST, San Francisco, CA 94102',
    surcharge: false,
    longitude: 37.78629,
    latitude: -122.40826
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '842    GEARY ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.7863,
    latitude: -122.4172
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '868    GEARY ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.7863,
    latitude: -122.4172
  },
  {
    zipcode: 94103,
    title: 'PULSE NETWORK',
    description: '50    3RD ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78635,
    latitude: -122.4023
  },
  {
    zipcode: 94109,
    title: 'RBS WorldPay',
    description: '1047    POLK ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78641,
    latitude: -122.41993
  },
  {
    zipcode: 94102,
    title: 'PULSE NETWORK',
    description: '325    MASON ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78641,
    latitude: -122.40981
  },
  {
    zipcode: 94109,
    title: 'FIS',
    description: '1030    POLK ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78645,
    latitude: -122.41976
  },
  {
    zipcode: 94109,
    title: 'RBS WorldPay',
    description: '1042    POLK ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78645,
    latitude: -122.41976
  },
  {
    zipcode: 94102,
    title: 'PULSE NETWORK',
    description: '415    TAYLOR ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78645,
    latitude: -122.4115
  },
  {
    zipcode: 94118,
    title: 'BANK OF AMERICA',
    description: '3565    CALIFORNIA ST, San Francisco, CA 94118',
    surcharge: false,
    longitude: 37.78648,
    latitude: -122.4521
  },
  {
    zipcode: 94118,
    title: 'BANK OF AMERICA',
    description: '3565    CALIFORNIA ST, San Francisco, CA 94118',
    surcharge: false,
    longitude: 37.78648,
    latitude: -122.4521
  },
  {
    zipcode: 94102,
    title: 'RBS WorldPay',
    description: '689    GEARY ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78648,
    latitude: -122.41434
  },
  {
    zipcode: 94109,
    title: 'FIS',
    description: '700    GEARY ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78649,
    latitude: -122.41571
  },
  {
    zipcode: 94109,
    title: 'FIS',
    description: '798    GEARY ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78649,
    latitude: -122.41571
  },
  {
    zipcode: 94115,
    title: 'CARDTRONICS',
    description: '1899    FILLMORE ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.7865,
    latitude: -122.43344
  },
  {
    zipcode: 94102,
    title: 'FIS',
    description: '170    OFARRELL ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78652,
    latitude: -122.4078
  },
  {
    zipcode: 94118,
    title: 'WELLS FARGO BANK',
    description: '3431    CALIFORNIA ST, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78661,
    latitude: -122.4511
  },
  {
    zipcode: 94118,
    title: 'WELLS FARGO BANK',
    description: '3431    CALIFORNIA ST, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78661,
    latitude: -122.4511
  },
  {
    zipcode: 94118,
    title: 'UNION BANK',
    description: '3473    CALIFORNIA ST, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78661,
    latitude: -122.4511
  },
  {
    zipcode: 94118,
    title: 'UNION BANK',
    description: '3473    CALIFORNIA ST, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78661,
    latitude: -122.4511
  },
  {
    zipcode: 94109,
    title: 'SWITCH COMMERCE INC.',
    description: '955    LARKIN ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78672,
    latitude: -122.4183
  },
  {
    zipcode: 94102,
    title: 'ACFN',
    description: '401    GEARY ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78686,
    latitude: -122.41141
  },
  {
    zipcode: 94109,
    title: 'CARDTRONICS',
    description: '1301    FRANKLIN ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78689,
    latitude: -122.4234
  },
  {
    zipcode: 94102,
    title: 'PULSE NETWORK',
    description: '560    GEARY ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78691,
    latitude: -122.41239
  },
  {
    zipcode: 94102,
    title: 'RBS WorldPay',
    description: '516    GEARY ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78694,
    latitude: -122.4122
  },
  {
    zipcode: 94103,
    title: 'CARDTRONICS',
    description: '731    MARKET ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78695,
    latitude: -122.40406
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '1012    POST ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.7871,
    latitude: -122.41845
  },
  {
    zipcode: 94105,
    title: 'CARDTRONICS',
    description: '116    NEW MONTGOMERY ST, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.78714,
    latitude: -122.40027
  },
  {
    zipcode: 94105,
    title: 'RBS WorldPay',
    description: '111    MINNA ST, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.78715,
    latitude: -122.39964
  },
  {
    zipcode: 94103,
    title: 'CARDTRONICS',
    description: '711    MARKET ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.7873,
    latitude: -122.40363
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '900    POST ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78731,
    latitude: -122.41677
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '1355    SUTTER ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78738,
    latitude: -122.42232
  },
  {
    zipcode: 94109,
    title: 'RBS WorldPay',
    description: '1400    SUTTER ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78739,
    latitude: -122.42365
  },
  {
    zipcode: 94108,
    title: 'WELLS FARGO BANK',
    description: '2    GRANT AVE, San Francisco, CA 94108',
    surcharge: true,
    longitude: 37.78743,
    latitude: -122.40488
  },
  {
    zipcode: 94108,
    title: 'WELLS FARGO BANK',
    description: '2    GRANT AVE, San Francisco, CA 94108',
    surcharge: true,
    longitude: 37.78743,
    latitude: -122.40488
  },
  {
    zipcode: 94108,
    title: 'WELLS FARGO BANK',
    description: '2    GRANT AVE, San Francisco, CA 94108',
    surcharge: true,
    longitude: 37.78743,
    latitude: -122.40488
  },
  {
    zipcode: 94108,
    title: 'WELLS FARGO BANK',
    description: '2    GRANT AVE, San Francisco, CA 94108',
    surcharge: true,
    longitude: 37.78743,
    latitude: -122.40488
  },
  {
    zipcode: 94115,
    title: 'WELLS FARGO BANK',
    description: '3150    CALIFORNIA ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78743,
    latitude: -122.44612
  },
  {
    zipcode: 94109,
    title: 'CARDTRONICS',
    description: '1285    SUTTER ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78748,
    latitude: -122.4215
  },
  {
    zipcode: 94102,
    title: 'BANK OF AMERICA',
    description: '335    POWELL ST, San Francisco, CA 94102',
    surcharge: false,
    longitude: 37.78768,
    latitude: -122.40838
  },
  {
    zipcode: 94102,
    title: 'RBS WorldPay',
    description: '335    POWELL ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78768,
    latitude: -122.40838
  },
  {
    zipcode: 94102,
    title: 'CHASE',
    description: '700    MARKET ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.7877,
    latitude: -122.40351
  },
  {
    zipcode: 94102,
    title: 'CHASE',
    description: '700    MARKET ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.7877,
    latitude: -122.40351
  },
  {
    zipcode: 94102,
    title: 'CHASE',
    description: '700    MARKET ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.7877,
    latitude: -122.40351
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '708    POST ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.7877,
    latitude: -122.4137
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '728    POST ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.7877,
    latitude: -122.4137
  },
  {
    zipcode: 94102,
    title: 'CARDTRONICS',
    description: '730    MARKET ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.7877,
    latitude: -122.40351
  },
  {
    zipcode: 94109,
    title: 'FIS',
    description: '1185    SUTTER ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78782,
    latitude: -122.41882
  },
  {
    zipcode: 94105,
    title: 'CARDTRONICS',
    description: '601    MISSION ST, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.78786,
    latitude: -122.39983
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '600    POST ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78795,
    latitude: -122.41172
  },
  {
    zipcode: 94109,
    title: 'FIS',
    description: '606    POST ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78795,
    latitude: -122.41172
  },
  {
    zipcode: 94102,
    title: 'WELLS FARGO BANK',
    description: '760    MARKET ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78796,
    latitude: -122.40324
  },
  {
    zipcode: 94102,
    title: 'WELLS FARGO BANK',
    description: '760    MARKET ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78796,
    latitude: -122.40324
  },
  {
    zipcode: 94105,
    title: 'CARDTRONICS',
    description: '644    MISSION ST, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.78797,
    latitude: -122.39998
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '1200    POLK ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78803,
    latitude: -122.42008
  },
  {
    zipcode: 94105,
    title: 'PULSE NETWORK',
    description: '201    HARRISON ST, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.78806,
    latitude: -122.39026
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '1203    POLK ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78809,
    latitude: -122.42027
  },
  {
    zipcode: 94104,
    title: 'CARDTRONICS',
    description: '690    MARKET ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.78828,
    latitude: -122.40284
  },
  {
    zipcode: 94102,
    title: 'PULSE NETWORK',
    description: '488    POST ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78829,
    latitude: -122.40908
  },
  {
    zipcode: 94108,
    title: 'CARDTRONICS',
    description: '333    POST ST, San Francisco, CA 94108',
    surcharge: true,
    longitude: 37.78834,
    latitude: -122.40729
  },
  {
    zipcode: 94109,
    title: 'FIS',
    description: '1233    POLK ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78836,
    latitude: -122.42033
  },
  {
    zipcode: 94115,
    title: 'CITIBANK',
    description: '3296    SACRAMENTO ST, San Francisco, CA 94115',
    surcharge: false,
    longitude: 37.78837,
    latitude: -122.44619
  },
  {
    zipcode: 94115,
    title: 'CITIBANK',
    description: '3296    SACRAMENTO ST, San Francisco, CA 94115',
    surcharge: false,
    longitude: 37.78837,
    latitude: -122.44619
  },
  {
    zipcode: 94102,
    title: 'CHASE',
    description: '400    POST ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78837,
    latitude: -122.40844
  },
  {
    zipcode: 94102,
    title: 'CHASE',
    description: '400    POST ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78837,
    latitude: -122.40844
  },
  {
    zipcode: 94102,
    title: 'CHASE',
    description: '400    POST ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78837,
    latitude: -122.40844
  },
  {
    zipcode: 94105,
    title: 'BANK OF AMERICA',
    description: '33    NEW MONTGOMERY ST, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.78839,
    latitude: -122.40152
  },
  {
    zipcode: 94105,
    title: 'BANK OF AMERICA',
    description: '33    NEW MONTGOMERY ST, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.78839,
    latitude: -122.40152
  },
  {
    zipcode: 94105,
    title: 'BANK OF AMERICA',
    description: '33    NEW MONTGOMERY ST, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.78839,
    latitude: -122.40152
  },
  {
    zipcode: 94105,
    title: 'BANK OF AMERICA',
    description: '33    NEW MONTGOMERY ST, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.78839,
    latitude: -122.40152
  },
  {
    zipcode: 94105,
    title: 'BANK OF AMERICA',
    description: '33    NEW MONTGOMERY ST, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.78839,
    latitude: -122.40152
  },
  {
    zipcode: 94105,
    title: 'BANK OF AMERICA',
    description: '33    NEW MONTGOMERY ST, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.78839,
    latitude: -122.40152
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '908    SUTTER ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78839,
    latitude: -122.41587
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '920    SUTTER ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78839,
    latitude: -122.41587
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '988    SUTTER ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78839,
    latitude: -122.41587
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '1528    FRANKLIN ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78844,
    latitude: -122.42353
  },
  {
    zipcode: 94105,
    title: 'CHASE',
    description: '555    MISSION ST, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.78862,
    latitude: -122.39887
  },
  {
    zipcode: 94108,
    title: 'CAPITAL ONE',
    description: '101    POST ST, San Francisco, CA 94108',
    surcharge: false,
    longitude: 37.78863,
    latitude: -122.40495
  },
  {
    zipcode: 94108,
    title: 'CAPITAL ONE',
    description: '101    POST ST, San Francisco, CA 94108',
    surcharge: false,
    longitude: 37.78863,
    latitude: -122.40495
  },
  {
    zipcode: 94115,
    title: 'PULSE NETWORK',
    description: '2500    CALIFORNIA ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78866,
    latitude: -122.43646
  },
  {
    zipcode: 94102,
    title: 'BANK OF AMERICA',
    description: '445    POWELL ST, San Francisco, CA 94102',
    surcharge: false,
    longitude: 37.78873,
    latitude: -122.40858
  },
  {
    zipcode: 94102,
    title: 'BANK OF AMERICA',
    description: '445    POWELL ST, San Francisco, CA 94102',
    surcharge: false,
    longitude: 37.78873,
    latitude: -122.40858
  },
  {
    zipcode: 94102,
    title: 'BANK OF AMERICA',
    description: '445    POWELL ST, San Francisco, CA 94102',
    surcharge: false,
    longitude: 37.78873,
    latitude: -122.40858
  },
  {
    zipcode: 94102,
    title: 'CARDTRONICS',
    description: '459    POWELL ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78873,
    latitude: -122.40858
  },
  {
    zipcode: 94115,
    title: 'CHASE',
    description: '2429    CALIFORNIA ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78876,
    latitude: -122.4342
  },
  {
    zipcode: 94115,
    title: 'CHASE',
    description: '2429    CALIFORNIA ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78876,
    latitude: -122.4342
  },
  {
    zipcode: 94115,
    title: 'CHASE',
    description: '2429    CALIFORNIA ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78876,
    latitude: -122.4342
  },
  {
    zipcode: 94115,
    title: 'CHASE',
    description: '2435    CALIFORNIA ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78876,
    latitude: -122.4342
  },
  {
    zipcode: 94104,
    title: 'CITIBANK',
    description: '99    POST ST, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.7888,
    latitude: -122.40364
  },
  {
    zipcode: 94104,
    title: 'CITIBANK',
    description: '99    POST ST, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.7888,
    latitude: -122.40364
  },
  {
    zipcode: 94104,
    title: 'CITIBANK',
    description: '99    POST ST, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.7888,
    latitude: -122.40364
  },
  {
    zipcode: 94104,
    title: 'CITIBANK',
    description: '99    POST ST, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.7888,
    latitude: -122.40364
  },
  {
    zipcode: 94104,
    title: 'RBS WorldPay',
    description: '1    POST ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.78893,
    latitude: -122.40262
  },
  {
    zipcode: 94105,
    title: 'CHASE',
    description: '560    MISSION ST, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.78894,
    latitude: -122.39875
  },
  {
    zipcode: 94104,
    title: 'WELLS FARGO BANK',
    description: '1    MONTGOMERY ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.78909,
    latitude: -122.40208
  },
  {
    zipcode: 94104,
    title: 'WELLS FARGO BANK',
    description: '1    MONTGOMERY ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.78909,
    latitude: -122.40208
  },
  {
    zipcode: 94104,
    title: 'WELLS FARGO BANK',
    description: '1    MONTGOMERY ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.78909,
    latitude: -122.40208
  },
  {
    zipcode: 94104,
    title: 'WELLS FARGO BANK',
    description: '1    MONTGOMERY ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.78909,
    latitude: -122.40208
  },
  {
    zipcode: 94104,
    title: 'WELLS FARGO BANK',
    description: '1    MONTGOMERY ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.78909,
    latitude: -122.40208
  },
  {
    zipcode: 94104,
    title: 'WELLS FARGO BANK',
    description: '1    MONTGOMERY ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.78909,
    latitude: -122.40208
  },
  {
    zipcode: 94104,
    title: 'WELLS FARGO BANK',
    description: '1    MONTGOMERY ST, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.78909,
    latitude: -122.40208
  },
  {
    zipcode: 94108,
    title: 'CARDTRONICS',
    description: '141    KEARNY ST, San Francisco, CA 94108',
    surcharge: true,
    longitude: 37.78913,
    latitude: -122.40379
  },
  {
    zipcode: 94105,
    title: 'CITIBANK',
    description: '405    HOWARD ST, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.78913,
    latitude: -122.39513
  },
  {
    zipcode: 94105,
    title: 'MONEYPASS',
    description: '215    FREMONT ST, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.78914,
    latitude: -122.39489
  },
  {
    zipcode: 94115,
    title: 'WELLS FARGO BANK',
    description: '2100    FILLMORE ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78919,
    latitude: -122.4338
  },
  {
    zipcode: 94115,
    title: 'WELLS FARGO BANK',
    description: '2100    FILLMORE ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78919,
    latitude: -122.4338
  },
  {
    zipcode: 94115,
    title: 'WELLS FARGO BANK',
    description: '2100    FILLMORE ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78919,
    latitude: -122.4338
  },
  {
    zipcode: 94115,
    title: 'WELLS FARGO BANK',
    description: '2100    FILLMORE ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78919,
    latitude: -122.4338
  },
  {
    zipcode: 94105,
    title: 'WELLS FARGO BANK',
    description: '536    MISSION ST, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.78921,
    latitude: -122.39841
  },
  {
    zipcode: 94105,
    title: 'CHASE',
    description: '595    MARKET ST, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.78921,
    latitude: -122.40122
  },
  {
    zipcode: 94105,
    title: 'CHASE',
    description: '595    MARKET ST, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.78921,
    latitude: -122.40122
  },
  {
    zipcode: 94109,
    title: 'SWITCH COMMERCE INC.',
    description: '1330    POLK ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78923,
    latitude: -122.42032
  },
  {
    zipcode: 94102,
    title: 'WELLS FARGO BANK',
    description: '400    HOWARD ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78924,
    latitude: -122.39528
  },
  {
    zipcode: 94102,
    title: 'WELLS FARGO BANK',
    description: '400    HOWARD ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78924,
    latitude: -122.39528
  },
  {
    zipcode: 94104,
    title: 'CITIBANK',
    description: '590    MARKET ST, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.78927,
    latitude: -122.40158
  },
  {
    zipcode: 94104,
    title: 'CITIBANK',
    description: '590    MARKET ST, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.78927,
    latitude: -122.40158
  },
  {
    zipcode: 94104,
    title: 'CITIBANK',
    description: '590    MARKET ST, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.78927,
    latitude: -122.40158
  },
  {
    zipcode: 94104,
    title: 'PULSE NETWORK',
    description: '598    MARKET ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.78927,
    latitude: -122.40158
  },
  {
    zipcode: 94108,
    title: 'WELLS FARGO BANK',
    description: '120    KEARNY ST, San Francisco, CA 94108',
    surcharge: true,
    longitude: 37.78929,
    latitude: -122.40345
  },
  {
    zipcode: 94108,
    title: 'WELLS FARGO BANK',
    description: '120    KEARNY ST, San Francisco, CA 94108',
    surcharge: true,
    longitude: 37.78929,
    latitude: -122.40345
  },
  {
    zipcode: 94105,
    title: 'RBS WorldPay',
    description: '199    FREMONT ST, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.7893,
    latitude: -122.3951
  },
  {
    zipcode: 94104,
    title: 'WELLS FARGO BANK',
    description: '544    MARKET ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.78938,
    latitude: -122.40143
  },
  {
    zipcode: 94104,
    title: 'WELLS FARGO BANK',
    description: '544    MARKET ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.78938,
    latitude: -122.40143
  },
  {
    zipcode: 94104,
    title: 'WELLS FARGO BANK',
    description: '544    MARKET ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.78938,
    latitude: -122.40143
  },
  {
    zipcode: 94104,
    title: 'WELLS FARGO BANK',
    description: '544    MARKET ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.78938,
    latitude: -122.40143
  },
  {
    zipcode: 94108,
    title: 'WELLS FARGO BANK',
    description: '460    SUTTER ST, San Francisco, CA 94108',
    surcharge: true,
    longitude: 37.7894,
    latitude: -122.40788
  },
  {
    zipcode: 94104,
    title: 'CARDTRONICS',
    description: '564    MARKET ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.78942,
    latitude: -122.40138
  },
  {
    zipcode: 94105,
    title: 'CARDTRONICS',
    description: '581    MARKET ST, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.78947,
    latitude: -122.40088
  },
  {
    zipcode: 94108,
    title: 'CARDTRONICS',
    description: '400    SUTTER ST, San Francisco, CA 94108',
    surcharge: true,
    longitude: 37.78948,
    latitude: -122.40724
  },
  {
    zipcode: 94104,
    title: 'UNION BANK',
    description: '44    MONTGOMERY ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.78953,
    latitude: -122.40199
  },
  {
    zipcode: 94104,
    title: 'FIRST REPUBLIC BANK',
    description: '44    MONTGOMERY ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.78953,
    latitude: -122.40199
  },
  {
    zipcode: 94104,
    title: 'UNION BANK',
    description: '44    MONTGOMERY ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.78953,
    latitude: -122.40199
  },
  {
    zipcode: 94108,
    title: 'CARDTRONICS',
    description: '217    SUTTER ST, San Francisco, CA 94108',
    surcharge: true,
    longitude: 37.78969,
    latitude: -122.4042
  },
  {
    zipcode: 94111,
    title: 'BANK OF THE WEST',
    description: '555    MARKET ST, San Francisco, CA 94111',
    surcharge: false,
    longitude: 37.78994,
    latitude: -122.40028
  },
  {
    zipcode: 94104,
    title: 'CHASE',
    description: '101    MONTGOMERY ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.79005,
    latitude: -122.40228
  },
  {
    zipcode: 94109,
    title: 'ACFN',
    description: '1500    VAN NESS AVE, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.79006,
    latitude: -122.42207
  },
  {
    zipcode: 94109,
    title: 'WELLS FARGO BANK',
    description: '1560    VAN NESS AVE, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.79006,
    latitude: -122.42207
  },
  {
    zipcode: 94109,
    title: 'WELLS FARGO BANK',
    description: '1560    VAN NESS AVE, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.79006,
    latitude: -122.42207
  },
  {
    zipcode: 94109,
    title: 'WELLS FARGO BANK',
    description: '1560    VAN NESS AVE, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.79006,
    latitude: -122.42207
  },
  {
    zipcode: 94109,
    title: 'WELLS FARGO BANK',
    description: '1560    VAN NESS AVE, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.79006,
    latitude: -122.42207
  },
  {
    zipcode: 94105,
    title: 'CARDTRONICS',
    description: '456    MISSION ST, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.79013,
    latitude: -122.39725
  },
  {
    zipcode: 94105,
    title: 'PULSE NETWORK',
    description: '237    KEARNY ST, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.79015,
    latitude: -122.40399
  },
  {
    zipcode: 94109,
    title: 'FIS',
    description: '1191    PINE ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.79018,
    latitude: -122.41541
  },
  {
    zipcode: 94105,
    title: 'RBS WorldPay',
    description: '425    MISSION ST, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.79021,
    latitude: -122.39685
  },
  {
    zipcode: 94104,
    title: 'CITIBANK',
    description: '1    SANSOME ST, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.79023,
    latitude: -122.40064
  },
  {
    zipcode: 94104,
    title: 'CITIBANK',
    description: '1    SANSOME ST, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.79023,
    latitude: -122.40064
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '1100    PINE ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.79048,
    latitude: -122.41443
  },
  {
    zipcode: 94105,
    title: 'MONEYPASS',
    description: '211    MAIN ST, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.79055,
    latitude: -122.39318
  },
  {
    zipcode: 94108,
    title: 'PULSE NETWORK',
    description: '996    PINE ST, San Francisco, CA 94108',
    surcharge: true,
    longitude: 37.79077,
    latitude: -122.41218
  },
  {
    zipcode: 94109,
    title: 'BANK OF AMERICA',
    description: '1640    VAN NESS AVE, San Francisco, CA 94109',
    surcharge: false,
    longitude: 37.79079,
    latitude: -122.42221
  },
  {
    zipcode: 94109,
    title: 'BANK OF AMERICA',
    description: '1640    VAN NESS AVE, San Francisco, CA 94109',
    surcharge: false,
    longitude: 37.79079,
    latitude: -122.42221
  },
  {
    zipcode: 94109,
    title: 'BANK OF AMERICA',
    description: '1640    VAN NESS AVE, San Francisco, CA 94109',
    surcharge: false,
    longitude: 37.79079,
    latitude: -122.42221
  },
  {
    zipcode: 94105,
    title: 'FIS',
    description: '180 STE G2  HOWARD ST, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.79081,
    latitude: -122.39329
  },
  {
    zipcode: 94104,
    title: 'BANK OF THE WEST',
    description: '295    BUSH ST, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.79088,
    latitude: -122.40234
  },
  {
    zipcode: 94104,
    title: 'BANK OF THE WEST',
    description: '295    BUSH ST, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.79088,
    latitude: -122.40234
  },
  {
    zipcode: 94104,
    title: 'BANK OF THE WEST',
    description: '295    BUSH ST, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.79088,
    latitude: -122.40234
  },
  {
    zipcode: 94115,
    title: 'BANK OF AMERICA',
    description: '2310    FILLMORE ST, San Francisco, CA 94115',
    surcharge: false,
    longitude: 37.79092,
    latitude: -122.43415
  },
  {
    zipcode: 94115,
    title: 'BANK OF AMERICA',
    description: '2310    FILLMORE ST, San Francisco, CA 94115',
    surcharge: false,
    longitude: 37.79092,
    latitude: -122.43415
  },
  {
    zipcode: 94109,
    title: 'CHASE',
    description: '1500    POLK ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.79098,
    latitude: -122.42067
  },
  {
    zipcode: 94109,
    title: 'CHASE',
    description: '1500    POLK ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.79098,
    latitude: -122.42067
  },
  {
    zipcode: 94109,
    title: 'CHASE',
    description: '1500    POLK ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.79098,
    latitude: -122.42067
  },
  {
    zipcode: 94109,
    title: 'CARDTRONICS',
    description: '1524    POLK ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.79098,
    latitude: -122.42067
  },
  {
    zipcode: 94105,
    title: 'BANK OF THE WEST',
    description: '301    MISSION ST, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.79107,
    latitude: -122.39576
  },
  {
    zipcode: 94105,
    title: 'BANK OF AMERICA',
    description: '425    MARKET ST, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.79112,
    latitude: -122.39812
  },
  {
    zipcode: 94105,
    title: 'BANK OF AMERICA',
    description: '425    MARKET ST, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.79112,
    latitude: -122.39812
  },
  {
    zipcode: 94105,
    title: 'BANK OF AMERICA',
    description: '425    MARKET ST, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.79112,
    latitude: -122.39812
  },
  {
    zipcode: 94108,
    title: 'RBS WorldPay',
    description: '723    PINE ST, San Francisco, CA 94108',
    surcharge: true,
    longitude: 37.79115,
    latitude: -122.40776
  },
  {
    zipcode: 94104,
    title: 'CARDTRONICS',
    description: '100    SANSOME ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.79119,
    latitude: -122.40065
  },
  {
    zipcode: 94105,
    title: 'PULSE NETWORK',
    description: '98    HOWARD ST, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.79138,
    latitude: -122.39257
  },
  {
    zipcode: 94111,
    title: 'FIRST REPUBLIC BANK',
    description: '1    FRONT ST, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.7915,
    latitude: -122.39875
  },
  {
    zipcode: 94111,
    title: 'FIRST REPUBLIC BANK',
    description: '36    BATTERY ST, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.79167,
    latitude: -122.39955
  },
  {
    zipcode: 94105,
    title: 'CHEVRON FCU',
    description: '50    BEALE ST, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.7917,
    latitude: -122.39665
  },
  {
    zipcode: 94105,
    title: 'MONEYPASS',
    description: '50 LBBY   BEALE ST, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.7917,
    latitude: -122.39665
  },
  {
    zipcode: 94105,
    title: 'WELLS FARGO BANK',
    description: '333    MARKET ST, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.79177,
    latitude: -122.39751
  },
  {
    zipcode: 94105,
    title: 'WELLS FARGO BANK',
    description: '333    MARKET ST, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.79177,
    latitude: -122.39751
  },
  {
    zipcode: 94105,
    title: 'WELLS FARGO BANK',
    description: '333    MARKET ST, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.79177,
    latitude: -122.39751
  },
  {
    zipcode: 94104,
    title: 'MONEYPASS',
    description: '300 STE 100  MONTGOMERY ST, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.79192,
    latitude: -122.40248
  },
  {
    zipcode: 94104,
    title: 'BANK OF AMERICA',
    description: '345    MONTGOMERY ST, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.79211,
    latitude: -122.4027
  },
  {
    zipcode: 94104,
    title: 'BANK OF AMERICA',
    description: '345    MONTGOMERY ST, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.79211,
    latitude: -122.4027
  },
  {
    zipcode: 94104,
    title: 'BANK OF AMERICA',
    description: '345    MONTGOMERY ST, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.79211,
    latitude: -122.4027
  },
  {
    zipcode: 94104,
    title: 'BANK OF AMERICA',
    description: '345    MONTGOMERY ST, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.79211,
    latitude: -122.4027
  },
  {
    zipcode: 94104,
    title: 'BANK OF AMERICA',
    description: '345    MONTGOMERY ST, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.79211,
    latitude: -122.4027
  },
  {
    zipcode: 94109,
    title: 'CITIBANK',
    description: '1801    VAN NESS AVE, San Francisco, CA 94109',
    surcharge: false,
    longitude: 37.79216,
    latitude: -122.42278
  },
  {
    zipcode: 94109,
    title: 'CITIBANK',
    description: '1801    VAN NESS AVE, San Francisco, CA 94109',
    surcharge: false,
    longitude: 37.79216,
    latitude: -122.42278
  },
  {
    zipcode: 94111,
    title: 'CARDTRONICS',
    description: '195    PINE ST, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.79217,
    latitude: -122.39969
  },
  {
    zipcode: 94104,
    title: 'CARDTRONICS',
    description: '221    SANSOME ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.79228,
    latitude: -122.40106
  },
  {
    zipcode: 94111,
    title: 'FIRST REPUBLIC BANK',
    description: '101    PINE ST, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.79231,
    latitude: -122.39858
  },
  {
    zipcode: 94108,
    title: 'U.S. BANK - NON MONEYPASS',
    description: '950    MASON ST, San Francisco, CA 94108',
    surcharge: true,
    longitude: 37.79232,
    latitude: -122.41082
  },
  {
    zipcode: 94111,
    title: 'CHASE',
    description: '100    PINE ST, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.79249,
    latitude: -122.3986
  },
  {
    zipcode: 94111,
    title: 'CHASE',
    description: '100    PINE ST, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.79249,
    latitude: -122.3986
  },
  {
    zipcode: 94105,
    title: 'CARDTRONICS',
    description: '88    SPEAR ST, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.79259,
    latitude: -122.39428
  },
  {
    zipcode: 94105,
    title: 'CITIBANK',
    description: '245    MARKET ST, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.79267,
    latitude: -122.39681
  },
  {
    zipcode: 94105,
    title: 'CITIBANK',
    description: '245    MARKET ST, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.79267,
    latitude: -122.39681
  },
  {
    zipcode: 94105,
    title: 'CITIBANK',
    description: '245    MARKET ST, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.79267,
    latitude: -122.39681
  },
  {
    zipcode: 94104,
    title: 'CHASE',
    description: '401    CALIFORNIA ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.79296,
    latitude: -122.40112
  },
  {
    zipcode: 94104,
    title: 'CHASE',
    description: '401    CALIFORNIA ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.79296,
    latitude: -122.40112
  },
  {
    zipcode: 94104,
    title: 'WELLS FARGO BANK',
    description: '464    CALIFORNIA ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.79301,
    latitude: -122.4022
  },
  {
    zipcode: 94104,
    title: 'WELLS FARGO BANK',
    description: '464    CALIFORNIA ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.79301,
    latitude: -122.4022
  },
  {
    zipcode: 94104,
    title: 'WELLS FARGO BANK',
    description: '464    CALIFORNIA ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.79301,
    latitude: -122.4022
  },
  {
    zipcode: 94104,
    title: 'WELLS FARGO BANK',
    description: '464    CALIFORNIA ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.79301,
    latitude: -122.4022
  },
  {
    zipcode: 94104,
    title: 'CARDTRONICS',
    description: '351    CALIFORNIA ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.79304,
    latitude: -122.40054
  },
  {
    zipcode: 94104,
    title: 'UNION BANK',
    description: '400    CALIFORNIA ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.79314,
    latitude: -122.40114
  },
  {
    zipcode: 94104,
    title: 'UNION BANK',
    description: '400    CALIFORNIA ST, San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.79314,
    latitude: -122.40114
  },
  {
    zipcode: 94111,
    title: 'REDWOOD CREDIT UNION',
    description: '241    CALIFORNIA ST, San Francisco, CA 94111',
    surcharge: false,
    longitude: 37.7932,
    latitude: -122.39929
  },
  {
    zipcode: 94104,
    title: 'CITIBANK',
    description: '451    MONTGOMERY ST, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.7933,
    latitude: -122.40295
  },
  {
    zipcode: 94104,
    title: 'CITIBANK',
    description: '451    MONTGOMERY ST, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.7933,
    latitude: -122.40295
  },
  {
    zipcode: 94104,
    title: 'CITIBANK',
    description: '451    MONTGOMERY ST, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.7933,
    latitude: -122.40295
  },
  {
    zipcode: 94111,
    title: 'RBS WorldPay',
    description: '15    DRUMM ST, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.79332,
    latitude: -122.39641
  },
  {
    zipcode: 94111,
    title: 'CARDTRONICS',
    description: '33    DRUMM ST, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.79332,
    latitude: -122.39641
  },
  {
    zipcode: 94111,
    title: 'CARDTRONICS',
    description: '43    DRUMM ST, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.79332,
    latitude: -122.39641
  },
  {
    zipcode: 94104,
    title: 'FIRST BANK',
    description: '460    MONTGOMERY ST, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.79332,
    latitude: -122.40277
  },
  {
    zipcode: 94111,
    title: 'CITIBANK',
    description: '260    CALIFORNIA ST, San Francisco, CA 94111',
    surcharge: false,
    longitude: 37.79335,
    latitude: -122.39951
  },
  {
    zipcode: 94111,
    title: 'CITIBANK',
    description: '260    CALIFORNIA ST, San Francisco, CA 94111',
    surcharge: false,
    longitude: 37.79335,
    latitude: -122.39951
  },
  {
    zipcode: 94111,
    title: 'CITIBANK',
    description: '260    CALIFORNIA ST, San Francisco, CA 94111',
    surcharge: false,
    longitude: 37.79335,
    latitude: -122.39951
  },
  {
    zipcode: 94111,
    title: 'MONEYPASS',
    description: '101    CALIFORNIA ST, San Francisco, CA 94111',
    surcharge: false,
    longitude: 37.79341,
    latitude: -122.3976
  },
  {
    zipcode: 94111,
    title: 'WESTAMERICA BANK',
    description: '214    CALIFORNIA ST, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.79341,
    latitude: -122.39903
  },
  {
    zipcode: 94108,
    title: 'MONEYPASS',
    description: '701    SACRAMENTO ST, San Francisco, CA 94108',
    surcharge: false,
    longitude: 37.79346,
    latitude: -122.4047
  },
  {
    zipcode: 94104,
    title: 'MONEYPASS',
    description: '343    SANSOME ST, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.79352,
    latitude: -122.40131
  },
  {
    zipcode: 94111,
    title: 'WELLS FARGO BANK',
    description: '1    CALIFORNIA ST, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.79357,
    latitude: -122.39638
  },
  {
    zipcode: 94111,
    title: 'WELLS FARGO BANK',
    description: '1    CALIFORNIA ST, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.79357,
    latitude: -122.39638
  },
  {
    zipcode: 94111,
    title: 'WELLS FARGO BANK',
    description: '1    CALIFORNIA ST, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.79357,
    latitude: -122.39638
  },
  {
    zipcode: 94111,
    title: 'WELLS FARGO BANK',
    description: '1    CALIFORNIA ST, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.79357,
    latitude: -122.39638
  },
  {
    zipcode: 94111,
    title: 'WELLS FARGO BANK',
    description: '1    CALIFORNIA ST, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.79357,
    latitude: -122.39638
  },
  {
    zipcode: 94111,
    title: 'BANK OF AMERICA',
    description: '50    CALIFORNIA ST, San Francisco, CA 94111',
    surcharge: false,
    longitude: 37.79367,
    latitude: -122.39701
  },
  {
    zipcode: 94111,
    title: 'BANK OF AMERICA',
    description: '50    CALIFORNIA ST, San Francisco, CA 94111',
    surcharge: false,
    longitude: 37.79367,
    latitude: -122.39701
  },
  {
    zipcode: 94111,
    title: 'BANK OF AMERICA',
    description: '50    CALIFORNIA ST, San Francisco, CA 94111',
    surcharge: false,
    longitude: 37.79367,
    latitude: -122.39701
  },
  {
    zipcode: 94111,
    title: 'BANK OF AMERICA',
    description: '50    CALIFORNIA ST, San Francisco, CA 94111',
    surcharge: false,
    longitude: 37.79367,
    latitude: -122.39701
  },
  {
    zipcode: 94111,
    title: 'BANK OF AMERICA',
    description: '1    FERRY BUILDING, San Francisco, CA 94111',
    surcharge: false,
    longitude: 37.79371,
    latitude: -122.39802
  },
  {
    zipcode: 94111,
    title: 'BANK OF AMERICA',
    description: '1    FERRY BUILDING, San Francisco, CA 94111',
    surcharge: false,
    longitude: 37.79371,
    latitude: -122.39802
  },
  {
    zipcode: 94108,
    title: 'BANK OF AMERICA',
    description: '701    GRANT AVE, San Francisco, CA 94108',
    surcharge: false,
    longitude: 37.79371,
    latitude: -122.40628
  },
  {
    zipcode: 94111,
    title: 'BANK OF THE WEST',
    description: '505    MONTGOMERY ST, San Francisco, CA 94111',
    surcharge: false,
    longitude: 37.7938,
    latitude: -122.40305
  },
  {
    zipcode: 94109,
    title: 'FIRST REPUBLIC BANK',
    description: '2001    VAN NESS AVE, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.79392,
    latitude: -122.42314
  },
  {
    zipcode: 94104,
    title: 'BANK OF AMERICA',
    description: '275    BATTERY ST, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.79395,
    latitude: -122.4002
  },
  {
    zipcode: 94104,
    title: 'BANK OF AMERICA',
    description: '275    BATTERY ST, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.79395,
    latitude: -122.4002
  },
  {
    zipcode: 94109,
    title: 'RBS WorldPay',
    description: '1469    HYDE ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.794,
    latitude: -122.41809
  },
  {
    zipcode: 94111,
    title: 'WELLS FARGO BANK',
    description: '292    BATTERY ST, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.7941,
    latitude: -122.40005
  },
  {
    zipcode: 94111,
    title: 'WELLS FARGO BANK',
    description: '292    BATTERY ST, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.7941,
    latitude: -122.40005
  },
  {
    zipcode: 94111,
    title: 'WELLS FARGO BANK',
    description: '292    BATTERY ST, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.7941,
    latitude: -122.40005
  },
  {
    zipcode: 94111,
    title: 'WELLS FARGO BANK',
    description: '292    BATTERY ST, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.7941,
    latitude: -122.40005
  },
  {
    zipcode: 94108,
    title: 'BANK OF AMERICA',
    description: '944    STOCKTON ST, San Francisco, CA 94108',
    surcharge: false,
    longitude: 37.79422,
    latitude: -122.40784
  },
  {
    zipcode: 94108,
    title: 'BANK OF AMERICA',
    description: '944    STOCKTON ST, San Francisco, CA 94108',
    surcharge: false,
    longitude: 37.79422,
    latitude: -122.40784
  },
  {
    zipcode: 94108,
    title: 'BANK OF AMERICA',
    description: '944    STOCKTON ST, San Francisco, CA 94108',
    surcharge: false,
    longitude: 37.79422,
    latitude: -122.40784
  },
  {
    zipcode: 94111,
    title: 'MONEYPASS',
    description: '555    MONTGOMERY ST, San Francisco, CA 94111',
    surcharge: false,
    longitude: 37.79423,
    latitude: -122.40314
  },
  {
    zipcode: 94105,
    title: 'BANK OF AMERICA',
    description: '1    MARKET ST, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.7944,
    latitude: -122.39469
  },
  {
    zipcode: 94105,
    title: 'BANK OF AMERICA',
    description: '1    MARKET ST, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.7944,
    latitude: -122.39469
  },
  {
    zipcode: 94105,
    title: 'BANK OF AMERICA',
    description: '1    MARKET ST, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.7944,
    latitude: -122.39469
  },
  {
    zipcode: 94105,
    title: 'BANK OF AMERICA',
    description: '1    MARKET ST, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.7944,
    latitude: -122.39469
  },
  {
    zipcode: 94105,
    title: 'BANK OF AMERICA',
    description: '1    MARKET ST, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.7944,
    latitude: -122.39469
  },
  {
    zipcode: 94109,
    title: 'CARDTRONICS',
    description: '2025    VAN NESS AVE, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.7945,
    latitude: -122.42326
  },
  {
    zipcode: 94111,
    title: 'CITIBANK',
    description: '1    EMBARCADERO CTR, San Francisco, CA 94111',
    surcharge: false,
    longitude: 37.79464,
    latitude: -122.39964
  },
  {
    zipcode: 94111,
    title: 'FIRST REPUBLIC BANK',
    description: '1    EMBARCADERO CTR, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.79464,
    latitude: -122.39964
  },
  {
    zipcode: 94111,
    title: 'FIRST REPUBLIC BANK',
    description: '1    EMBARCADERO CTR, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.79464,
    latitude: -122.39964
  },
  {
    zipcode: 94108,
    title: 'CITIBANK',
    description: '845    GRANT AVE, San Francisco, CA 94108',
    surcharge: false,
    longitude: 37.79464,
    latitude: -122.40647
  },
  {
    zipcode: 94108,
    title: 'CITIBANK',
    description: '845    GRANT AVE, San Francisco, CA 94108',
    surcharge: false,
    longitude: 37.79464,
    latitude: -122.40647
  },
  {
    zipcode: 94111,
    title: 'HSBC BANK',
    description: '601    MONTGOMERY ST, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.79465,
    latitude: -122.40322
  },
  {
    zipcode: 94111,
    title: 'WELLS FARGO BANK',
    description: '600    MONTGOMERY ST, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.79468,
    latitude: -122.40305
  },
  {
    zipcode: 94111,
    title: 'CHASE',
    description: '2    EMBARCADERO CTR, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.79479,
    latitude: -122.39847
  },
  {
    zipcode: 94111,
    title: 'CHASE',
    description: '2    EMBARCADERO CTR, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.79479,
    latitude: -122.39847
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '2101    VAN NESS AVE, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.79485,
    latitude: -122.42338
  },
  {
    zipcode: 94111,
    title: 'BANK OF AMERICA',
    description: '4    EMBARCADERO CTR, San Francisco, CA 94111',
    surcharge: false,
    longitude: 37.79503,
    latitude: -122.39606
  },
  {
    zipcode: 94108,
    title: 'MONEYPASS',
    description: '743    WASHINGTON ST, San Francisco, CA 94108',
    surcharge: false,
    longitude: 37.79513,
    latitude: -122.40579
  },
  {
    zipcode: 94108,
    title: 'WELLS FARGO BANK',
    description: '1015    STOCKTON ST, San Francisco, CA 94108',
    surcharge: true,
    longitude: 37.79526,
    latitude: -122.40823
  },
  {
    zipcode: 94108,
    title: 'MONEYPASS',
    description: '1023    STOCKTON ST, San Francisco, CA 94108',
    surcharge: false,
    longitude: 37.79526,
    latitude: -122.40823
  },
  {
    zipcode: 94108,
    title: 'HSBC BANK',
    description: '933    GRANT AVE, San Francisco, CA 94108',
    surcharge: true,
    longitude: 37.79557,
    latitude: -122.40665
  },
  {
    zipcode: 94109,
    title: 'RBS WorldPay',
    description: '2201    VAN NESS AVE, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.79579,
    latitude: -122.42359
  },
  {
    zipcode: 94133,
    title: 'MONEYPASS',
    description: '900    KEARNY ST, San Francisco, CA 94133',
    surcharge: false,
    longitude: 37.79623,
    latitude: -122.40505
  },
  {
    zipcode: 94109,
    title: 'RBS WorldPay',
    description: '2139A    POLK ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.79631,
    latitude: -122.42193
  },
  {
    zipcode: 94109,
    title: 'CARDTRONICS',
    description: '2120    POLK ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.79635,
    latitude: -122.42175
  },
  {
    zipcode: 94133,
    title: 'CITIBANK',
    description: '1000    GRANT AVE, San Francisco, CA 94133',
    surcharge: false,
    longitude: 37.7964,
    latitude: -122.40663
  },
  {
    zipcode: 94133,
    title: 'CITIBANK',
    description: '1000    GRANT AVE, San Francisco, CA 94133',
    surcharge: false,
    longitude: 37.7964,
    latitude: -122.40663
  },
  {
    zipcode: 94133,
    title: 'CHASE',
    description: '1040    GRANT AVE, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.7964,
    latitude: -122.40663
  },
  {
    zipcode: 94133,
    title: 'CHASE',
    description: '1040    GRANT AVE, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.7964,
    latitude: -122.40663
  },
  {
    zipcode: 94133,
    title: 'MONEYPASS',
    description: '1066    GRANT AVE, San Francisco, CA 94133',
    surcharge: false,
    longitude: 37.7964,
    latitude: -122.40663
  },
  {
    zipcode: 94111,
    title: 'BANK OF AMERICA',
    description: '500    BATTERY ST, San Francisco, CA 94111',
    surcharge: false,
    longitude: 37.79644,
    latitude: -122.40051
  },
  {
    zipcode: 94111,
    title: 'BANK OF AMERICA',
    description: '500    BATTERY ST, San Francisco, CA 94111',
    surcharge: false,
    longitude: 37.79644,
    latitude: -122.40051
  },
  {
    zipcode: 94133,
    title: 'PULSE NETWORK',
    description: '145    COLUMBUS AVE, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.79683,
    latitude: -122.40534
  },
  {
    zipcode: 94111,
    title: 'CHASE',
    description: '165    JACKSON ST, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.79687,
    latitude: -122.3992
  },
  {
    zipcode: 94111,
    title: 'CHASE',
    description: '165    JACKSON ST, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.79687,
    latitude: -122.3992
  },
  {
    zipcode: 94133,
    title: 'FIRST BANK',
    description: '1143    GRANT AVE, San Francisco, CA 94133',
    surcharge: false,
    longitude: 37.79737,
    latitude: -122.40701
  },
  {
    zipcode: 94123,
    title: 'COMERICA BANK',
    description: '2001    UNION ST, San Francisco, CA 94123',
    surcharge: false,
    longitude: 37.79741,
    latitude: -122.4322
  },
  {
    zipcode: 94123,
    title: 'BANK OF AMERICA',
    description: '1995    UNION ST, San Francisco, CA 94123',
    surcharge: false,
    longitude: 37.79742,
    latitude: -122.43212
  },
  {
    zipcode: 94123,
    title: 'BANK OF AMERICA',
    description: '1995    UNION ST, San Francisco, CA 94123',
    surcharge: false,
    longitude: 37.79742,
    latitude: -122.43212
  },
  {
    zipcode: 94123,
    title: 'BANK OF AMERICA',
    description: '1995    UNION ST, San Francisco, CA 94123',
    surcharge: false,
    longitude: 37.79742,
    latitude: -122.43212
  },
  {
    zipcode: 94133,
    title: 'WELLS FARGO BANK',
    description: '1160    GRANT AVE, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.79759,
    latitude: -122.40687
  },
  {
    zipcode: 94133,
    title: 'WELLS FARGO BANK',
    description: '1160    GRANT AVE, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.79759,
    latitude: -122.40687
  },
  {
    zipcode: 94123,
    title: 'WELLS FARGO BANK',
    description: '1900    UNION ST, San Francisco, CA 94123',
    surcharge: true,
    longitude: 37.79767,
    latitude: -122.43155
  },
  {
    zipcode: 94123,
    title: 'WELLS FARGO BANK',
    description: '1900    UNION ST, San Francisco, CA 94123',
    surcharge: true,
    longitude: 37.79767,
    latitude: -122.43155
  },
  {
    zipcode: 94123,
    title: 'WELLS FARGO BANK',
    description: '1900    UNION ST, San Francisco, CA 94123',
    surcharge: true,
    longitude: 37.79767,
    latitude: -122.43155
  },
  {
    zipcode: 94133,
    title: 'CHASE',
    description: '1318    STOCKTON ST, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.79797,
    latitude: -122.40859
  },
  {
    zipcode: 94133,
    title: 'CHASE',
    description: '1318    STOCKTON ST, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.79797,
    latitude: -122.40859
  },
  {
    zipcode: 94133,
    title: 'CARDTRONICS',
    description: '1344    STOCKTON ST, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.79797,
    latitude: -122.40859
  },
  {
    zipcode: 94133,
    title: 'FIS',
    description: '308    COLUMBUS AVE, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.79802,
    latitude: -122.40674
  },
  {
    zipcode: 94133,
    title: 'RBS WorldPay',
    description: '310    COLUMBUS AVE, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.79802,
    latitude: -122.40674
  },
  {
    zipcode: 94109,
    title: 'BANK OF AMERICA',
    description: '2325    POLK ST, San Francisco, CA 94109',
    surcharge: false,
    longitude: 37.79803,
    latitude: -122.42228
  },
  {
    zipcode: 94133,
    title: 'RBS WorldPay',
    description: '536    BROADWAY, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.79804,
    latitude: -122.40599
  },
  {
    zipcode: 94133,
    title: 'RBS WorldPay',
    description: '435    BROADWAY, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.79807,
    latitude: -122.40429
  },
  {
    zipcode: 94133,
    title: 'MONEYPASS',
    description: '1301    STOCKTON ST, San Francisco, CA 94133',
    surcharge: false,
    longitude: 37.79826,
    latitude: -122.40883
  },
  {
    zipcode: 94133,
    title: 'PULSE NETWORK',
    description: '458    BROADWAY, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.7983,
    latitude: -122.40393
  },
  {
    zipcode: 94118,
    title: 'FIS',
    description: '464    BROADWAY, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.7983,
    latitude: -122.40393
  },
  {
    zipcode: 94123,
    title: 'PULSE NETWORK',
    description: '3165    STEINER ST, San Francisco, CA 94123',
    surcharge: true,
    longitude: 37.79835,
    latitude: -122.43752
  },
  {
    zipcode: 94123,
    title: 'FIS',
    description: '1598    UNION ST, San Francisco, CA 94123',
    surcharge: true,
    longitude: 37.79854,
    latitude: -122.42478
  },
  {
    zipcode: 94123,
    title: 'WELLS FARGO BANK',
    description: '3161    FILLMORE ST, San Francisco, CA 94123',
    surcharge: true,
    longitude: 37.79862,
    latitude: -122.43589
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '2501    VAN NESS AVE, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.79865,
    latitude: -122.42419
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '2545    VAN NESS AVE, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.79865,
    latitude: -122.42419
  },
  {
    zipcode: 94129,
    title: 'FIRST REPUBLIC BANK',
    description: '558    PRESIDIO BLVD, San Francisco, CA 94129',
    surcharge: true,
    longitude: 37.79876,
    latitude: -122.45329
  },
  {
    zipcode: 94133,
    title: 'FIS',
    description: '1326    GRANT AVE, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.79896,
    latitude: -122.40715
  },
  {
    zipcode: 94133,
    title: 'FIS',
    description: '1337    GRANT AVE, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.799,
    latitude: -122.40734
  },
  {
    zipcode: 94123,
    title: 'CHASE',
    description: '3207    FILLMORE ST, San Francisco, CA 94123',
    surcharge: true,
    longitude: 37.79903,
    latitude: -122.43597
  },
  {
    zipcode: 94123,
    title: 'FIS',
    description: '1700    FILBERT ST, San Francisco, CA 94123',
    surcharge: true,
    longitude: 37.79904,
    latitude: -122.42834
  },
  {
    zipcode: 94133,
    title: 'MONEYPASS',
    description: '1435    STOCKTON ST, San Francisco, CA 94133',
    surcharge: false,
    longitude: 37.79906,
    latitude: -122.40901
  },
  {
    zipcode: 94133,
    title: 'BANK OF AMERICA',
    description: '1455    STOCKTON ST, San Francisco, CA 94133',
    surcharge: false,
    longitude: 37.79906,
    latitude: -122.40901
  },
  {
    zipcode: 94133,
    title: 'BANK OF AMERICA',
    description: '1455    STOCKTON ST, San Francisco, CA 94133',
    surcharge: false,
    longitude: 37.79906,
    latitude: -122.40901
  },
  {
    zipcode: 94133,
    title: 'BANK OF AMERICA',
    description: '1455    STOCKTON ST, San Francisco, CA 94133',
    surcharge: false,
    longitude: 37.79906,
    latitude: -122.40901
  },
  {
    zipcode: 94133,
    title: 'WELLS FARGO BANK',
    description: '468    COLUMBUS AVE, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.79914,
    latitude: -122.40835
  },
  {
    zipcode: 94133,
    title: 'WELLS FARGO BANK',
    description: '468    COLUMBUS AVE, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.79914,
    latitude: -122.40835
  },
  {
    zipcode: 94133,
    title: 'WELLS FARGO BANK',
    description: '468    COLUMBUS AVE, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.79914,
    latitude: -122.40835
  },
  {
    zipcode: 94133,
    title: 'BANK OF THE WEST',
    description: '480    COLUMBUS AVE, San Francisco, CA 94133',
    surcharge: false,
    longitude: 37.79914,
    latitude: -122.40835
  },
  {
    zipcode: 94123,
    title: 'PULSE NETWORK',
    description: '2498    LOMBARD ST, San Francisco, CA 94123',
    surcharge: true,
    longitude: 37.79932,
    latitude: -122.44123
  },
  {
    zipcode: 94123,
    title: 'PULSE NETWORK',
    description: '2139    LOMBARD ST, San Francisco, CA 94123',
    surcharge: true,
    longitude: 37.79961,
    latitude: -122.4366
  },
  {
    zipcode: 94133,
    title: 'CITIBANK',
    description: '580    GREEN ST, San Francisco, CA 94133',
    surcharge: false,
    longitude: 37.79966,
    latitude: -122.40836
  },
  {
    zipcode: 94133,
    title: 'CITIBANK',
    description: '580    GREEN ST, San Francisco, CA 94133',
    surcharge: false,
    longitude: 37.79966,
    latitude: -122.40836
  },
  {
    zipcode: 94133,
    title: 'PULSE NETWORK',
    description: '542    GREEN ST, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.79973,
    latitude: -122.40784
  },
  {
    zipcode: 94123,
    title: 'PULSE NETWORK',
    description: '1701    GREENWICH ST, San Francisco, CA 94123',
    surcharge: true,
    longitude: 37.79978,
    latitude: -122.4286
  },
  {
    zipcode: 94133,
    title: 'PULSE NETWORK',
    description: '507    COLUMBUS AVE, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80004,
    latitude: -122.40996
  },
  {
    zipcode: 94133,
    title: 'PULSE NETWORK',
    description: '1401    GRANT AVE, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80008,
    latitude: -122.40756
  },
  {
    zipcode: 94133,
    title: 'PULSE NETWORK',
    description: '1461    GRANT AVE, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80008,
    latitude: -122.40756
  },
  {
    zipcode: 94123,
    title: 'BANK OF AMERICA',
    description: '2200    CHESTNUT ST, San Francisco, CA 94123',
    surcharge: false,
    longitude: 37.80042,
    latitude: -122.44001
  },
  {
    zipcode: 94123,
    title: 'BANK OF AMERICA',
    description: '2200    CHESTNUT ST, San Francisco, CA 94123',
    surcharge: false,
    longitude: 37.80042,
    latitude: -122.44001
  },
  {
    zipcode: 94123,
    title: 'PULSE NETWORK',
    description: '1800    LOMBARD ST, San Francisco, CA 94123',
    surcharge: true,
    longitude: 37.80044,
    latitude: -122.4325
  },
  {
    zipcode: 94123,
    title: 'CHASE',
    description: '2166    CHESTNUT ST, San Francisco, CA 94123',
    surcharge: true,
    longitude: 37.80061,
    latitude: -122.43854
  },
  {
    zipcode: 94123,
    title: 'CITIBANK',
    description: '2198    CHESTNUT ST, San Francisco, CA 94123',
    surcharge: false,
    longitude: 37.80061,
    latitude: -122.43854
  },
  {
    zipcode: 94123,
    title: 'CITIBANK',
    description: '2198    CHESTNUT ST, San Francisco, CA 94123',
    surcharge: false,
    longitude: 37.80061,
    latitude: -122.43854
  },
  {
    zipcode: 94123,
    title: 'WELLS FARGO BANK',
    description: '2055    CHESTNUT ST, San Francisco, CA 94123',
    surcharge: true,
    longitude: 37.80065,
    latitude: -122.43683
  },
  {
    zipcode: 94123,
    title: 'WELLS FARGO BANK',
    description: '2055    CHESTNUT ST, San Francisco, CA 94123',
    surcharge: true,
    longitude: 37.80065,
    latitude: -122.43683
  },
  {
    zipcode: 94123,
    title: 'WELLS FARGO BANK',
    description: '2055    CHESTNUT ST, San Francisco, CA 94123',
    surcharge: true,
    longitude: 37.80065,
    latitude: -122.43683
  },
  {
    zipcode: 94123,
    title: 'WELLS FARGO BANK',
    description: '2055    CHESTNUT ST, San Francisco, CA 94123',
    surcharge: true,
    longitude: 37.80065,
    latitude: -122.43683
  },
  {
    zipcode: 94123,
    title: 'WELLS FARGO BANK',
    description: '2055    CHESTNUT ST, San Francisco, CA 94123',
    surcharge: true,
    longitude: 37.80065,
    latitude: -122.43683
  },
  {
    zipcode: 94123,
    title: 'FIS',
    description: '2836    FRANKLIN ST, San Francisco, CA 94123',
    surcharge: true,
    longitude: 37.80072,
    latitude: -122.42601
  },
  {
    zipcode: 94123,
    title: 'CARDTRONICS',
    description: '1790    LOMBARD ST, San Francisco, CA 94123',
    surcharge: true,
    longitude: 37.80078,
    latitude: -122.42986
  },
  {
    zipcode: 94109,
    title: 'CHASE',
    description: '2750    VAN NESS AVE, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.80092,
    latitude: -122.42426
  },
  {
    zipcode: 94111,
    title: 'BANK OF AMERICA',
    description: '151    UNION ST, San Francisco, CA 94111',
    surcharge: false,
    longitude: 37.80122,
    latitude: -122.40216
  },
  {
    zipcode: 94133,
    title: 'FIS',
    description: '759    COLUMBUS AVE, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80144,
    latitude: -122.41199
  },
  {
    zipcode: 94109,
    title: 'PULSE NETWORK',
    description: '2901    VAN NESS AVE, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.80231,
    latitude: -122.42489
  },
  {
    zipcode: 94111,
    title: 'WELLS FARGO BANK',
    description: '1255    BATTERY ST, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.8028,
    latitude: -122.40198
  },
  {
    zipcode: 94111,
    title: 'WELLS FARGO BANK',
    description: '1255    BATTERY ST, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.8028,
    latitude: -122.40198
  },
  {
    zipcode: 94133,
    title: 'FIS',
    description: '901    COLUMBUS AVE, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80301,
    latitude: -122.41426
  },
  {
    zipcode: 94133,
    title: 'SWITCH COMMERCE INC.',
    description: '2168    MASON ST, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80313,
    latitude: -122.413
  },
  {
    zipcode: 94133,
    title: 'FIS',
    description: '900    COLUMBUS AVE, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80314,
    latitude: -122.41414
  },
  {
    zipcode: 94133,
    title: 'FIS',
    description: '1025    COLUMBUS AVE, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80365,
    latitude: -122.4152
  },
  {
    zipcode: 94112,
    title: 'PULSE NETWORK',
    description: '749    ADELINE ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.80415,
    latitude: -122.28826
  },
  {
    zipcode: 94109,
    title: 'CARDTRONICS',
    description: '1175    COLUMBUS AVE, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.80468,
    latitude: -122.41667
  },
  {
    zipcode: 94123,
    title: 'CARDTRONICS',
    description: '15    MARINA BLVD, San Francisco, CA 94123',
    surcharge: false,
    longitude: 37.80509,
    latitude: -122.43233
  },
  {
    zipcode: 94133,
    title: 'WELLS FARGO BANK',
    description: '501    BAY ST, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80529,
    latitude: -122.41547
  },
  {
    zipcode: 94109,
    title: 'BANK OF AMERICA',
    description: '900   N POINT ST, San Francisco, CA 94109',
    surcharge: false,
    longitude: 37.80558,
    latitude: -122.42202
  },
  {
    zipcode: 94133,
    title: 'FIS',
    description: '490    BAY ST, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.8056,
    latitude: -122.41445
  },
  {
    zipcode: 94133,
    title: 'CHASE',
    description: '360    BAY ST, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80578,
    latitude: -122.41297
  },
  {
    zipcode: 94133,
    title: 'CHASE',
    description: '360    BAY ST, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80578,
    latitude: -122.41297
  },
  {
    zipcode: 94133,
    title: 'WELLS FARGO BANK',
    description: '350    BAY ST, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.8058,
    latitude: -122.4128
  },
  {
    zipcode: 94133,
    title: 'WELLS FARGO BANK',
    description: '350    BAY ST, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.8058,
    latitude: -122.4128
  },
  {
    zipcode: 94133,
    title: '1ST ISO PROCESSING',
    description: '1300    COLUMBUS AVE, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80605,
    latitude: -122.41833
  },
  {
    zipcode: 94109,
    title: 'WELLS FARGO BANK',
    description: '757    BEACH ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.80648,
    latitude: -122.42119
  },
  {
    zipcode: 94133,
    title: 'PULSE NETWORK',
    description: '2800    LEAVENWORTH ST, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80688,
    latitude: -122.41882
  },
  {
    zipcode: 94133,
    title: 'FIS',
    description: '2737B    TAYLOR ST, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.8076,
    latitude: -122.41577
  },
  {
    zipcode: 94133,
    title: 'PULSE NETWORK',
    description: '250    BEACH ST, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80767,
    latitude: -122.41318
  },
  {
    zipcode: 94133,
    title: 'CARDTRONICS',
    description: '2650    MASON ST, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80797,
    latitude: -122.41398
  },
  {
    zipcode: 94133,
    title: 'CARDTRONICS',
    description: '1    JEFFERSON ST, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80837,
    latitude: -122.41381
  },
  {
    zipcode: 94133,
    title: 'RBS WorldPay',
    description: '49    JEFFERSON ST, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80837,
    latitude: -122.41381
  },
  {
    zipcode: 94130,
    title: 'RBS WorldPay',
    description: '2    AVENUE OF THE PALMS AVE, San Francisco, CA 94130',
    surcharge: true,
    longitude: 37.81619,
    latitude: -122.37142
  },
  {
    zipcode: 94130,
    title: 'PULSE NETWORK',
    description: '800 STE 5  AVENUE H, San Francisco, CA 94130',
    surcharge: true,
    longitude: 37.8241,
    latitude: -122.36904
  },
  {
    zipcode: 95682,
    title: 'CARDTRONICS',
    description: '4047   S SHINGLE RD, Shingle Springs, CA 95682',
    surcharge: true,
    longitude: 38.62656,
    latitude: -120.94498
  },
  {
    zipcode: 95762,
    title: 'CARDTRONICS',
    description: '4400    LATROBE RD, El Dorado Hills, CA 95762',
    surcharge: true,
    longitude: 38.62802,
    latitude: -121.03838
  },
  {
    zipcode: 95684,
    title: 'BANK OF AMERICA',
    description: '3651    TRUXEL RD, Somerset, CA 95684',
    surcharge: false,
    longitude: 38.63481,
    latitude: -121.50592
  },
  {
    zipcode: 95762,
    title: 'MONEYPASS',
    description: '1020 BLDG E  WHITE ROCK RD, El Dorado Hills, CA 95762',
    surcharge: false,
    longitude: 38.64773,
    latitude: -121.06536
  },
  {
    zipcode: 95762,
    title: 'RBS WorldPay',
    description: '4315    TOWN CENTER BLVD, El Dorado Hills, CA 95762',
    surcharge: true,
    longitude: 38.64973,
    latitude: -121.0675
  },
  {
    zipcode: 95762,
    title: 'PULSE NETWORK',
    description: '4316    TOWN CENTER BLVD, El Dorado Hills, CA 95762',
    surcharge: true,
    longitude: 38.64973,
    latitude: -121.0675
  },
  {
    zipcode: 95762,
    title: 'CHASE',
    description: '4363    TOWN CENTER BLVD, El Dorado Hills, CA 95762',
    surcharge: true,
    longitude: 38.64973,
    latitude: -121.0675
  },
  {
    zipcode: 95762,
    title: 'CHASE',
    description: '4363    TOWN CENTER BLVD, El Dorado Hills, CA 95762',
    surcharge: true,
    longitude: 38.64973,
    latitude: -121.0675
  },
  {
    zipcode: 95762,
    title: 'CHASE',
    description: '4363    TOWN CENTER BLVD, El Dorado Hills, CA 95762',
    surcharge: true,
    longitude: 38.64973,
    latitude: -121.0675
  },
  {
    zipcode: 95762,
    title: 'CARDTRONICS',
    description: '4400    TOWN CENTER BLVD, El Dorado Hills, CA 95762',
    surcharge: true,
    longitude: 38.65008,
    latitude: -121.06239
  },
  {
    zipcode: 95762,
    title: 'MONEYPASS',
    description: '4354    TOWN CENTER BLVD, El Dorado Hills, CA 95762',
    surcharge: false,
    longitude: 38.65018,
    latitude: -121.06678
  },
  {
    zipcode: 95762,
    title: 'MONEYPASS',
    description: '4354    TOWN CENTER BLVD, El Dorado Hills, CA 95762',
    surcharge: false,
    longitude: 38.65018,
    latitude: -121.06678
  },
  {
    zipcode: 95762,
    title: 'GOLDEN 1 CREDIT UNION',
    description: '4311 STE 400  TOWN CENTER BLVD, El Dorado Hills, CA 95762',
    surcharge: true,
    longitude: 38.65054,
    latitude: -121.06856
  },
  {
    zipcode: 95762,
    title: 'WELLS FARGO BANK',
    description: '4355 STE 110  TOWN CENTER BLVD, El Dorado Hills, CA 95762',
    surcharge: true,
    longitude: 38.65099,
    latitude: -121.06695
  },
  {
    zipcode: 95762,
    title: 'WELLS FARGO BANK',
    description: '4355 STE 110  TOWN CENTER BLVD, El Dorado Hills, CA 95762',
    surcharge: true,
    longitude: 38.65099,
    latitude: -121.06695
  },
  {
    zipcode: 95762,
    title: 'PULSE NETWORK',
    description: '1021    SARATOGA WAY, El Dorado Hills, CA 95762',
    surcharge: true,
    longitude: 38.65457,
    latitude: -121.07025
  },
  {
    zipcode: 95762,
    title: 'WELLS FARGO BANK',
    description: '3935 STE B  PARK DR, El Dorado Hills, CA 95762',
    surcharge: true,
    longitude: 38.65561,
    latitude: -121.07005
  },
  {
    zipcode: 95762,
    title: 'WELLS FARGO BANK',
    description: '3935 STE B  PARK DR, El Dorado Hills, CA 95762',
    surcharge: true,
    longitude: 38.65561,
    latitude: -121.07005
  },
  {
    zipcode: 95682,
    title: 'BANK OF AMERICA',
    description: '4070    CAMERON PARK DR, Shingle Springs, CA 95682',
    surcharge: false,
    longitude: 38.65697,
    latitude: -120.96951
  },
  {
    zipcode: 95682,
    title: 'BANK OF AMERICA',
    description: '4070    CAMERON PARK DR, Shingle Springs, CA 95682',
    surcharge: false,
    longitude: 38.65697,
    latitude: -120.96951
  },
  {
    zipcode: 95682,
    title: 'BANK OF AMERICA',
    description: '4070    CAMERON PARK DR, Shingle Springs, CA 95682',
    surcharge: false,
    longitude: 38.65697,
    latitude: -120.96951
  },
  {
    zipcode: 95682,
    title: 'CARDTRONICS',
    description: '2580    MERRYCHASE DR, Shingle Springs, CA 95682',
    surcharge: true,
    longitude: 38.657,
    latitude: -121.00065
  },
  {
    zipcode: 95682,
    title: 'PULSE NETWORK',
    description: '4051    CAMERON PARK DR, Shingle Springs, CA 95682',
    surcharge: true,
    longitude: 38.65703,
    latitude: -120.96813
  },
  {
    zipcode: 95682,
    title: 'WELLS FARGO BANK',
    description: '4095    CAMERON PARK DR, Shingle Springs, CA 95682',
    surcharge: true,
    longitude: 38.65703,
    latitude: -120.96813
  },
  {
    zipcode: 95682,
    title: 'WELLS FARGO BANK',
    description: '4095    CAMERON PARK DR, Shingle Springs, CA 95682',
    surcharge: true,
    longitude: 38.65703,
    latitude: -120.96813
  },
  {
    zipcode: 95762,
    title: 'UMPQUA BANK',
    description: '3880 # 100  EL DORADO HILLS BLVD, El Dorado Hills, CA 95762',
    surcharge: false,
    longitude: 38.65709,
    latitude: -121.0725
  },
  {
    zipcode: 95682,
    title: 'MONEYPASS',
    description: '3380    COACH LN, Shingle Springs, CA 95682',
    surcharge: false,
    longitude: 38.65783,
    latitude: -120.9697
  },
  {
    zipcode: 95682,
    title: 'EL DORADO SAVINGS BANK',
    description: '4060    CAMERON PARK DR, Shingle Springs, CA 95682',
    surcharge: true,
    longitude: 38.65784,
    latitude: -120.96935
  },
  {
    zipcode: 95682,
    title: 'MONEYPASS',
    description: '3311    COACH LN, Shingle Springs, CA 95682',
    surcharge: false,
    longitude: 38.65859,
    latitude: -120.97367
  },
  {
    zipcode: 95682,
    title: 'GOLDEN 1 CREDIT UNION',
    description: '3333    COACH LN, Shingle Springs, CA 95682',
    surcharge: true,
    longitude: 38.65865,
    latitude: -120.97067
  },
  {
    zipcode: 95682,
    title: 'PULSE NETWORK',
    description: '3381    COACH LN, Shingle Springs, CA 95682',
    surcharge: true,
    longitude: 38.65865,
    latitude: -120.97067
  },
  {
    zipcode: 95762,
    title: 'BANK OF AMERICA',
    description: '3901    PARK DR, El Dorado Hills, CA 95762',
    surcharge: false,
    longitude: 38.65904,
    latitude: -121.07116
  },
  {
    zipcode: 95762,
    title: 'BANK OF AMERICA',
    description: '3901    PARK DR, El Dorado Hills, CA 95762',
    surcharge: false,
    longitude: 38.65904,
    latitude: -121.07116
  },
  {
    zipcode: 95762,
    title: 'EL DORADO SAVINGS BANK',
    description: '3963    PARK DR, El Dorado Hills, CA 95762',
    surcharge: true,
    longitude: 38.65904,
    latitude: -121.07116
  },
  {
    zipcode: 95682,
    title: 'RBS WorldPay',
    description: '4131   S SHINGLE RD, Shingle Springs, CA 95682',
    surcharge: true,
    longitude: 38.66039,
    latitude: -120.93525
  },
  {
    zipcode: 95682,
    title: 'CARDTRONICS',
    description: '3500    PALMER DR, Shingle Springs, CA 95682',
    surcharge: true,
    longitude: 38.66116,
    latitude: -120.96694
  },
  {
    zipcode: 95682,
    title: 'CHASE',
    description: '3510    PALMER DR, Shingle Springs, CA 95682',
    surcharge: true,
    longitude: 38.66116,
    latitude: -120.96694
  },
  {
    zipcode: 95682,
    title: 'CHASE',
    description: '3510    PALMER DR, Shingle Springs, CA 95682',
    surcharge: true,
    longitude: 38.66116,
    latitude: -120.96694
  },
  {
    zipcode: 95682,
    title: 'WELLS FARGO BANK',
    description: '3440 STE 8A  PALMER DR, Shingle Springs, CA 95682',
    surcharge: true,
    longitude: 38.66164,
    latitude: -120.96694
  },
  {
    zipcode: 95682,
    title: 'WELLS FARGO BANK',
    description: '3440 STE 8A  PALMER DR, Shingle Springs, CA 95682',
    surcharge: true,
    longitude: 38.66164,
    latitude: -120.96694
  },
  {
    zipcode: 95682,
    title: 'RBS WorldPay',
    description: '4021 # D  MOTHER LODE DR, Shingle Springs, CA 95682',
    surcharge: true,
    longitude: 38.66229,
    latitude: -120.93652
  },
  {
    zipcode: 95667,
    title: 'RBS WorldPay',
    description: '2528    PLEASANT VALLEY RD, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.67932,
    latitude: -120.7386
  },
  {
    zipcode: 95667,
    title: 'PULSE NETWORK',
    description: '4653    MOUNT AUKUM RD, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.68185,
    latitude: -120.66307
  },
  {
    zipcode: 95667,
    title: 'PULSE NETWORK',
    description: '4412    PLEASANT VALLEY RD, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.68581,
    latitude: -120.66776
  },
  {
    zipcode: 95619,
    title: 'RBS WorldPay',
    description: '130    PLEASANT VALLEY RD, Diamond Springs, CA 95619',
    surcharge: true,
    longitude: 38.68922,
    latitude: -120.83074
  },
  {
    zipcode: 95619,
    title: 'PULSE NETWORK',
    description: '537    MAIN ST, Diamond Springs, CA 95619',
    surcharge: true,
    longitude: 38.69305,
    latitude: -120.81921
  },
  {
    zipcode: 95619,
    title: 'EL DORADO SAVINGS BANK',
    description: '694    PLEASANT VALLEY RD, Diamond Springs, CA 95619',
    surcharge: true,
    longitude: 38.69492,
    latitude: -120.80927
  },
  {
    zipcode: 95619,
    title: 'PULSE NETWORK',
    description: '639    PLEASANT VALLEY RD, Diamond Springs, CA 95619',
    surcharge: true,
    longitude: 38.69504,
    latitude: -120.81005
  },
  {
    zipcode: 95619,
    title: 'PULSE NETWORK',
    description: '639    PLEASANT VALLEY RD, Diamond Springs, CA 95619',
    surcharge: true,
    longitude: 38.69504,
    latitude: -120.81005
  },
  {
    zipcode: 95619,
    title: 'FIS',
    description: '680    PLEASANT VALLEY RD, Diamond Springs, CA 95619',
    surcharge: true,
    longitude: 38.69504,
    latitude: -120.81005
  },
  {
    zipcode: 95682,
    title: 'CARDTRONICS',
    description: '3020 STE B  GREEN VALLEY RD, Shingle Springs, CA 95682',
    surcharge: true,
    longitude: 38.69745,
    latitude: -121.00296
  },
  {
    zipcode: 95682,
    title: 'GOLDEN 1 CREDIT UNION',
    description: '2650    CAMERON PARK DR, Shingle Springs, CA 95682',
    surcharge: true,
    longitude: 38.69827,
    latitude: -120.99652
  },
  {
    zipcode: 95682,
    title: 'CARDTRONICS',
    description: '2650    CAMERON PARK DR, Shingle Springs, CA 95682',
    surcharge: true,
    longitude: 38.69827,
    latitude: -120.99652
  },
  {
    zipcode: 95682,
    title: 'PULSE NETWORK',
    description: '2643    CAMERON PARK DR, Shingle Springs, CA 95682',
    surcharge: true,
    longitude: 38.69896,
    latitude: -120.99547
  },
  {
    zipcode: 95667,
    title: 'RBS WorldPay',
    description: '4535    MISSOURI FLAT RD, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.69971,
    latitude: -120.82187
  },
  {
    zipcode: 95762,
    title: 'PULSE NETWORK',
    description: '341    GREEN VALLEY RD, El Dorado Hills, CA 95762',
    surcharge: true,
    longitude: 38.70174,
    latitude: -121.10559
  },
  {
    zipcode: 95667,
    title: 'EL DORADO SAVINGS BANK',
    description: '4040    EL DORADO RD, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.70236,
    latitude: -120.85732
  },
  {
    zipcode: 95667,
    title: 'PULSE NETWORK',
    description: '4300    MISSOURI FLAT RD, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.70299,
    latitude: -120.82684
  },
  {
    zipcode: 95667,
    title: 'CARDTRONICS',
    description: '4220    MISSOURI FLAT RD, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.70634,
    latitude: -120.83168
  },
  {
    zipcode: 95667,
    title: 'FIS',
    description: '6850    GREEN LEAF DR, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.70923,
    latitude: -120.83932
  },
  {
    zipcode: 95762,
    title: 'BANK OF AMERICA',
    description: '2222    FRANCISCO DR, El Dorado Hills, CA 95762',
    surcharge: false,
    longitude: 38.71025,
    latitude: -121.08648
  },
  {
    zipcode: 95667,
    title: 'CARDTRONICS',
    description: '3964    MISSOURI FLAT RD, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.71114,
    latitude: -120.84288
  },
  {
    zipcode: 95667,
    title: 'BANK OF AMERICA',
    description: '3964 STE K  MISSOURI FLAT RD, Placerville, CA 95667',
    surcharge: false,
    longitude: 38.71114,
    latitude: -120.84288
  },
  {
    zipcode: 95667,
    title: 'BANK OF AMERICA',
    description: '3964 STE K  MISSOURI FLAT RD, Placerville, CA 95667',
    surcharge: false,
    longitude: 38.71114,
    latitude: -120.84288
  },
  {
    zipcode: 95667,
    title: 'BANK OF AMERICA',
    description: '3964 STE K  MISSOURI FLAT RD, Placerville, CA 95667',
    surcharge: false,
    longitude: 38.71114,
    latitude: -120.84288
  },
  {
    zipcode: 95667,
    title: 'UMPQUA BANK',
    description: '3970 STE J  MISSOURI FLAT RD, Placerville, CA 95667',
    surcharge: false,
    longitude: 38.7115,
    latitude: -120.84168
  },
  {
    zipcode: 95667,
    title: 'UMPQUA BANK',
    description: '3970 STE J  MISSOURI FLAT RD, Placerville, CA 95667',
    surcharge: false,
    longitude: 38.7115,
    latitude: -120.84168
  },
  {
    zipcode: 95667,
    title: 'UNION BANK',
    description: '3970 STE L  MISSOURI FLAT RD, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.7115,
    latitude: -120.84168
  },
  {
    zipcode: 95667,
    title: 'UNION BANK',
    description: '3970 STE L  MISSOURI FLAT RD, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.7115,
    latitude: -120.84168
  },
  {
    zipcode: 95667,
    title: 'CHASE',
    description: '3980    MISSOURI FLAT RD, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.71176,
    latitude: -120.8412
  },
  {
    zipcode: 95667,
    title: 'GOLDEN 1 CREDIT UNION',
    description: '3966 STE O  MISSOURI FLAT RD, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.71278,
    latitude: -120.84163
  },
  {
    zipcode: 95667,
    title: 'CARDTRONICS',
    description: '3968    MISSOURI FLAT RD, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.71281,
    latitude: -120.84166
  },
  {
    zipcode: 95667,
    title: 'MONEYPASS',
    description: '3955    MISSOURI FLAT RD, Placerville, CA 95667',
    surcharge: false,
    longitude: 38.7141,
    latitude: -120.84265
  },
  {
    zipcode: 95762,
    title: 'CHASE',
    description: '2215    FRANCISCO DR, El Dorado Hills, CA 95762',
    surcharge: true,
    longitude: 38.7153,
    latitude: -121.08378
  },
  {
    zipcode: 95762,
    title: 'CHASE',
    description: '2215    FRANCISCO DR, El Dorado Hills, CA 95762',
    surcharge: true,
    longitude: 38.7153,
    latitude: -121.08378
  },
  {
    zipcode: 95762,
    title: 'MONEYPASS',
    description: '2207    FRANCISCO DR, El Dorado Hills, CA 95762',
    surcharge: false,
    longitude: 38.7162,
    latitude: -121.08275
  },
  {
    zipcode: 95667,
    title: 'CARDTRONICS',
    description: '3025    FORNI RD, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.72063,
    latitude: -120.83253
  },
  {
    zipcode: 95667,
    title: 'FIS',
    description: '67    FAIR LN, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.72247,
    latitude: -120.83144
  },
  {
    zipcode: 95667,
    title: 'PULSE NETWORK',
    description: '99    PLACERVILLE DR, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.72392,
    latitude: -120.83487
  },
  {
    zipcode: 95667,
    title: 'RBS WorldPay',
    description: '1100    MARSHALL WAY, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.72454,
    latitude: -120.79142
  },
  {
    zipcode: 95667,
    title: 'MONEYPASS',
    description: '3075    SACRAMENTO ST, Placerville, CA 95667',
    surcharge: false,
    longitude: 38.72525,
    latitude: -120.80312
  },
  {
    zipcode: 95726,
    title: 'PULSE NETWORK',
    description: '4782    SLY PARK RD, Pollock Pines, CA 95726',
    surcharge: true,
    longitude: 38.7256,
    latitude: -120.57019
  },
  {
    zipcode: 95667,
    title: 'BANK OF AMERICA',
    description: '3044    SACRAMENTO ST, Placerville, CA 95667',
    surcharge: false,
    longitude: 38.72613,
    latitude: -120.80327
  },
  {
    zipcode: 95667,
    title: 'BANK OF AMERICA',
    description: '3044    SACRAMENTO ST, Placerville, CA 95667',
    surcharge: false,
    longitude: 38.72613,
    latitude: -120.80327
  },
  {
    zipcode: 95667,
    title: 'WELLS FARGO BANK',
    description: '186    PLACERVILLE DR, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.72666,
    latitude: -120.83668
  },
  {
    zipcode: 95667,
    title: 'WELLS FARGO BANK',
    description: '186    PLACERVILLE DR, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.72666,
    latitude: -120.83668
  },
  {
    zipcode: 95667,
    title: 'WELLS FARGO BANK',
    description: '186    PLACERVILLE DR, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.72666,
    latitude: -120.83668
  },
  {
    zipcode: 95667,
    title: '1ST ISO PROCESSING',
    description: '88    MAIN ST, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.7276,
    latitude: -120.80766
  },
  {
    zipcode: 95667,
    title: 'EL DORADO SAVINGS BANK',
    description: '2888    RAY LAWYER DR, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.72782,
    latitude: -120.83654
  },
  {
    zipcode: 95667,
    title: 'EL DORADO SAVINGS BANK',
    description: '247    MAIN ST, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.72823,
    latitude: -120.80304
  },
  {
    zipcode: 95667,
    title: 'RIVER CITY BANK',
    description: '348    MAIN ST, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.72834,
    latitude: -120.80166
  },
  {
    zipcode: 95667,
    title: 'FIS',
    description: '1220    BROADWAY, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.73093,
    latitude: -120.78615
  },
  {
    zipcode: 95667,
    title: 'BANK OF AMERICA',
    description: '1270    BROADWAY, Placerville, CA 95667',
    surcharge: false,
    longitude: 38.73093,
    latitude: -120.78615
  },
  {
    zipcode: 95667,
    title: 'SWITCH COMMERCE INC.',
    description: '1296    BROADWAY, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.73093,
    latitude: -120.78615
  },
  {
    zipcode: 95667,
    title: 'PULSE NETWORK',
    description: '1178    BROADWAY, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.73104,
    latitude: -120.79004
  },
  {
    zipcode: 95667,
    title: 'WELLS FARGO BANK',
    description: '1244    BROADWAY, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.73105,
    latitude: -120.78549
  },
  {
    zipcode: 95667,
    title: 'WELLS FARGO BANK',
    description: '1244    BROADWAY, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.73105,
    latitude: -120.78549
  },
  {
    zipcode: 95667,
    title: 'UMPQUA BANK',
    description: '1224 STE A  BROADWAY, Placerville, CA 95667',
    surcharge: false,
    longitude: 38.73128,
    latitude: -120.78485
  },
  {
    zipcode: 95667,
    title: 'FIS',
    description: '1390    BROADWAY, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.73194,
    latitude: -120.77949
  },
  {
    zipcode: 95667,
    title: 'CARDTRONICS',
    description: '519    PLACERVILLE DR, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.73346,
    latitude: -120.82611
  },
  {
    zipcode: 95709,
    title: 'PULSE NETWORK',
    description: '3074    CAMINO HEIGHTS DR, Camino, CA 95709',
    surcharge: false,
    longitude: 38.73442,
    latitude: -120.71101
  },
  {
    zipcode: 95709,
    title: 'RBS WorldPay',
    description: '4124    CARSON RD, Camino, CA 95709',
    surcharge: true,
    longitude: 38.73798,
    latitude: -120.67426
  },
  {
    zipcode: 95709,
    title: 'PULSE NETWORK',
    description: '5450    PONY EXPRESS TRL, Camino, CA 95709',
    surcharge: true,
    longitude: 38.74902,
    latitude: -120.61812
  },
  {
    zipcode: 95726,
    title: 'PULSE NETWORK',
    description: '7720    HIGHWAY 50, Pollock Pines, CA 95726',
    surcharge: true,
    longitude: 38.7602,
    latitude: -120.5215
  },
  {
    zipcode: 95726,
    title: 'PULSE NETWORK',
    description: '2667    SANDERS DR, Pollock Pines, CA 95726',
    surcharge: true,
    longitude: 38.76031,
    latitude: -120.59152
  },
  {
    zipcode: 95726,
    title: 'EL DORADO SAVINGS BANK',
    description: '6462    PONY EXPRESS TRL, Pollock Pines, CA 95726',
    surcharge: true,
    longitude: 38.76234,
    latitude: -120.57692
  },
  {
    zipcode: 95726,
    title: 'MONEYPASS',
    description: '6498    PONY EXPRESS TRL, Pollock Pines, CA 95726',
    surcharge: false,
    longitude: 38.76234,
    latitude: -120.57692
  },
  {
    zipcode: 95726,
    title: 'CARDTRONICS',
    description: '6450    PONY EXPRESS TRL, Pollock Pines, CA 95726',
    surcharge: true,
    longitude: 38.76275,
    latitude: -120.58017
  },
  {
    zipcode: 95633,
    title: 'PULSE NETWORK',
    description: '4710    MARSHALL RD, Garden Valley, CA 95633',
    surcharge: true,
    longitude: 38.85679,
    latitude: -120.85273
  },
  {
    zipcode: 96150,
    title: 'PULSE NETWORK',
    description: '2986    US HIGHWAY 50, South Lake Tahoe, CA 96150',
    surcharge: true,
    longitude: 38.86042,
    latitude: -120.01776
  },
  {
    zipcode: 95614,
    title: 'WELLS FARGO BANK',
    description: '5036 STE 130  ELLINGHOUSE DR, Cool, CA 95614',
    surcharge: true,
    longitude: 38.88571,
    latitude: -121.01539
  },
  {
    zipcode: 95614,
    title: 'WELLS FARGO BANK',
    description: '5036 STE 130  ELLINGHOUSE DR, Cool, CA 95614',
    surcharge: true,
    longitude: 38.88571,
    latitude: -121.01539
  },
  {
    zipcode: 96150,
    title: 'WELLS FARGO BANK',
    description: '1032    EMERALD BAY RD, South Lake Tahoe, CA 96150',
    surcharge: true,
    longitude: 38.91259,
    latitude: -120.00422
  },
  {
    zipcode: 96150,
    title: 'WELLS FARGO BANK',
    description: '1032    EMERALD BAY RD, South Lake Tahoe, CA 96150',
    surcharge: true,
    longitude: 38.91259,
    latitude: -120.00422
  },
  {
    zipcode: 96150,
    title: 'WELLS FARGO BANK',
    description: '1040    EMERALD BAY RD, South Lake Tahoe, CA 96150',
    surcharge: true,
    longitude: 38.91259,
    latitude: -120.00422
  },
  {
    zipcode: 96150,
    title: 'CARDTRONICS',
    description: '1056    EMERALD BAY RD, South Lake Tahoe, CA 96150',
    surcharge: true,
    longitude: 38.91259,
    latitude: -120.00422
  },
  {
    zipcode: 95634,
    title: 'PULSE NETWORK',
    description: '6049    FRONT ST, Georgetown, CA 95634',
    surcharge: true,
    longitude: 38.91313,
    latitude: -120.85741
  },
  {
    zipcode: 96150,
    title: 'CARDTRONICS',
    description: '1043    EMERALD BAY RD, South Lake Tahoe, CA 96150',
    surcharge: true,
    longitude: 38.91316,
    latitude: -120.00431
  },
  {
    zipcode: 96150,
    title: 'BANK OF AMERICA',
    description: '2020    LAKE TAHOE BLVD, South Lake Tahoe, CA 96150',
    surcharge: false,
    longitude: 38.91422,
    latitude: -120.00282
  },
  {
    zipcode: 96150,
    title: 'EL DORADO SAVINGS BANK',
    description: '942    EMERALD BAY RD, South Lake Tahoe, CA 96150',
    surcharge: true,
    longitude: 38.91669,
    latitude: -120.00685
  },
  {
    zipcode: 96150,
    title: 'BANK OF THE WEST',
    description: '2161    LAKE TAHOE BLVD, South Lake Tahoe, CA 96150',
    surcharge: false,
    longitude: 38.91692,
    latitude: -119.99969
  },
  {
    zipcode: 96150,
    title: 'PULSE NETWORK',
    description: '913    EMERALD BAY RD, South Lake Tahoe, CA 96150',
    surcharge: true,
    longitude: 38.91717,
    latitude: -120.00865
  },
  {
    zipcode: 96150,
    title: 'CARDTRONICS',
    description: '800    EMERALD BAY RD, South Lake Tahoe, CA 96150',
    surcharge: true,
    longitude: 38.91751,
    latitude: -120.01135
  },
  {
    zipcode: 96150,
    title: 'PULSE NETWORK',
    description: '2227    LAKE TAHOE BLVD, South Lake Tahoe, CA 96150',
    surcharge: true,
    longitude: 38.91847,
    latitude: -119.99734
  },
  {
    zipcode: 96150,
    title: 'PULSE NETWORK',
    description: '2304    LAKE TAHOE BLVD, South Lake Tahoe, CA 96150',
    surcharge: true,
    longitude: 38.9194,
    latitude: -119.99442
  },
  {
    zipcode: 96150,
    title: '1ST ISO PROCESSING',
    description: '2470    LAKE TAHOE BLVD, South Lake Tahoe, CA 96150',
    surcharge: true,
    longitude: 38.92303,
    latitude: -119.98905
  },
  {
    zipcode: 96150,
    title: 'RBS WorldPay',
    description: '2933    US HIGHWAY 50, South Lake Tahoe, CA 96150',
    surcharge: true,
    longitude: 38.92853,
    latitude: -119.98375
  },
  {
    zipcode: 96150,
    title: 'MONEYPASS',
    description: '2850    LAKE TAHOE BLVD, South Lake Tahoe, CA 96150',
    surcharge: false,
    longitude: 38.93328,
    latitude: -119.97758
  },
  {
    zipcode: 96150,
    title: 'MONEYPASS',
    description: '2850    LAKE TAHOE BLVD, South Lake Tahoe, CA 96150',
    surcharge: false,
    longitude: 38.93328,
    latitude: -119.97758
  },
  {
    zipcode: 96150,
    title: 'SWITCH COMMERCE INC.',
    description: '3097    HARRISON AVE, South Lake Tahoe, CA 96150',
    surcharge: true,
    longitude: 38.94004,
    latitude: -119.9773
  },
  {
    zipcode: 96150,
    title: 'CARDTRONICS',
    description: '1020    JOHNSON BLVD, South Lake Tahoe, CA 96150',
    surcharge: false,
    longitude: 38.94497,
    latitude: -119.96733
  },
  {
    zipcode: 96150,
    title: 'BANK OF AMERICA',
    description: '3344    LAKE TAHOE BLVD, South Lake Tahoe, CA 96150',
    surcharge: false,
    longitude: 38.94528,
    latitude: -119.97001
  },
  {
    zipcode: 96150,
    title: 'BANK OF AMERICA',
    description: '3344    LAKE TAHOE BLVD, South Lake Tahoe, CA 96150',
    surcharge: false,
    longitude: 38.94528,
    latitude: -119.97001
  },
  {
    zipcode: 96150,
    title: 'BANK OF AMERICA',
    description: '3344    LAKE TAHOE BLVD, South Lake Tahoe, CA 96150',
    surcharge: false,
    longitude: 38.94528,
    latitude: -119.97001
  },
  {
    zipcode: 96150,
    title: 'BANK OF AMERICA',
    description: '3344    LAKE TAHOE BLVD, South Lake Tahoe, CA 96150',
    surcharge: false,
    longitude: 38.94528,
    latitude: -119.97001
  },
  {
    zipcode: 96150,
    title: 'BANK OF AMERICA',
    description: '3344    LAKE TAHOE BLVD, South Lake Tahoe, CA 96150',
    surcharge: false,
    longitude: 38.94528,
    latitude: -119.97001
  },
  {
    zipcode: 96150,
    title: 'CARDTRONICS',
    description: '3376    LAKE TAHOE BLVD, South Lake Tahoe, CA 96150',
    surcharge: false,
    longitude: 38.9453,
    latitude: -119.96834
  },
  {
    zipcode: 96150,
    title: 'PULSE NETWORK',
    description: '3460    LAKE TAHOE BLVD, South Lake Tahoe, CA 96150',
    surcharge: true,
    longitude: 38.94548,
    latitude: -119.96681
  },
  {
    zipcode: 96150,
    title: 'CARDTRONICS',
    description: '3471    LAKE TAHOE BLVD, South Lake Tahoe, CA 96150',
    surcharge: true,
    longitude: 38.946,
    latitude: -119.96523
  },
  {
    zipcode: 96150,
    title: 'PULSE NETWORK',
    description: '3651    LAKE TAHOE BLVD, South Lake Tahoe, CA 96150',
    surcharge: true,
    longitude: 38.94855,
    latitude: -119.95854
  },
  {
    zipcode: 96150,
    title: 'CARDTRONICS',
    description: '3923    PIONEER TRL, South Lake Tahoe, CA 96150',
    surcharge: true,
    longitude: 38.95246,
    latitude: -119.94695
  },
  {
    zipcode: 96150,
    title: 'WELLS FARGO BANK',
    description: '4000 STE 6  LAKE TAHOE BLVD, South Lake Tahoe, CA 96150',
    surcharge: true,
    longitude: 38.95449,
    latitude: -119.94526
  },
  {
    zipcode: 96150,
    title: 'WELLS FARGO BANK',
    description: '4000 STE 6  LAKE TAHOE BLVD, South Lake Tahoe, CA 96150',
    surcharge: true,
    longitude: 38.95449,
    latitude: -119.94526
  },
  {
    zipcode: 96150,
    title: 'PULSE NETWORK',
    description: '1001    HEAVENLY VILLAGE WAY, South Lake Tahoe, CA 96150',
    surcharge: true,
    longitude: 38.95578,
    latitude: -119.94325
  },
  {
    zipcode: 96150,
    title: 'PULSE NETWORK',
    description: '1001    HEAVENLY VILLAGE WAY, South Lake Tahoe, CA 96150',
    surcharge: true,
    longitude: 38.95578,
    latitude: -119.94325
  },
  {
    zipcode: 96150,
    title: 'PULSE NETWORK',
    description: '4029    LAKE TAHOE BLVD, South Lake Tahoe, CA 96150',
    surcharge: true,
    longitude: 38.95599,
    latitude: -119.94454
  },
  {
    zipcode: 96067,
    title: 'CARDTRONICS',
    description: '160    MORGAN WAY, Mount Shasta, CA 96067',
    surcharge: true,
    longitude: 41.31,
    latitude: -122.31676
  },
  {
    zipcode: 96067,
    title: 'PULSE NETWORK',
    description: '142    MORGAN WAY, Mount Shasta, CA 96067',
    surcharge: true,
    longitude: 41.31043,
    latitude: -122.31698
  },
  {
    zipcode: 96067,
    title: 'CHASE',
    description: '168    MORGAN WAY, Mount Shasta, CA 96067',
    surcharge: true,
    longitude: 41.31043,
    latitude: -122.31698
  },
  {
    zipcode: 96067,
    title: 'MONEYPASS',
    description: '312    MAPLE ST, Mount Shasta, CA 96067',
    surcharge: false,
    longitude: 41.31256,
    latitude: -122.31331
  },
  {
    zipcode: 96067,
    title: 'PULSE NETWORK',
    description: '300   W LAKE ST, Mount Shasta, CA 96067',
    surcharge: true,
    longitude: 41.31293,
    latitude: -122.31284
  },
  {
    zipcode: 96067,
    title: 'FIS',
    description: '310   W LAKE ST, Mount Shasta, CA 96067',
    surcharge: true,
    longitude: 41.31293,
    latitude: -122.31284
  },
  {
    zipcode: 96067,
    title: 'PULSE NETWORK',
    description: '205   W LAKE ST, Mount Shasta, CA 96067',
    surcharge: true,
    longitude: 41.313,
    latitude: -122.31244
  },
  {
    zipcode: 96067,
    title: 'MONEYPASS',
    description: '204    CHESTNUT ST, Mount Shasta, CA 96067',
    surcharge: false,
    longitude: 41.31347,
    latitude: -122.31095
  },
  {
    zipcode: 96094,
    title: 'ELAN',
    description: '395 # I5 E VISTA DR, Weed, CA 96094',
    surcharge: true,
    longitude: 41.39723,
    latitude: -122.4009
  },
  {
    zipcode: 96094,
    title: 'ELAN',
    description: '395 # I5 E VISTA DR, Weed, CA 96094',
    surcharge: true,
    longitude: 41.39723,
    latitude: -122.4009
  },
  {
    zipcode: 96094,
    title: 'PULSE NETWORK',
    description: '82   E VISTA DR, Weed, CA 96094',
    surcharge: true,
    longitude: 41.41455,
    latitude: -122.41145
  },
  {
    zipcode: 96094,
    title: 'PULSE NETWORK',
    description: '375   S WEED BLVD, Weed, CA 96094',
    surcharge: true,
    longitude: 41.4148,
    latitude: -122.3836
  },
  {
    zipcode: 96094,
    title: 'PULSE NETWORK',
    description: '1976    SHASTINA DR, Weed, CA 96094',
    surcharge: true,
    longitude: 41.41709,
    latitude: -122.43549
  },
  {
    zipcode: 96094,
    title: 'PULSE NETWORK',
    description: '56   S WEED BLVD, Weed, CA 96094',
    surcharge: true,
    longitude: 41.421,
    latitude: -122.38422
  },
  {
    zipcode: 96094,
    title: 'PULSE NETWORK',
    description: '25   N WEED BLVD, Weed, CA 96094',
    surcharge: true,
    longitude: 41.42215,
    latitude: -122.38635
  },
  {
    zipcode: 96094,
    title: 'CARDTRONICS',
    description: '175   N WEED BLVD, Weed, CA 96094',
    surcharge: true,
    longitude: 41.42229,
    latitude: -122.3867
  },
  {
    zipcode: 96094,
    title: 'MONEYPASS',
    description: '269    MAIN ST, Weed, CA 96094',
    surcharge: false,
    longitude: 41.42461,
    latitude: -122.38444
  },
  {
    zipcode: 96094,
    title: 'MONEYPASS',
    description: '303    MAIN ST, Weed, CA 96094',
    surcharge: false,
    longitude: 41.42551,
    latitude: -122.38437
  },
  {
    zipcode: 96094,
    title: 'PULSE NETWORK',
    description: '20506    BIG SPRINGS RD, Weed, CA 96094',
    surcharge: true,
    longitude: 41.48899,
    latitude: -122.36214
  },
  {
    zipcode: 96097,
    title: 'PULSE NETWORK',
    description: '1802    FORT JONES RD, Yreka, CA 96097',
    surcharge: true,
    longitude: 41.69966,
    latitude: -122.64699
  },
  {
    zipcode: 96097,
    title: 'WELLS FARGO BANK',
    description: '1842    FORT JONES RD, Yreka, CA 96097',
    surcharge: true,
    longitude: 41.69966,
    latitude: -122.64699
  },
  {
    zipcode: 96097,
    title: 'PULSE NETWORK',
    description: '1906    FORT JONES RD, Yreka, CA 96097',
    surcharge: true,
    longitude: 41.7023,
    latitude: -122.64548
  },
  {
    zipcode: 96097,
    title: 'PULSE NETWORK',
    description: '1258   S MAIN ST, Yreka, CA 96097',
    surcharge: true,
    longitude: 41.71656,
    latitude: -122.63983
  },
  {
    zipcode: 96097,
    title: 'FIS',
    description: '807   S MAIN ST, Yreka, CA 96097',
    surcharge: true,
    longitude: 41.72526,
    latitude: -122.63854
  },
  {
    zipcode: 96097,
    title: 'CHASE',
    description: '825   S MAIN ST, Yreka, CA 96097',
    surcharge: true,
    longitude: 41.72526,
    latitude: -122.63854
  },
  {
    zipcode: 96097,
    title: 'PULSE NETWORK',
    description: '515   S BROADWAY ST, Yreka, CA 96097',
    surcharge: true,
    longitude: 41.72995,
    latitude: -122.63557
  },
  {
    zipcode: 96097,
    title: 'MONEYPASS',
    description: '123   N MAIN ST, Yreka, CA 96097',
    surcharge: false,
    longitude: 41.73102,
    latitude: -122.6358
  },
  {
    zipcode: 96097,
    title: 'MONEYPASS',
    description: '220   W CENTER ST, Yreka, CA 96097',
    surcharge: false,
    longitude: 41.73125,
    latitude: -122.63752
  },
  {
    zipcode: 96097,
    title: 'MONEYPASS',
    description: '165   S BROADWAY ST, Yreka, CA 96097',
    surcharge: false,
    longitude: 41.73146,
    latitude: -122.63725
  },
  {
    zipcode: 96097,
    title: 'REDDING BANK OF COMMERCE',
    description: '200   S BROADWAY ST, Yreka, CA 96097',
    surcharge: false,
    longitude: 41.73146,
    latitude: -122.63725
  },
  {
    zipcode: 96097,
    title: 'BANK OF AMERICA',
    description: '200   S BROADWAY ST, Yreka, CA 96097',
    surcharge: false,
    longitude: 41.73146,
    latitude: -122.63725
  },
  {
    zipcode: 96097,
    title: 'PULSE NETWORK',
    description: '115   E MINER ST, Yreka, CA 96097',
    surcharge: true,
    longitude: 41.73247,
    latitude: -122.63532
  },
  {
    zipcode: 96097,
    title: 'PULSE NETWORK',
    description: '200   S MAIN ST, Yreka, CA 96097',
    surcharge: true,
    longitude: 41.73247,
    latitude: -122.63532
  },
  {
    zipcode: 96064,
    title: 'PULSE NETWORK',
    description: '250   E WEBB ST, Montague, CA 96064',
    surcharge: true,
    longitude: 41.73265,
    latitude: -122.42014
  },
  {
    zipcode: 96058,
    title: 'PULSE NETWORK',
    description: '41501    STATE HIGHWAY 97, Macdoel, CA 96058',
    surcharge: true,
    longitude: 41.74047,
    latitude: -121.93645
  },
  {
    zipcode: 93012,
    title: 'PULSE',
    description: '1 UNIVERSITY AVE, Camarillo, CA 93012',
    surcharge: true,
    longitude: 34.18044,
    latitude: -119.03879
  },
  {
    zipcode: 94131,
    title: 'SWITCH COMMERCE INC.',
    description: '100 CHENERY ST, San Francisco, CA 94131',
    surcharge: true,
    longitude: 37.73952,
    latitude: -122.42572
  },
  {
    zipcode: 93030,
    title: 'RBS WORLD/PAY',
    description: '100 DEL NORTE BLVD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.22201,
    latitude: -119.12675
  },
  {
    zipcode: 94105,
    title: '',
    description: '100 FIRST ST, SAN FRANCISCO, CA 94105',
    surcharge: false,
    longitude: 37.78968,
    latitude: -122.39762
  },
  {
    zipcode: 94105,
    title: '',
    description: '100 FIRST ST, SAN FRANCISCO, CA 94105',
    surcharge: false,
    longitude: 37.78968,
    latitude: -122.39762
  },
  {
    zipcode: 93015,
    title: 'PULSE',
    description: '100 MARKET ST, Fillmore, CA 93015',
    surcharge: true,
    longitude: 34.39945,
    latitude: -118.91762
  },
  {
    zipcode: 93015,
    title: 'PULSE',
    description: '100 MARKET STREET, Fillmore, CA 93015',
    surcharge: true,
    longitude: 34.39945,
    latitude: -118.91762
  },
  {
    zipcode: 96067,
    title: 'PULSE',
    description: '1000 SISKIYOU LAKE, Mount Shasta, CA 96067',
    surcharge: true,
    longitude: 41.28823,
    latitude: -122.31967
  },
  {
    zipcode: 94109,
    title: 'SWITCH COMMERCE INC.',
    description: '1000 VAN NESS AVE, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78478,
    latitude: -122.42109
  },
  {
    zipcode: 94114,
    title: 'SWITCH COMMERCE INC.',
    description: '1001 CASTRO ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.75361,
    latitude: -122.43421
  },
  {
    zipcode: 94110,
    title: 'CARDTRONICS',
    description: '1001 VALENCIA ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75614,
    latitude: -122.42095
  },
  {
    zipcode: 94109,
    title: 'PULSE',
    description: '1008 BH STREET     .., San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.79598,
    latitude: -122.4236
  },
  {
    zipcode: 94103,
    title: '',
    description: '1065 MISSION ST, SAN FRANCISCO, CA 94103',
    surcharge: true,
    longitude: 37.77954,
    latitude: -122.41037
  },
  {
    zipcode: 94109,
    title: 'PULSE',
    description: '1068 HYDE STREET, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.79047,
    latitude: -122.4172
  },
  {
    zipcode: 94103,
    title: 'SWITCH COMMERCE INC.',
    description: '1087 MARKET ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78133,
    latitude: -122.4112
  },
  {
    zipcode: 94116,
    title: 'RBS WORLD/PAY',
    description: '1098 HOWARD ST, San Francisco, CA 94116',
    surcharge: true,
    longitude: 37.77837,
    latitude: -122.40903
  },
  {
    zipcode: 93065,
    title: 'RBS WORLD/PAY',
    description: '1180 PATRICIA ST S, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27064,
    latitude: -118.77504
  },
  {
    zipcode: 94107,
    title: 'PULSE',
    description: '120 BRANNAN STREET, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.78407,
    latitude: -122.3894
  },
  {
    zipcode: 94110,
    title: 'CARDTRONICS',
    description: '1200 ELCAMINOREAL, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75826,
    latitude: -122.41691
  },
  {
    zipcode: 94112,
    title: 'PULSE',
    description: '1200 GENEVA AVENUE, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.71365,
    latitude: -122.43527
  },
  {
    zipcode: 94122,
    title: 'PULSE',
    description: '1201 9TH AVE., San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.7651,
    latitude: -122.46647
  },
  {
    zipcode: 94109,
    title: 'PULSE',
    description: '1202 SUTTER STREET, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78778,
    latitude: -122.4206
  },
  {
    zipcode: 93065,
    title: 'RBS WORLD/PAY',
    description: '1220 SYCAMORE DRIV, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.26201,
    latitude: -118.74769
  },
  {
    zipcode: 94103,
    title: 'PULSE',
    description: '1256 MISSION STREET, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77704,
    latitude: -122.41383
  },
  {
    zipcode: 94110,
    title: 'PULSE',
    description: '1266 VALENCIA STREE, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75826,
    latitude: -122.41691
  },
  {
    zipcode: 94102,
    title: 'SWITCH COMMERCE INC.',
    description: '127 EDDY ST SAN FRA, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78067,
    latitude: -122.41744
  },
  {
    zipcode: 94122,
    title: 'CARDTRONICS',
    description: '1288 19TH AVE, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.76429,
    latitude: -122.47716
  },
  {
    zipcode: 94109,
    title: 'SWITCH COMMERCE INC.',
    description: '1290 SUTTER ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78765,
    latitude: -122.42162
  },
  {
    zipcode: 94110,
    title: 'PULSE',
    description: '1298 VALENCIA ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75271,
    latitude: -122.42081
  },
  {
    zipcode: 94124,
    title: '',
    description: '1300 EVANS AVENUE, SAN FRANCISCO, CA 94124',
    surcharge: true,
    longitude: 37.73998,
    latitude: -122.38275
  },
  {
    zipcode: 94103,
    title: 'PULSE',
    description: '133 6TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78057,
    latitude: -122.40806
  },
  {
    zipcode: 94103,
    title: '',
    description: '136 6TH ST, SAN FRANCISCO, CA 94103',
    surcharge: true,
    longitude: 37.7804,
    latitude: -122.40814
  },
  {
    zipcode: 94133,
    title: 'FIS',
    description: '1398 EMBARCADERO RD, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80031,
    latitude: -122.4104
  },
  {
    zipcode: 94103,
    title: 'PULSE',
    description: '14 VALENCIA ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77242,
    latitude: -122.42271
  },
  {
    zipcode: 94102,
    title: 'PULSE',
    description: '140 MASON ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78473,
    latitude: -122.40929
  },
  {
    zipcode: 94110,
    title: 'PULSE',
    description: '1404 VALENCIA ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.74964,
    latitude: -122.42051
  },
  {
    zipcode: 93001,
    title: 'FISERV',
    description: '1418 E MAIN STREET, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.28026,
    latitude: -119.27947
  },
  {
    zipcode: 93003,
    title: 'RBS WORLD/PAY',
    description: '1440 EASTMAN AVENUE, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.25978,
    latitude: -119.23021
  },
  {
    zipcode: 93003,
    title: 'MONEYPASS',
    description: '1449 S. VICTORIA AVENUE #B, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.26157,
    latitude: -119.21173
  },
  {
    zipcode: 94112,
    title: 'FIS',
    description: '145 BOSWORTH ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.73344,
    latitude: -122.4279
  },
  {
    zipcode: 94122,
    title: 'PULSE',
    description: '1460 48TH AVE, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.75983,
    latitude: -122.50794
  },
  {
    zipcode: 93065,
    title: 'RBS WORLD/PAY',
    description: '1464 MADERO ROAD, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.26546,
    latitude: -118.79621
  },
  {
    zipcode: 94130,
    title: 'RBS WORLD/PAY',
    description: '150 4TH STREET #1, San Francisco, CA 94130',
    surcharge: true,
    longitude: 37.82406,
    latitude: -122.36481
  },
  {
    zipcode: 94134,
    title: 'PULSE',
    description: '1524 SILVER AVE., San Francisco, CA 94134',
    surcharge: true,
    longitude: 37.73221,
    latitude: -122.40604
  },
  {
    zipcode: 94117,
    title: 'FIS',
    description: '1535 HAIGHT ST., San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.76983,
    latitude: -122.44759
  },
  {
    zipcode: 93065,
    title: 'RBS WORLD/PAY',
    description: '1555 E. LOS ANGELE, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27181,
    latitude: -118.76867
  },
  {
    zipcode: 93001,
    title: 'RBS WORLD/PAY',
    description: '1583 SPINNAKER DR #104, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.24361,
    latitude: -119.25891
  },
  {
    zipcode: 94115,
    title: 'FIS',
    description: '1598 MCALISTER ST., San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.77801,
    latitude: -122.43732
  },
  {
    zipcode: 94109,
    title: 'FIS',
    description: '1600 BH ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.79598,
    latitude: -122.4236
  },
  {
    zipcode: 94103,
    title: 'SWITCH COMMERCE INC.',
    description: '1601 MISSION ST., San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77211,
    latitude: -122.41899
  },
  {
    zipcode: 94109,
    title: 'PULSE',
    description: '1619 POLK STREET, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.79167,
    latitude: -122.421
  },
  {
    zipcode: 93065,
    title: 'ELAN',
    description: '1631 ROYAL AVENUE, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.26456,
    latitude: -118.76644
  },
  {
    zipcode: 94115,
    title: 'FIS',
    description: '1635 DIVISADERO ST., San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78461,
    latitude: -122.43988
  },
  {
    zipcode: 93065,
    title: 'PULSE',
    description: '1650 LOS ANGELES AV, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27163,
    latitude: -118.7663
  },
  {
    zipcode: 94158,
    title: '',
    description: '1675 OWENS STREET, SAN FRANCISCO, CA 94158',
    surcharge: true,
    longitude: 37.6152,
    latitude: -122.22932
  },
  {
    zipcode: 94117,
    title: 'RBS WORLD/PAY',
    description: '1700 HAYES ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77413,
    latitude: -122.44524
  },
  {
    zipcode: 91362,
    title: 'RBS WORLD/PAY',
    description: '1715 E. THOAND O, Thousand Oaks, CA 91362',
    surcharge: true,
    longitude: 34.18236,
    latitude: -118.82863
  },
  {
    zipcode: 94133,
    title: 'FIS',
    description: '1756 STOCKTON ST, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80187,
    latitude: -122.40938
  },
  {
    zipcode: 96097,
    title: '',
    description: '1760 CHALLENGE WAY, SACRAMENTO, CA 96097',
    surcharge: false,
    longitude: 38.59697,
    latitude: -121.42578
  },
  {
    zipcode: 93065,
    title: 'RBS WORLD/PAY',
    description: '1790 E. LOS ANGELE, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27163,
    latitude: -118.76383
  },
  {
    zipcode: 94112,
    title: 'SWITCH COMMERCE INC.',
    description: '1798 ALEMANY BLVD., San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.7244,
    latitude: -122.43742
  },
  {
    zipcode: 94103,
    title: 'RBS WORLD/PAY',
    description: '181 THIRD STREET, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78561,
    latitude: -122.40106
  },
  {
    zipcode: 93001,
    title: '1ST ISO PROCESSING',
    description: '1888 E THOMPSON BL, Ventura, CA 93001',
    surcharge: true,
    longitude: 34.2749,
    latitude: -119.27352
  },
  {
    zipcode: 94102,
    title: 'PULSE',
    description: '1906 MARKET ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.77029,
    latitude: -122.42564
  },
  {
    zipcode: 94103,
    title: 'PULSE',
    description: '1932 MISSION ST., San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76574,
    latitude: -122.41982
  },
  {
    zipcode: 96150,
    title: 'SWITCH COMMERCE INC.',
    description: '1950 LAKE TAHOE BLV, South Lake Tahoe, CA 96150',
    surcharge: true,
    longitude: 38.91186,
    latitude: -120.00685
  },
  {
    zipcode: 93030,
    title: 'CARDTRONICS',
    description: '200  N HAYES AVE, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.205,
    latitude: -119.17525
  },
  {
    zipcode: 93023,
    title: 'RBS WORLD/PAY',
    description: '201 N. SIGNAL STRE, Ojai, CA 93023',
    surcharge: true,
    longitude: 34.44494,
    latitude: -119.25841
  },
  {
    zipcode: 91362,
    title: 'MONEYPASS',
    description: '2036 E AVENIDA DE LOS ARBOLES, Thousand Oaks, CA 91362',
    surcharge: false,
    longitude: 34.21116,
    latitude: -118.84202
  },
  {
    zipcode: 93010,
    title: 'PULSE',
    description: '2071 VENTURA BLVD, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.21699,
    latitude: -119.04272
  },
  {
    zipcode: 95762,
    title: 'PULSE',
    description: '2101 VINE ST, El Dorado Hills, CA 95762',
    surcharge: true,
    longitude: 38.6521,
    latitude: -121.06198
  },
  {
    zipcode: 93030,
    title: 'RBS WORLD/PAY',
    description: '2101 WEST VINEYARD, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.22954,
    latitude: -119.19895
  },
  {
    zipcode: 94115,
    title: 'SWITCH COMMERCE INC.',
    description: '2135 BUCHANAN ST, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78964,
    latitude: -122.4307
  },
  {
    zipcode: 94123,
    title: 'CARDTRONICS',
    description: '2141 CHESTNUT ST, San Francisco, CA 94123',
    surcharge: true,
    longitude: 37.80044,
    latitude: -122.43844
  },
  {
    zipcode: 93010,
    title: 'RBS WORLD/PAY',
    description: '2161 PICKWICK DRIV, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.22229,
    latitude: -119.04263
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '2171 MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.7624,
    latitude: -122.41932
  },
  {
    zipcode: 94109,
    title: 'PULSE',
    description: '2216 POLK STREET, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.79741,
    latitude: -122.42197
  },
  {
    zipcode: 93063,
    title: 'MONEYPASS',
    description: '2268 TAPO, Simi Valley, CA 93063',
    surcharge: false,
    longitude: 34.27649,
    latitude: -118.70885
  },
  {
    zipcode: 93010,
    title: 'MONEYPASS',
    description: '2277 LAS POSAS ROAD, Camarillo, CA 93010',
    surcharge: false,
    longitude: 34.23649,
    latitude: -119.03947
  },
  {
    zipcode: 94107,
    title: 'PULSE',
    description: '2295 3RD STREET, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.76093,
    latitude: -122.38853
  },
  {
    zipcode: 94110,
    title: 'PULSE',
    description: '2299 MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76067,
    latitude: -122.41915
  },
  {
    zipcode: 94109,
    title: 'SWITCH COMMERCE INC.',
    description: '2301 VAN NESS, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.79745,
    latitude: -122.42394
  },
  {
    zipcode: 94121,
    title: 'SWITCH COMMERCE INC.',
    description: '2342 CLEMENT ST, San Francisco, CA 94121',
    surcharge: true,
    longitude: 37.78214,
    latitude: -122.48422
  },
  {
    zipcode: 93010,
    title: 'RBS WORLD/PAY',
    description: '2344 VENTURA BLVD, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.21631,
    latitude: -119.03814
  },
  {
    zipcode: 94114,
    title: 'CARDTRONICS',
    description: '2399 MARKET ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.76351,
    latitude: -122.43371
  },
  {
    zipcode: 96057,
    title: 'PULSE',
    description: '241 MAIN STREET, Mccloud, CA 96057',
    surcharge: true,
    longitude: 41.25404,
    latitude: -122.13876
  },
  {
    zipcode: 94114,
    title: 'SWITCH COMMERCE INC.',
    description: '2416 MARKET STREET, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.76259,
    latitude: -122.43556
  },
  {
    zipcode: 94122,
    title: 'PULSE',
    description: '2431 NORIEGA STREET, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.75356,
    latitude: -122.48965
  },
  {
    zipcode: 94117,
    title: 'FIS',
    description: '247 FILLMORE ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77169,
    latitude: -122.43045
  },
  {
    zipcode: 93063,
    title: 'RBS WORLD/PAY',
    description: '2488 TAPO SREEET #, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.27872,
    latitude: -118.69879
  },
  {
    zipcode: 94115,
    title: 'FIS',
    description: '2500 GEARY BLVD, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78262,
    latitude: -122.44555
  },
  {
    zipcode: 94133,
    title: 'PULSE',
    description: '2500 MASON STREET, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80657,
    latitude: -122.41369
  },
  {
    zipcode: 94115,
    title: 'PULSE',
    description: '2501 CALIFORNIA ST., San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.78848,
    latitude: -122.43641
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '2524 MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75637,
    latitude: -122.41892
  },
  {
    zipcode: 93010,
    title: 'MONEYPASS',
    description: '256 CARMEN DRIVE, Camarillo, CA 93010',
    surcharge: false,
    longitude: 34.22029,
    latitude: -119.05058
  },
  {
    zipcode: 94110,
    title: 'PULSE',
    description: '2565 MISSION ST., San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75622,
    latitude: -122.41873
  },
  {
    zipcode: 94112,
    title: 'SWITCH COMMERCE INC.',
    description: '2598 SAN JOSE AVE, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.71688,
    latitude: -122.44988
  },
  {
    zipcode: 93033,
    title: 'FIS',
    description: '2661 SAVIERS ROAD, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.17527,
    latitude: -119.17762
  },
  {
    zipcode: 91360,
    title: 'RBS WORLD/PAY',
    description: '2689 N. MOORPARK RD., Thousand Oaks, CA 91360',
    surcharge: true,
    longitude: 34.21889,
    latitude: -118.86833
  },
  {
    zipcode: 94133,
    title: 'PULSE',
    description: '2699 TAYLOR STREET, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80689,
    latitude: -122.41563
  },
  {
    zipcode: 94110,
    title: 'SWITCH COMMERCE INC.',
    description: '2702 24TH ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75302,
    latitude: -122.40677
  },
  {
    zipcode: 94133,
    title: 'SWITCH COMMERCE INC.',
    description: '2711 TAYLOR ST, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80752,
    latitude: -122.41575
  },
  {
    zipcode: 94110,
    title: 'PULSE',
    description: '2765 MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75306,
    latitude: -122.41843
  },
  {
    zipcode: 94123,
    title: 'SWITCH COMMERCE INC.',
    description: '2767 LOMBARD, San Francisco, CA 94123',
    surcharge: true,
    longitude: 37.79844,
    latitude: -122.44669
  },
  {
    zipcode: 93003,
    title: 'RBS WORLD/PAY',
    description: '2790 E. THOMPSON BLVD, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.27192,
    latitude: -119.25848
  },
  {
    zipcode: 95651,
    title: 'PULSE',
    description: '2791 HWY 49, Lotus, CA 95651',
    surcharge: true,
    longitude: 38.80697,
    latitude: -120.92905
  },
  {
    zipcode: 94133,
    title: 'CARDTRONICS',
    description: '2801 JONES  ST, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80706,
    latitude: -122.41735
  },
  {
    zipcode: 94133,
    title: 'SWITCH COMMERCE INC.',
    description: '2801 LEAVENWORTH ST, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80684,
    latitude: -122.41899
  },
  {
    zipcode: 93003,
    title: 'PULSE',
    description: '2825 JOHNSON AVE, Ventura, CA 93003',
    surcharge: true,
    longitude: 34.24707,
    latitude: -119.19515
  },
  {
    zipcode: 94132,
    title: 'CARDTRONICS',
    description: '285 WINSTON DRIVE, San Francisco, CA 94132',
    surcharge: true,
    longitude: 37.72689,
    latitude: -122.4757
  },
  {
    zipcode: 94133,
    title: 'RBS WORLD/PAY',
    description: '286 JEFFERSON ST, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80799,
    latitude: -122.41826
  },
  {
    zipcode: 94110,
    title: 'SWITCH COMMERCE INC.',
    description: '2898 FOLSOM, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75164,
    latitude: -122.41409
  },
  {
    zipcode: 95667,
    title: 'RBS WORLD/PAY',
    description: '2901 HIGH HILL RD, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.73969,
    latitude: -120.71252
  },
  {
    zipcode: 94110,
    title: 'RBS WORLD/PAY',
    description: '2922 MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.74936,
    latitude: -122.41825
  },
  {
    zipcode: 94110,
    title: 'SWITCH COMMERCE INC.',
    description: '2948 24TH ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.7528,
    latitude: -122.41041
  },
  {
    zipcode: 94110,
    title: 'PULSE',
    description: '2950 25TH STREET, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75126,
    latitude: -122.40937
  },
  {
    zipcode: 93065,
    title: 'CARDTRONICS',
    description: '2950 COCHRAN STSTE D, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.26703,
    latitude: -118.77491
  },
  {
    zipcode: 96150,
    title: 'CARDTRONICS',
    description: '2977 HWY 50, South Lake Tahoe, CA 96150',
    surcharge: true,
    longitude: 38.86042,
    latitude: -120.01776
  },
  {
    zipcode: 94105,
    title: 'RBS WORLD/PAY',
    description: '299 SECOND ST, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.78562,
    latitude: -122.39665
  },
  {
    zipcode: 94110,
    title: 'RBS WORLD/PAY',
    description: '2999 HARRISON STRE, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75826,
    latitude: -122.41691
  },
  {
    zipcode: 95682,
    title: 'PULSE',
    description: '3000 GREEN VALLEY R, Shingle Springs, CA 95682',
    surcharge: true,
    longitude: 38.69703,
    latitude: -121.00146
  },
  {
    zipcode: 94127,
    title: 'FIS',
    description: '301 CLAREMONT BLVD, San Francisco, CA 94127',
    surcharge: true,
    longitude: 37.74025,
    latitude: -122.46508
  },
  {
    zipcode: 94110,
    title: 'SWITCH COMMERCE INC.',
    description: '3049 20TH ST., San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75903,
    latitude: -122.41092
  },
  {
    zipcode: 91362,
    title: 'CARDTRONICS',
    description: '30740 RSELL RANCH, Thousand Oaks, CA 91362',
    surcharge: true,
    longitude: 34.15621,
    latitude: -118.8045
  },
  {
    zipcode: 94110,
    title: 'SWITCH COMMERCE INC.',
    description: '3122 16TH ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76498,
    latitude: -122.42221
  },
  {
    zipcode: 94103,
    title: 'SWITCH COMMERCE INC.',
    description: '3131 16TH ST., San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.76479,
    latitude: -122.42246
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '3139 MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.74708,
    latitude: -122.41881
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '3149 22ND ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75541,
    latitude: -122.41752
  },
  {
    zipcode: 94110,
    title: 'SWITCH COMMERCE INC.',
    description: '3149 24TH ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75239,
    latitude: -122.41444
  },
  {
    zipcode: 94116,
    title: 'RBS WORLD/PAY',
    description: '3150 VICENTE ST, San Francisco, CA 94116',
    surcharge: true,
    longitude: 37.7383,
    latitude: -122.5005
  },
  {
    zipcode: 94110,
    title: 'PULSE',
    description: '3216 FOLSOM STREET, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.74609,
    latitude: -122.41355
  },
  {
    zipcode: 91320,
    title: 'CARDTRONICS',
    description: '3309 KIMBER DR, Newbury Park, CA 91320',
    surcharge: true,
    longitude: 34.17615,
    latitude: -118.9456
  },
  {
    zipcode: 94110,
    title: 'SWITCH COMMERCE INC.',
    description: '3318 24TH ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.7523,
    latitude: -122.41891
  },
  {
    zipcode: 95682,
    title: 'PULSE',
    description: '3326 COACH LN., Shingle Springs, CA 95682',
    surcharge: true,
    longitude: 38.65814,
    latitude: -120.96951
  },
  {
    zipcode: 94103,
    title: 'MONEYPASS',
    description: '333 11TH STREET, San Francisco, CA 94103',
    surcharge: false,
    longitude: 37.77113,
    latitude: -122.41296
  },
  {
    zipcode: 94102,
    title: 'FIS',
    description: '333 GEARY ST., San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78711,
    latitude: -122.40942
  },
  {
    zipcode: 96067,
    title: 'FIS',
    description: '333 N MT SHASTA BLVD, Mount Shasta, CA 96067',
    surcharge: true,
    longitude: 41.31322,
    latitude: -122.31236
  },
  {
    zipcode: 94110,
    title: 'SWITCH COMMERCE INC.',
    description: '3398 22ND ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.7553,
    latitude: -122.42245
  },
  {
    zipcode: 94110,
    title: 'PULSE',
    description: '3398 22ND STREET, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.7553,
    latitude: -122.42245
  },
  {
    zipcode: 91360,
    title: '',
    description: '33M NORTH MOORPARK RD, THOUSAND OAKS, CA 91360',
    surcharge: false,
    longitude: 34.1781,
    latitude: -118.87648
  },
  {
    zipcode: 94122,
    title: 'PULSE',
    description: '3400 JUDAH STREET, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.76083,
    latitude: -122.49862
  },
  {
    zipcode: 94102,
    title: 'CARDTRONICS',
    description: '351 GEARY ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78711,
    latitude: -122.40942
  },
  {
    zipcode: 94118,
    title: 'CARDTRONICS',
    description: '3600 GEARY BLVD, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78145,
    latitude: -122.45801
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '3608 18TH ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76157,
    latitude: -122.42517
  },
  {
    zipcode: 94133,
    title: 'RBS WORLD/PAY',
    description: '366 COLUMB, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.79838,
    latitude: -122.40725
  },
  {
    zipcode: 93010,
    title: 'RBS WORLD/PAY',
    description: '3661 LA POSAS RD #, Camarillo, CA 93010',
    surcharge: true,
    longitude: 34.22904,
    latitude: -119.05036
  },
  {
    zipcode: 94114,
    title: 'RBS WORLD/PAY',
    description: '3698 17TH ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.76301,
    latitude: -122.42795
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '3698 20TH STREET, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75849,
    latitude: -122.42283
  },
  {
    zipcode: 94103,
    title: 'SWITCH COMMERCE INC.',
    description: '371 11TH STREET, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.77113,
    latitude: -122.41296
  },
  {
    zipcode: 94114,
    title: 'SWITCH COMMERCE INC.',
    description: '3801 24TH STREET, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.75158,
    latitude: -122.42798
  },
  {
    zipcode: 94124,
    title: '',
    description: '3801 THIRD ST STE 550, SAN FRANCISCO, CA 94124',
    surcharge: true,
    longitude: 37.74266,
    latitude: -122.38783
  },
  {
    zipcode: 94124,
    title: '',
    description: '3801 THIRD ST., SAN FRANCISCO, CA 94124',
    surcharge: true,
    longitude: 37.74266,
    latitude: -122.38783
  },
  {
    zipcode: 94122,
    title: 'RBS WORLD/PAY',
    description: '3821 NORIEGA ST, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.75291,
    latitude: -122.50448
  },
  {
    zipcode: 91362,
    title: 'FIS',
    description: '3825 E THOAND OAKS, Thousand Oaks, CA 91362',
    surcharge: true,
    longitude: 34.18236,
    latitude: -118.82863
  },
  {
    zipcode: 93063,
    title: 'CARDTRONICS',
    description: '3935 COCHRAN ST, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.27911,
    latitude: -118.71882
  },
  {
    zipcode: 94122,
    title: 'FIS',
    description: '3960 IRVING ST, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.76264,
    latitude: -122.49998
  },
  {
    zipcode: 94114,
    title: 'PULSE',
    description: '3988 18TH STREET, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.76116,
    latitude: -122.43189
  },
  {
    zipcode: 94102,
    title: 'FIS',
    description: '400 MCALLISTER ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78034,
    latitude: -122.41861
  },
  {
    zipcode: 94122,
    title: '',
    description: '400 PARNASSUS AVE, SAN FRANCISCO, CA 94122',
    surcharge: true,
    longitude: 37.76386,
    latitude: -122.45839
  },
  {
    zipcode: 95682,
    title: 'CARDTRONICS',
    description: '4014 PLAZA GOLDORADO, Shingle Springs, CA 95682',
    surcharge: true,
    longitude: 38.66221,
    latitude: -120.97025
  },
  {
    zipcode: 94114,
    title: 'PULSE',
    description: '4023 18TH STREET, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.76089,
    latitude: -122.43334
  },
  {
    zipcode: 94118,
    title: 'RBS WORLD/PAY',
    description: '4157 GEARY BLVD., San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78098,
    latitude: -122.46352
  },
  {
    zipcode: 94118,
    title: 'PULSE',
    description: '4201 GEARY BLVD., San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78092,
    latitude: -122.4645
  },
  {
    zipcode: 95682,
    title: 'FIS',
    description: '4201 MOTHER LODE DR, Shingle Springs, CA 95682',
    surcharge: true,
    longitude: 38.66346,
    latitude: -120.93343
  },
  {
    zipcode: 95762,
    title: '',
    description: '4203 TOWN CENTER DRBLDG B-VENDING AREA, EL DORADO HILLS, CA 95762',
    surcharge: true,
    longitude: 38.68293,
    latitude: -121.06867
  },
  {
    zipcode: 93030,
    title: 'CARDTRONICS',
    description: '421 S VENTURA RD #1, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.19869,
    latitude: -119.19484
  },
  {
    zipcode: 96067,
    title: 'CARDTRONICS',
    description: '4239 WA BARR RD, Mount Shasta, CA 96067',
    surcharge: true,
    longitude: 41.27155,
    latitude: -122.34895
  },
  {
    zipcode: 94108,
    title: 'FIS',
    description: '439 STOCKTON ST, San Francisco, CA 94108',
    surcharge: true,
    longitude: 37.78998,
    latitude: -122.40716
  },
  {
    zipcode: 94124,
    title: 'SWITCH COMMERCE INC.',
    description: '4404 3RD ST, San Francisco, CA 94124',
    surcharge: true,
    longitude: 37.73781,
    latitude: -122.3898
  },
  {
    zipcode: 94118,
    title: 'FIS',
    description: '441 CLEMENT ST, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.78288,
    latitude: -122.46361
  },
  {
    zipcode: 94109,
    title: 'CARDTRONICS',
    description: '441 JEFFERSON ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.80757,
    latitude: -122.42015
  },
  {
    zipcode: 95667,
    title: 'PULSE',
    description: '4430 PLEASANT VALLE, Placerville, CA 95667',
    surcharge: true,
    longitude: 38.68581,
    latitude: -120.66776
  },
  {
    zipcode: 94108,
    title: 'PULSE',
    description: '447 SUTTER ST, San Francisco, CA 94108',
    surcharge: true,
    longitude: 37.78925,
    latitude: -122.40764
  },
  {
    zipcode: 94103,
    title: 'FIS',
    description: '448 BEACH STREET, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.80727,
    latitude: -122.41633
  },
  {
    zipcode: 94102,
    title: 'RBS WORLD/PAY',
    description: '450 POWELL STREET, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78888,
    latitude: -122.40843
  },
  {
    zipcode: 93030,
    title: 'FIS',
    description: '450 S. VICTORIA AVE, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.20838,
    latitude: -119.22084
  },
  {
    zipcode: 94112,
    title: 'FIS',
    description: '4528 MISSION ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.72557,
    latitude: -122.43423
  },
  {
    zipcode: 94117,
    title: '',
    description: '460 HAIGHT STREET, SAN FRANCISCO, CA 94117',
    surcharge: true,
    longitude: 37.77232,
    latitude: -122.42941
  },
  {
    zipcode: 93012,
    title: 'CARDTRONICS',
    description: '4676 ADOLFO RD, Camarillo, CA 93012',
    surcharge: true,
    longitude: 34.21792,
    latitude: -119.00231
  },
  {
    zipcode: 93036,
    title: 'RBS WORLD/PAY',
    description: '4708 E. VINEYARD A, Oxnard, CA 93036',
    surcharge: true,
    longitude: 34.25798,
    latitude: -119.153
  },
  {
    zipcode: 93021,
    title: 'RBS WORLD/PAY',
    description: '476 W LOS ANGELES, Moorpark, CA 93021',
    surcharge: true,
    longitude: 34.28636,
    latitude: -118.81083
  },
  {
    zipcode: 93033,
    title: 'CARDTRONICS',
    description: '4815 S ROSE AVE, Oxnard, CA 93033',
    surcharge: true,
    longitude: 34.15699,
    latitude: -119.15959
  },
  {
    zipcode: 94102,
    title: 'FIS',
    description: '483 ELLIS ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78465,
    latitude: -122.41365
  },
  {
    zipcode: 93033,
    title: '',
    description: '4833 S. ROSE AVE., OXNARD, CA 93033',
    surcharge: false,
    longitude: 34.15699,
    latitude: -119.15959
  },
  {
    zipcode: 93063,
    title: 'FIS',
    description: '4860 ALAMO ST, Simi Valley, CA 93063',
    surcharge: true,
    longitude: 34.28614,
    latitude: -118.69852
  },
  {
    zipcode: 94102,
    title: 'FIS',
    description: '488 A HAYES, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.77692,
    latitude: -122.42339
  },
  {
    zipcode: 94102,
    title: 'PULSE',
    description: '491 ELLIS STREET, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78465,
    latitude: -122.41365
  },
  {
    zipcode: 96025,
    title: '',
    description: '4929 DUNSMUIR AVE., DUNSMUIR, CA 96025',
    surcharge: true,
    longitude: 41.22245,
    latitude: -122.27609
  },
  {
    zipcode: 94133,
    title: 'PULSE',
    description: '494 BROADWAY, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.7983,
    latitude: -122.40393
  },
  {
    zipcode: 93065,
    title: 'FIS',
    description: '494 E LOS ANGELES AVE, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.27162,
    latitude: -118.788
  },
  {
    zipcode: 94133,
    title: 'PULSE',
    description: '495 BEACH STREET, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80031,
    latitude: -122.4104
  },
  {
    zipcode: 94124,
    title: 'FIS',
    description: '500 BAYSHORE BLVD., San Francisco, CA 94124',
    surcharge: true,
    longitude: 37.73923,
    latitude: -122.40692
  },
  {
    zipcode: 94104,
    title: 'PULSE',
    description: '500 CALIFORNIA ST., San Francisco, CA 94104',
    surcharge: true,
    longitude: 37.79286,
    latitude: -122.40338
  },
  {
    zipcode: 94117,
    title: 'FIS',
    description: '500 DIVISADERO ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77437,
    latitude: -122.43753
  },
  {
    zipcode: 95614,
    title: 'PULSE',
    description: '5030 ELLINGHOE DR, Cool, CA 95614',
    surcharge: true,
    longitude: 38.8861,
    latitude: -121.01501
  },
  {
    zipcode: 93065,
    title: 'CARDTRONICS',
    description: '51 TIERRA REJADA RD, Simi Valley, CA 93065',
    surcharge: true,
    longitude: 34.2741,
    latitude: -118.80418
  },
  {
    zipcode: 94102,
    title: 'FIS',
    description: '510 LARKIN ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.7827,
    latitude: -122.41731
  },
  {
    zipcode: 94105,
    title: 'PULSE',
    description: '511 HARRISON, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.78572,
    latitude: -122.39322
  },
  {
    zipcode: 94112,
    title: 'PULSE',
    description: '5179 MISSION STREET, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.71619,
    latitude: -122.44111
  },
  {
    zipcode: 94131,
    title: 'CARDTRONICS',
    description: '5260 DIAMOND HEIGHTS, San Francisco, CA 94131',
    surcharge: true,
    longitude: 37.74456,
    latitude: -122.43962
  },
  {
    zipcode: 93021,
    title: '',
    description: '530 E LOS ANGELES, MOORPARK, CA 93021',
    surcharge: true,
    longitude: 34.27883,
    latitude: -118.87193
  },
  {
    zipcode: 93041,
    title: 'PULSE',
    description: '530 E PLEASANT VALLEY RD, Port Hueneme, CA 93041',
    surcharge: true,
    longitude: 34.15471,
    latitude: -119.19301
  },
  {
    zipcode: 94107,
    title: 'FIS',
    description: '545 2ND ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.78265,
    latitude: -122.39293
  },
  {
    zipcode: 94102,
    title: 'RBS WORLD/PAY',
    description: '55 CYRIL MAGNIN ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78466,
    latitude: -122.40862
  },
  {
    zipcode: 94108,
    title: 'PULSE',
    description: '550 POWELL ST., San Francisco, CA 94108',
    surcharge: true,
    longitude: 37.78995,
    latitude: -122.40865
  },
  {
    zipcode: 94133,
    title: 'RBS WORLD/PAY',
    description: '555 BEACH ST, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80686,
    latitude: -122.41815
  },
  {
    zipcode: 93030,
    title: 'FISERV',
    description: '555 SOUTH A STREET, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.19656,
    latitude: -119.17867
  },
  {
    zipcode: 94105,
    title: 'SWITCH COMMERCE INC.',
    description: '557 HOWARD STREET, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.78737,
    latitude: -122.39736
  },
  {
    zipcode: 91362,
    title: 'PULSE',
    description: '5790 E. LINDERO CAN, Thousand Oaks, CA 91362',
    surcharge: true,
    longitude: 34.15436,
    latitude: -118.79603
  },
  {
    zipcode: 94121,
    title: 'FIS',
    description: '5851 GEARY BLVD, San Francisco, CA 94121',
    surcharge: true,
    longitude: 37.78015,
    latitude: -122.48179
  },
  {
    zipcode: 96025,
    title: '',
    description: '5928 DUNSMUIR AVENUE, DUNSMUIR, CA 96025',
    surcharge: false,
    longitude: 41.20738,
    latitude: -122.27349
  },
  {
    zipcode: 94121,
    title: 'SWITCH COMMERCE INC.',
    description: '6000 CALIFORNIA ST, San Francisco, CA 94121',
    surcharge: true,
    longitude: 37.7841,
    latitude: -122.48201
  },
  {
    zipcode: 94117,
    title: 'RBS WORLD/PAY',
    description: '601 DIVISADERO, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77531,
    latitude: -122.438
  },
  {
    zipcode: 95684,
    title: 'FIS',
    description: '6032 GRIZZLY FLAT RD, Somerset, CA 95684',
    surcharge: true,
    longitude: 38.64709,
    latitude: -120.68154
  },
  {
    zipcode: 94102,
    title: 'PULSE',
    description: '610 GEARY, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78668,
    latitude: -122.41421
  },
  {
    zipcode: 94121,
    title: 'PULSE',
    description: '6146 GEARY BLVD      .., San Francisco, CA 94121',
    surcharge: true,
    longitude: 37.78023,
    latitude: -122.48502
  },
  {
    zipcode: 94121,
    title: 'PULSE',
    description: '6157 GEARY BLVD, San Francisco, CA 94121',
    surcharge: true,
    longitude: 37.78,
    latitude: -122.48511
  },
  {
    zipcode: 94109,
    title: 'PULSE',
    description: '625 LARKIN STREET, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78371,
    latitude: -122.41769
  },
  {
    zipcode: 94117,
    title: 'PULSE',
    description: '667 BRODERICK ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77602,
    latitude: -122.43981
  },
  {
    zipcode: 94102,
    title: '1ST ISO PROCESSING',
    description: '669 GEARY ST, San Francisco, CA 94102',
    surcharge: false,
    longitude: 37.78648,
    latitude: -122.41434
  },
  {
    zipcode: 94109,
    title: 'SWITCH COMMERCE INC.',
    description: '678 EDDY ST, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.7833,
    latitude: -122.41831
  },
  {
    zipcode: 96025,
    title: '',
    description: '6920 DUNSMUIR AVE, DUNSMUIR, CA 96025',
    surcharge: true,
    longitude: 41.19491,
    latitude: -122.28171
  },
  {
    zipcode: 94110,
    title: 'RBS WORLD/PAY',
    description: '698 GUERRERO ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76069,
    latitude: -122.42385
  },
  {
    zipcode: 94107,
    title: 'PULSE',
    description: '699 3RD ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.77945,
    latitude: -122.39335
  },
  {
    zipcode: 94114,
    title: 'FIS',
    description: '699 CASTRO ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.75873,
    latitude: -122.4347
  },
  {
    zipcode: 94110,
    title: 'SWITCH COMMERCE INC.',
    description: '699 VALENCIA ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76212,
    latitude: -122.42152
  },
  {
    zipcode: 94112,
    title: 'PULSE',
    description: '700 NAPLES ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.717,
    latitude: -122.43422
  },
  {
    zipcode: 94118,
    title: 'RBS WORLD/PAY',
    description: '701 10TH AVE, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.77436,
    latitude: -122.46819
  },
  {
    zipcode: 94109,
    title: 'FIS',
    description: '733 POLK STREET, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78364,
    latitude: -122.41938
  },
  {
    zipcode: 94109,
    title: 'FIS',
    description: '733 POLK STREET, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78364,
    latitude: -122.41938
  },
  {
    zipcode: 91362,
    title: 'RBS WORLD/PAY',
    description: '75 RANCHO ROAD #A, Thousand Oaks, CA 91362',
    surcharge: true,
    longitude: 34.17954,
    latitude: -118.85799
  },
  {
    zipcode: 94133,
    title: 'SWITCH COMMERCE INC.',
    description: '758 SANSOME STREET, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.79669,
    latitude: -122.40177
  },
  {
    zipcode: 94132,
    title: 'PULSE',
    description: '77 CAMBON STREET, San Francisco, CA 94132',
    surcharge: true,
    longitude: 37.71799,
    latitude: -122.47437
  },
  {
    zipcode: 94102,
    title: 'PULSE',
    description: '77 MCALLISTER, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78086,
    latitude: -122.41344
  },
  {
    zipcode: 94102,
    title: 'CARDTRONICS',
    description: '776 MARKET ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78791,
    latitude: -122.4033
  },
  {
    zipcode: 94105,
    title: 'PULSE',
    description: '78 2ND ST, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.78815,
    latitude: -122.40012
  },
  {
    zipcode: 94118,
    title: 'PULSE',
    description: '782 ARGUELLO BLVD, San Francisco, CA 94118',
    surcharge: true,
    longitude: 37.77561,
    latitude: -122.45837
  },
  {
    zipcode: 94109,
    title: 'RBS WORLD/PAY',
    description: '785 OFARRELL STREE, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.79598,
    latitude: -122.4236
  },
  {
    zipcode: 94110,
    title: 'FIS',
    description: '789 VALENCIA ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.76047,
    latitude: -122.42137
  },
  {
    zipcode: 94109,
    title: 'PULSE',
    description: '798 EDDY STREET, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.783,
    latitude: -122.42066
  },
  {
    zipcode: 94102,
    title: 'PULSE',
    description: '80 POWELL STREET, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78535,
    latitude: -122.40773
  },
  {
    zipcode: 93030,
    title: 'FIS',
    description: '800 HOBSON WAY, Oxnard, CA 93030',
    surcharge: true,
    longitude: 34.19503,
    latitude: -119.18847
  },
  {
    zipcode: 94133,
    title: 'PULSE',
    description: '81 JEFFERSON STREET, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80837,
    latitude: -122.41381
  },
  {
    zipcode: 94105,
    title: 'SWITCH COMMERCE INC.',
    description: '82 FIRST STREET, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.78986,
    latitude: -122.39784
  },
  {
    zipcode: 94117,
    title: 'FIS',
    description: '846 DIVISADERO ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.77715,
    latitude: -122.43809
  },
  {
    zipcode: 94103,
    title: 'PULSE',
    description: '847 HOWARD STREET, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.7824,
    latitude: -122.40364
  },
  {
    zipcode: 94103,
    title: 'RBS WORLD/PAY',
    description: '87 6TH ST, San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.78141,
    latitude: -122.40911
  },
  {
    zipcode: 96150,
    title: 'SWITCH COMMERCE INC.',
    description: '900 SKI RUN BLVD ST, South Lake Tahoe, CA 96150',
    surcharge: true,
    longitude: 38.91531,
    latitude: -119.98853
  },
  {
    zipcode: 95726,
    title: 'PULSE',
    description: '9000 ICE HOE ROAD, Pollock Pines, CA 95726',
    surcharge: true,
    longitude: 38.74631,
    latitude: -120.58543
  },
  {
    zipcode: 94115,
    title: 'PULSE',
    description: '901 DIVISADERO STRE, San Francisco, CA 94115',
    surcharge: true,
    longitude: 37.7857,
    latitude: -122.43613
  },
  {
    zipcode: 96150,
    title: 'FISERV',
    description: '901 SKI RUN BLVD, South Lake Tahoe, CA 96150',
    surcharge: true,
    longitude: 38.94976,
    latitude: -119.95704
  },
  {
    zipcode: 94117,
    title: 'PULSE',
    description: '906 COLE ST, San Francisco, CA 94117',
    surcharge: true,
    longitude: 37.76569,
    latitude: -122.44984
  },
  {
    zipcode: 94107,
    title: 'SWITCH COMMERCE INC.',
    description: '917 FOLSOM ST, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.77978,
    latitude: -122.40385
  },
  {
    zipcode: 94103,
    title: 'PULSE',
    description: '934 BRANNAN ST., San Francisco, CA 94103',
    surcharge: true,
    longitude: 37.7712,
    latitude: -122.40568
  },
  {
    zipcode: 93004,
    title: 'CARDTRONICS',
    description: '9372 TELEPHONE RD, Ventura, CA 93004',
    surcharge: true,
    longitude: 34.27163,
    latitude: -119.17128
  },
  {
    zipcode: 94107,
    title: 'SWITCH COMMERCE INC.',
    description: '947 FOLSOM STREET, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.77886,
    latitude: -122.40501
  },
  {
    zipcode: 94111,
    title: 'MONEYPASS',
    description: '950 BATTERY ST., San Francisco, CA 94111',
    surcharge: false,
    longitude: 37.79858,
    latitude: -122.40095
  },
  {
    zipcode: 94122,
    title: 'FIS',
    description: '951 IRVING STREET, San Francisco, CA 94122',
    surcharge: true,
    longitude: 37.76388,
    latitude: -122.46766
  },
  {
    zipcode: 94114,
    title: 'FIS',
    description: '98 SANCHEZ ST, San Francisco, CA 94114',
    surcharge: true,
    longitude: 37.76862,
    latitude: -122.43138
  },
  {
    zipcode: 94133,
    title: 'FIS',
    description: '99 JEFFERSON ST, San Francisco, CA 94133',
    surcharge: true,
    longitude: 37.80837,
    latitude: -122.41381
  },
  {
    zipcode: 94109,
    title: 'PULSE',
    description: '990 POLK STREET, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78583,
    latitude: -122.41963
  },
  {
    zipcode: 94109,
    title: 'SWITCH COMMERCE INC.',
    description: '999 POLK STREET, San Francisco, CA 94109',
    surcharge: true,
    longitude: 37.78586,
    latitude: -122.41982
  },
  {
    zipcode: 94105,
    title: 'FIS',
    description: 'PIER 28 1/2, San Francisco, CA 94105',
    surcharge: true,
    longitude: 37.78938,
    latitude: -122.39638
  },
  {
    zipcode: 94107,
    title: 'PULSE',
    description: 'PIER 40 THE EMBARCA, San Francisco, CA 94107',
    surcharge: true,
    longitude: 37.771,
    latitude: -122.39469
  },
  {
    zipcode: 94133,
    title: '',
    description: 'PIER 43, SAN FRANCISCO, CA 94133',
    surcharge: true,
    longitude: 37.80031,
    latitude: -122.4104
  },
  {
    zipcode: 94158,
    title: 'FIS',
    description: 'PIER 50, San Francisco, CA 94158',
    surcharge: true,
    longitude: 37.74575,
    latitude: -122.35617
  },
  {
    zipcode: 94111,
    title: 'PULSE',
    description: 'THE EMBARCADERO, San Francisco, CA 94111',
    surcharge: true,
    longitude: 37.79557,
    latitude: -122.40034
  }
];