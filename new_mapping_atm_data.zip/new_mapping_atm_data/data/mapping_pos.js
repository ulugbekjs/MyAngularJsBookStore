var mapping_pos = [
  {
    zipcode: 91320,
    title: 'ALBERTSONS #6391',
    description: '541 S Reino Rd, Newbury Park, CA 91320',
    surcharge: false,
    longitude: 34.16773,
    latitude: -118.95642
  },
  {
    zipcode: 93065,
    title: 'ALBERTSONS #6393',
    description: '1268 Madera Rd, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.26281,
    latitude: -118.79618
  },
  {
    zipcode: 94122,
    title: 'Andronico\'s Community Market #3',
    description: '1200 Irving St, San Francisco, CA 94122',
    surcharge: false,
    longitude: 37.76393,
    latitude: -122.4706
  },
  {
    zipcode: 95682,
    title: 'BEL AIR  #515',
    description: '3510 Palmer Dr, Cameron Park, CA 95682',
    surcharge: false,
    longitude: 38.66116,
    latitude: -120.96694
  },
  {
    zipcode: 93036,
    title: 'Circle K',
    description: '2323 N Oxnard Blvd, Oxnard, CA 93036',
    surcharge: false,
    longitude: 34.21957,
    latitude: -119.17713
  },
  {
    zipcode: 93065,
    title: 'Circle K #2655640',
    description: '1706 Erringer Rd, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.26847,
    latitude: -118.76127
  },
  {
    zipcode: 93023,
    title: 'Circle K #2721045',
    description: '11408 N Ventura Ave, Ojai, CA 93023',
    surcharge: false,
    longitude: 34.42271,
    latitude: -119.28965
  },
  {
    zipcode: 93036,
    title: 'Circle K #2725209',
    description: '1954 N Ventura Rd, Oxnard, CA 93036',
    surcharge: false,
    longitude: 34.22038,
    latitude: -119.19457
  },
  {
    zipcode: 93030,
    title: 'Circle K #2725210',
    description: '105 S Rose Ave, Oxnard, CA 93030',
    surcharge: false,
    longitude: 34.20255,
    latitude: -119.15973
  },
  {
    zipcode: 93003,
    title: 'Circle K #2725211',
    description: '3506 E Main St, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.26444,
    latitude: -119.24472
  },
  {
    zipcode: 93004,
    title: 'Circle K #2725212',
    description: '11051 Citrus Dr, Ventura, CA 93004',
    surcharge: false,
    longitude: 34.29261,
    latitude: -119.15733
  },
  {
    zipcode: 93001,
    title: 'Circle K #2725220',
    description: '1007 E Main St, Ventura, CA 93001',
    surcharge: false,
    longitude: 34.28093,
    latitude: -119.28458
  },
  {
    zipcode: 93004,
    title: 'Circle K #2725228',
    description: '1001 Petit Ave, Ventura, CA 93004',
    surcharge: false,
    longitude: 34.27211,
    latitude: -119.17056
  },
  {
    zipcode: 93060,
    title: 'Circle K #2725238',
    description: '765 W Harvard Blvd, Santa Paula, CA 93060',
    surcharge: false,
    longitude: 34.34112,
    latitude: -119.08376
  },
  {
    zipcode: 93036,
    title: 'Circle K #2729460',
    description: '2200 N Rose Ave, Oxnard, CA 93036',
    surcharge: false,
    longitude: 34.22337,
    latitude: -119.15853
  },
  {
    zipcode: 93030,
    title: 'Circle K #2729483',
    description: '490 S Victoria Ave, Oxnard, CA 93030',
    surcharge: false,
    longitude: 34.20838,
    latitude: -119.22084
  },
  {
    zipcode: 94114,
    title: 'CVS #10036',
    description: '2280 Market St, San Francisco, CA 94114',
    surcharge: false,
    longitude: 37.7655,
    latitude: -122.43174
  },
  {
    zipcode: 94109,
    title: 'CVS #10080',
    description: '1059 Hyde St, San Francisco, CA 94109',
    surcharge: false,
    longitude: 37.79091,
    latitude: -122.41747
  },
  {
    zipcode: 94117,
    title: 'CVS #10188',
    description: '499 Haight St, San Francisco, CA 94117',
    surcharge: false,
    longitude: 37.77216,
    latitude: -122.42926
  },
  {
    zipcode: 94109,
    title: 'CVS #10189',
    description: '1285 Sutter St, San Francisco, CA 94109',
    surcharge: false,
    longitude: 37.78748,
    latitude: -122.4215
  },
  {
    zipcode: 94133,
    title: 'CVS #10391',
    description: '1 Jefferson St, San Francisco, CA 94133',
    surcharge: false,
    longitude: 37.80837,
    latitude: -122.41381
  },
  {
    zipcode: 94103,
    title: 'CVS #10622',
    description: '955 Market St, San Francisco, CA 94103',
    surcharge: false,
    longitude: 37.78361,
    latitude: -122.40831
  },
  {
    zipcode: 94103,
    title: 'CVS #4770',
    description: '1101 Market St, San Francisco, CA 94103',
    surcharge: false,
    longitude: 37.77968,
    latitude: -122.41329
  },
  {
    zipcode: 94105,
    title: 'CVS PHARMACY #10164',
    description: '601 Mission St, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.78786,
    latitude: -122.39983
  },
  {
    zipcode: 94118,
    title: 'CVS Pharmacy #10330',
    description: '3600 Geary Blvd, San Francisco, CA 94118',
    surcharge: false,
    longitude: 37.78145,
    latitude: -122.45801
  },
  {
    zipcode: 94103,
    title: 'CVS Pharmacy #2852',
    description: '731 Market St, San Francisco, CA 94103',
    surcharge: false,
    longitude: 37.78695,
    latitude: -122.40406
  },
  {
    zipcode: 95682,
    title: 'CVS Pharmacy #3009',
    description: '3500 Palmer Dr, Cameron Park, CA 95682',
    surcharge: false,
    longitude: 38.66116,
    latitude: -120.96694
  },
  {
    zipcode: 91320,
    title: 'CVS Pharmacy #3069',
    description: '451 S Reino Rd, Newbury Park, CA 91320',
    surcharge: false,
    longitude: 34.16813,
    latitude: -118.95632
  },
  {
    zipcode: 95762,
    title: 'CVS Pharmacy #3909',
    description: '4400 Latrobe Rd, El Dorado Hills, CA 95762',
    surcharge: false,
    longitude: 38.62802,
    latitude: -121.03838
  },
  {
    zipcode: 91360,
    title: 'CVS Pharmacy #3934',
    description: '60 N Moorpark Rd, Thousand Oaks, CA 91360',
    surcharge: false,
    longitude: 34.17844,
    latitude: -118.87627
  },
  {
    zipcode: 94121,
    title: 'CVS Pharmacy #4675',
    description: '377 32nd Ave, San Francisco, CA 94121',
    surcharge: false,
    longitude: 37.78205,
    latitude: -122.49249
  },
  {
    zipcode: 95682,
    title: 'CVS Pharmacy #6793',
    description: '3020 Green Valley Rd, Cameron Park, CA 95682',
    surcharge: false,
    longitude: 38.69745,
    latitude: -121.00296
  },
  {
    zipcode: 94112,
    title: 'CVS Pharmacy #7596',
    description: '1760 Ocean Ave, San Francisco, CA 94112',
    surcharge: false,
    longitude: 37.72482,
    latitude: -122.46005
  },
  {
    zipcode: 94104,
    title: 'CVS Pharmacy #7657',
    description: '351 California St, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.79304,
    latitude: -122.40054
  },
  {
    zipcode: 94109,
    title: 'CVS Pharmacy #7955',
    description: '2025 Van Ness Ave, San Francisco, CA 94109',
    surcharge: false,
    longitude: 37.7945,
    latitude: -122.42326
  },
  {
    zipcode: 93030,
    title: 'CVS Pharmacy #8520',
    description: '1205 S Oxnard Blvd, Oxnard, CA 93030',
    surcharge: false,
    longitude: 34.18771,
    latitude: -119.17499
  },
  {
    zipcode: 91320,
    title: 'CVS Pharmacy #8820',
    description: '123 N Reino Rd, Newbury Park, CA 91320',
    surcharge: false,
    longitude: 34.18243,
    latitude: -118.95342
  },
  {
    zipcode: 93012,
    title: 'CVS Pharmacy #9143',
    description: '5800 SANTA ROSA RD, CAMARILLO, CA 93012',
    surcharge: false,
    longitude: 34.22531,
    latitude: -118.98978
  },
  {
    zipcode: 93060,
    title: 'CVS Pharmacy #9151',
    description: '600 W Main St, Santa Paula, CA 93060',
    surcharge: false,
    longitude: 34.34447,
    latitude: -119.08359
  },
  {
    zipcode: 95667,
    title: 'CVS Pharmacy #9184',
    description: '3964-A Missouri Flat Rd, Placerville, CA 95667',
    surcharge: false,
    longitude: 38.71114,
    latitude: -120.84288
  },
  {
    zipcode: 91320,
    title: 'CVS Pharmacy #9221',
    description: '2120 Newbury Rd, Newbury Park, CA 91320',
    surcharge: false,
    longitude: 34.18291,
    latitude: -118.9249
  },
  {
    zipcode: 93003,
    title: 'CVS Pharmacy #9236',
    description: '50 N Ashwood Ave, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.27712,
    latitude: -119.23964
  },
  {
    zipcode: 91362,
    title: 'CVS Pharmacy #9241',
    description: '1822 E Avenida de Los Arboles, Thousand Oaks, CA 91362',
    surcharge: false,
    longitude: 34.21124,
    latitude: -118.84478
  },
  {
    zipcode: 93041,
    title: 'CVS Pharmacy #9286',
    description: '581 W Channel Islands Blvd, Port Hueneme, CA 93041',
    surcharge: false,
    longitude: 34.17712,
    latitude: -119.21007
  },
  {
    zipcode: 96150,
    title: 'CVS Pharmacy #9376',
    description: '3471 Lake Tahoe Blvd, South Lake Tahoe, CA 96150',
    surcharge: false,
    longitude: 38.946,
    latitude: -119.96523
  },
  {
    zipcode: 95726,
    title: 'CVS Pharmacy #9490',
    description: '6450 Pony Express Trl, Pollock Pines, CA 95726',
    surcharge: false,
    longitude: 38.76275,
    latitude: -120.58017
  },
  {
    zipcode: 93021,
    title: 'CVS Pharmacy #9530',
    description: '155 W Los Angeles Ave, Moorpark, CA 93021',
    surcharge: false,
    longitude: 34.28597,
    latitude: -118.81358
  },
  {
    zipcode: 93003,
    title: 'CVS Pharmacy #9556',
    description: '1740 S Victoria Ave, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.25826,
    latitude: -119.21084
  },
  {
    zipcode: 93065,
    title: 'CVS Pharmacy #9631',
    description: '2825 Cochran St, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.27908,
    latitude: -118.74142
  },
  {
    zipcode: 91360,
    title: 'CVS Pharmacy #9633',
    description: '1382 N Moorpark Rd, Thousand Oaks, CA 91360',
    surcharge: false,
    longitude: 34.19534,
    latitude: -118.87159
  },
  {
    zipcode: 93003,
    title: 'CVS Pharmacy #9683',
    description: '5900 Telegraph Rd, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.27791,
    latitude: -119.2146
  },
  {
    zipcode: 93030,
    title: 'CVS Pharmacy #9695',
    description: '551 S Ventura Rd, Oxnard, CA 93030',
    surcharge: false,
    longitude: 34.19711,
    latitude: -119.19475
  },
  {
    zipcode: 96150,
    title: 'CVS Pharmacy #9713',
    description: '1043 Emerald Bay Rd, South Lake Tahoe, CA 96150',
    surcharge: false,
    longitude: 38.91316,
    latitude: -120.00431
  },
  {
    zipcode: 91361,
    title: 'CVS Pharmacy #9715',
    description: '2791 Agoura Rd, Thousand Oaks, CA 91361',
    surcharge: false,
    longitude: 34.15083,
    latitude: -118.82597
  },
  {
    zipcode: 93012,
    title: 'CVS Pharmacy #9719',
    description: '5259 Mission Oaks Blvd, Camarillo, CA 93012',
    surcharge: false,
    longitude: 34.22847,
    latitude: -118.99792
  },
  {
    zipcode: 93010,
    title: 'CVS Pharmacy #9764',
    description: '351 Carmen Dr, Camarillo, CA 93010',
    surcharge: false,
    longitude: 34.22068,
    latitude: -119.05076
  },
  {
    zipcode: 93063,
    title: 'CVS Pharmacy #9790',
    description: '4440 Alamo St, Simi Valley, CA 93063',
    surcharge: false,
    longitude: 34.28618,
    latitude: -118.708
  },
  {
    zipcode: 93010,
    title: 'CVS Pharmacy #9844',
    description: '760 Arneill Rd, Camarillo, CA 93010',
    surcharge: false,
    longitude: 34.22495,
    latitude: -119.03897
  },
  {
    zipcode: 93063,
    title: 'CVS Pharmacy #9859',
    description: '3935 Cochran St, Simi Valley, CA 93063',
    surcharge: false,
    longitude: 34.27911,
    latitude: -118.71882
  },
  {
    zipcode: 93004,
    title: 'CVS Pharmacy #9969',
    description: '7850 Telegraph Rd, Ventura, CA 93004',
    surcharge: false,
    longitude: 34.2814,
    latitude: -119.19013
  },
  {
    zipcode: 93065,
    title: 'CVS/pharmacy #10026',
    description: '501-591 Country Dr, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.26703,
    latitude: -118.77491
  },
  {
    zipcode: 94105,
    title: 'CVS/pharmacy #10035',
    description: '581 Market St, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.78947,
    latitude: -122.40088
  },
  {
    zipcode: 94127,
    title: 'CVS/pharmacy #1983',
    description: '701 Portola Dr, San Francisco, CA 94127',
    surcharge: false,
    longitude: 37.74426,
    latitude: -122.4536
  },
  {
    zipcode: 95667,
    title: 'DOLLAR TREE #1244',
    description: '1480 Broadway, Placerville, CA 95667',
    surcharge: false,
    longitude: 38.73203,
    latitude: -120.77964
  },
  {
    zipcode: 96097,
    title: 'DOLLAR TREE #1251',
    description: '1828 Fort Jones Rd, Yreka, CA 96097',
    surcharge: false,
    longitude: 41.69966,
    latitude: -122.64699
  },
  {
    zipcode: 93030,
    title: 'Dollar Tree #2237',
    description: '838 N Ventura Rd, Oxnard, CA 93030',
    surcharge: false,
    longitude: 34.21117,
    latitude: -119.19454
  },
  {
    zipcode: 93065,
    title: 'Dollar Tree #2585',
    description: '2970 Cochran St, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.2789,
    latitude: -118.73825
  },
  {
    zipcode: 93060,
    title: 'Dollar Tree #2963',
    description: '588 W Main St, Santa Paula, CA 93060',
    surcharge: false,
    longitude: 34.3444,
    latitude: -119.08362
  },
  {
    zipcode: 93015,
    title: 'Dollar Tree #3753',
    description: '745 Ventura St, Fillmore, CA 93015',
    surcharge: false,
    longitude: 34.39624,
    latitude: -118.91755
  },
  {
    zipcode: 93041,
    title: 'Dollar Tree #3874',
    description: '729 W Channel Islands Blvd, Port Hueneme, CA 93041',
    surcharge: false,
    longitude: 34.17579,
    latitude: -119.22118
  },
  {
    zipcode: 91360,
    title: 'Dollar Tree #3999',
    description: '1760 N Moorpark Rd, Thousand Oaks, CA 91360',
    surcharge: false,
    longitude: 34.20132,
    latitude: -118.86819
  },
  {
    zipcode: 91320,
    title: 'Dollar Tree #4223',
    description: '737 N Wendy Dr, Newbury Park, CA 91320',
    surcharge: false,
    longitude: 34.18786,
    latitude: -118.94219
  },
  {
    zipcode: 95682,
    title: 'Dollar Tree #4242',
    description: '3386 Coach Ln, Cameron Park, CA 95682',
    surcharge: false,
    longitude: 38.65783,
    latitude: -120.9697
  },
  {
    zipcode: 93003,
    title: 'Dollar Tree #4315',
    description: '4738 Telephone Rd, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.26316,
    latitude: -119.22706
  },
  {
    zipcode: 93033,
    title: 'Dollar Tree #4687',
    description: '150 W Laurel St, Oxnard, CA 93033',
    surcharge: false,
    longitude: 34.17725,
    latitude: -119.17816
  },
  {
    zipcode: 93021,
    title: 'Dollar Tree #5464',
    description: '543-B W Los Angeles Ave, Moorpark, CA 93021',
    surcharge: false,
    longitude: 34.28598,
    latitude: -118.81428
  },
  {
    zipcode: 93010,
    title: 'Dollar Tree #5599',
    description: '2291 Pickwick Dr, Camarillo, CA 93010',
    surcharge: false,
    longitude: 34.22229,
    latitude: -119.0428
  },
  {
    zipcode: 93033,
    title: 'El Super #46',
    description: '2800 Saviers Rd, Oxnard, CA 93033',
    surcharge: false,
    longitude: 34.17405,
    latitude: -119.17754
  },
  {
    zipcode: 93036,
    title: 'Food 4 Less #335',
    description: '250 W Esplanade Dr, Oxnard, CA 93036',
    surcharge: false,
    longitude: 34.23242,
    latitude: -119.17658
  },
  {
    zipcode: 94124,
    title: 'FOODS CO #351',
    description: '345 Williams Ave, San Francisco, CA 94124',
    surcharge: false,
    longitude: 37.72994,
    latitude: -122.39806
  },
  {
    zipcode: 94103,
    title: 'Foods Co #357',
    description: '1800 Folsom St, San Francisco, CA 94103',
    surcharge: false,
    longitude: 37.76852,
    latitude: -122.4157
  },
  {
    zipcode: 91361,
    title: 'GELSON\'S MARKET #8',
    description: '2734 Townsgate Rd, Westlake Village, CA 91361',
    surcharge: false,
    longitude: 34.15402,
    latitude: -118.82588
  },
  {
    zipcode: 95667,
    title: 'HOLIDAY FOODS #57',
    description: '4653 Mount Aukum Rd, Placerville, CA 95667',
    surcharge: false,
    longitude: 38.68185,
    latitude: -120.66307
  },
  {
    zipcode: 95614,
    title: 'Holiday Foods #62',
    description: '5030 Ellinghouse Dr, Cool, CA 95614',
    surcharge: false,
    longitude: 38.8861,
    latitude: -121.01501
  },
  {
    zipcode: 93063,
    title: 'Jons Marketplace #17',
    description: '3963 Cochran St, Simi Valley, CA 93063',
    surcharge: false,
    longitude: 34.27911,
    latitude: -118.71882
  },
  {
    zipcode: 93010,
    title: 'Kmart #7165',
    description: '940 Arneill Rd, Camarillo, CA 93010',
    surcharge: false,
    longitude: 34.22644,
    latitude: -119.03898
  },
  {
    zipcode: 95667,
    title: 'Kmart #7471',
    description: '3968 Missouri Flat Rd Ste A, Placerville, CA 95667',
    surcharge: false,
    longitude: 38.71281,
    latitude: -120.84166
  },
  {
    zipcode: 93060,
    title: 'Kmart #7639',
    description: '895 Faulkner Rd, Santa Paula, CA 93060',
    surcharge: false,
    longitude: 34.33544,
    latitude: -119.0859
  },
  {
    zipcode: 96150,
    title: 'Kmart #9153',
    description: '1056 Emerald Bay Rd, South Lake Tahoe, CA 96150',
    surcharge: false,
    longitude: 38.91259,
    latitude: -120.00422
  },
  {
    zipcode: 94132,
    title: 'Lucky #755',
    description: '1515 Sloat Blvd, San Francisco, CA 94132',
    surcharge: false,
    longitude: 37.73397,
    latitude: -122.48847
  },
  {
    zipcode: 94117,
    title: 'Lucky #756',
    description: '1750 Fulton St, San Francisco, CA 94117',
    surcharge: false,
    longitude: 37.77604,
    latitude: -122.44531
  },
  {
    zipcode: 93033,
    title: 'MY GOODS MARKET #5696',
    description: '1445 W Channel Islands Blvd, Oxnard, CA 93033',
    surcharge: false,
    longitude: 34.17575,
    latitude: -119.19421
  },
  {
    zipcode: 95682,
    title: 'MY GOODS MARKET #7237',
    description: '4047 S Shingle Rd, Shingle Springs, CA 95682',
    surcharge: false,
    longitude: 38.62656,
    latitude: -120.94498
  },
  {
    zipcode: 95682,
    title: 'MY GOODS MARKET #7966',
    description: '2650 Cameron Park Dr, Cameron Park, CA 95682',
    surcharge: false,
    longitude: 38.69827,
    latitude: -120.99652
  },
  {
    zipcode: 95762,
    title: 'Nugget Market #9',
    description: '4500 Post St, El Dorado Hills, CA 95762',
    surcharge: false,
    longitude: 38.65134,
    latitude: -121.06888
  },
  {
    zipcode: 95619,
    title: 'Quik Stop Market #9161',
    description: '615 Pleasant Valley Rd, Diamond Springs, CA 95619',
    surcharge: false,
    longitude: 38.69504,
    latitude: -120.81005
  },
  {
    zipcode: 96097,
    title: 'RALEY\'S  #247',
    description: '1842 Fort Jones Rd, Yreka, CA 96097',
    surcharge: false,
    longitude: 41.69966,
    latitude: -122.64699
  },
  {
    zipcode: 96150,
    title: 'RALEY\'S #119',
    description: '4010 Hwy 50, South Lake Tahoe, CA 96150',
    surcharge: false,
    longitude: 38.91531,
    latitude: -119.98853
  },
  {
    zipcode: 96150,
    title: 'RALEY\'S #127',
    description: '1040 Emerald Bay Rd, South Lake Tahoe, CA 96150',
    surcharge: false,
    longitude: 38.91259,
    latitude: -120.00422
  },
  {
    zipcode: 95667,
    title: 'RALEY\'S #422',
    description: '166 Placerville Dr, Placerville, CA 95667',
    surcharge: false,
    longitude: 38.72666,
    latitude: -120.83668
  },
  {
    zipcode: 95762,
    title: 'RALEY\'S #424',
    description: '3935 Park Dr, El Dorado Hills, CA 95762',
    surcharge: false,
    longitude: 38.65561,
    latitude: -121.07005
  },
  {
    zipcode: 91360,
    title: 'RALPHS  #620',
    description: '1500 N Moorpark Rd, Thousand Oaks, CA 91360',
    surcharge: false,
    longitude: 34.19849,
    latitude: -118.86906
  },
  {
    zipcode: 93021,
    title: 'RALPHS  #723',
    description: '101 W Los Angeles Ave, Moorpark, CA 93021',
    surcharge: false,
    longitude: 34.28596,
    latitude: -118.81335
  },
  {
    zipcode: 91320,
    title: 'RALPHS  #729',
    description: '583 N Ventu Park Rd, Newbury Park, CA 91320',
    surcharge: false,
    longitude: 34.1882,
    latitude: -118.91124
  },
  {
    zipcode: 93033,
    title: 'RALPHS #190',
    description: '3443 Saviers Rd, Oxnard, CA 93033',
    surcharge: false,
    longitude: 34.16812,
    latitude: -119.1777
  },
  {
    zipcode: 93003,
    title: 'RALPHS #664',
    description: '1776 S Victoria Ave, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.25826,
    latitude: -119.21084
  },
  {
    zipcode: 93010,
    title: 'Ralphs Fresh Fare #741',
    description: '674 Las Posas Rd, Camarillo, CA 93010',
    surcharge: false,
    longitude: 34.22276,
    latitude: -119.06966
  },
  {
    zipcode: 91360,
    title: 'Ralphs Fresh Fare #9',
    description: '3963 Thousand Oaks, Thousand Oaks, CA 91360',
    surcharge: false,
    longitude: 34.16127,
    latitude: -118.82342
  },
  {
    zipcode: 93065,
    title: 'RALPHS GROCERY COMPANY #52',
    description: '2726 E Los Angeles Ave, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.27158,
    latitude: -118.74333
  },
  {
    zipcode: 93041,
    title: 'RALPHS GROCERY COMPANY #62',
    description: '615 W Channel Islands Blvd, Port Hueneme, CA 93041',
    surcharge: false,
    longitude: 34.17712,
    latitude: -119.21007
  },
  {
    zipcode: 91360,
    title: 'RITE AID #5559',
    description: '387 AVE DE LOS ARBOLES, THOUSAND OAKS, CA 91360',
    surcharge: false,
    longitude: 34.2012,
    latitude: -118.87653
  },
  {
    zipcode: 91362,
    title: 'RITE AID #5560',
    description: '3825 E Thousand Oaks Blvd, THOUSAND OAKS, CA 91362',
    surcharge: false,
    longitude: 34.16249,
    latitude: -118.82569
  },
  {
    zipcode: 93001,
    title: 'RITE AID #5771',
    description: '131 W Main St, Ventura, CA 93001',
    surcharge: false,
    longitude: 34.28139,
    latitude: -119.30303
  },
  {
    zipcode: 93003,
    title: 'RITE AID #5772',
    description: '2738 E Thompson Blvd, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.27227,
    latitude: -119.26022
  },
  {
    zipcode: 93010,
    title: 'RITE AID #5775',
    description: '2550 Las Posas Rd, Camarillo, CA 93010',
    surcharge: false,
    longitude: 34.23691,
    latitude: -119.03693
  },
  {
    zipcode: 93015,
    title: 'RITE AID #5777',
    description: '600 W Ventura St, Fillmore, CA 93015',
    surcharge: false,
    longitude: 34.39625,
    latitude: -118.91684
  },
  {
    zipcode: 93021,
    title: 'RITE AID #5778',
    description: '3941 Spring Rd, Moorpark, CA 93021',
    surcharge: false,
    longitude: 34.26464,
    latitude: -118.86564
  },
  {
    zipcode: 93023,
    title: 'RITE AID #5779',
    description: '11496 N Ventura Ave, Ojai, CA 93023',
    surcharge: false,
    longitude: 34.42569,
    latitude: -119.28892
  },
  {
    zipcode: 93030,
    title: 'RITE AID #5780',
    description: '720 N Ventura Rd, Oxnard, CA 93030',
    surcharge: false,
    longitude: 34.21025,
    latitude: -119.19457
  },
  {
    zipcode: 93033,
    title: 'RITE AID #5781',
    description: '2661 Saviers Rd, Oxnard, CA 93033',
    surcharge: false,
    longitude: 34.17527,
    latitude: -119.17762
  },
  {
    zipcode: 93041,
    title: 'RITE AID #5782',
    description: '2480 Victoria Ave, Port Hueneme, CA 93041',
    surcharge: false,
    longitude: 34.17668,
    latitude: -119.22141
  },
  {
    zipcode: 93060,
    title: 'RITE AID #5783',
    description: '221 E Harvard Blvd, Santa Paula, CA 93060',
    surcharge: false,
    longitude: 34.3471,
    latitude: -119.06954
  },
  {
    zipcode: 93063,
    title: 'RITE AID #5786',
    description: '5845 E Los Angeles Ave, Simi Valley, CA 93063',
    surcharge: false,
    longitude: 34.27182,
    latitude: -118.67775
  },
  {
    zipcode: 93065,
    title: 'RITE AID #5787',
    description: '1159 E Los Angeles Ave, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.2718,
    latitude: -118.77815
  },
  {
    zipcode: 95667,
    title: 'RITE AID #6057',
    description: '1220 Broadway, Placerville, CA 95667',
    surcharge: false,
    longitude: 38.73093,
    latitude: -120.78615
  },
  {
    zipcode: 95667,
    title: 'RITE AID #6058',
    description: '31 Fair Ln, Placerville, CA 95667',
    surcharge: false,
    longitude: 38.72247,
    latitude: -120.83144
  },
  {
    zipcode: 96067,
    title: 'RITE AID #6103',
    description: '310 W Lake St, Mount Shasta, CA 96067',
    surcharge: false,
    longitude: 41.31293,
    latitude: -122.31284
  },
  {
    zipcode: 96097,
    title: 'RITE AID #6104',
    description: '807 S Main St, Yreka, CA 96097',
    surcharge: false,
    longitude: 41.72526,
    latitude: -122.63854
  },
  {
    zipcode: 96150,
    title: 'RITE AID #6107',
    description: '1020 Al Tahoe Blvd, South Lake Tahoe, CA 96150',
    surcharge: false,
    longitude: 38.93431,
    latitude: -119.9758
  },
  {
    zipcode: 95682,
    title: 'Rite Aid #6526',
    description: '3101 Green Valley Rd, Cameron Park, CA 95682',
    surcharge: false,
    longitude: 38.69888,
    latitude: -120.99699
  },
  {
    zipcode: 94133,
    title: 'SAFEWAY  #1206',
    description: '350 Bay St, San Francisco, CA 94133',
    surcharge: false,
    longitude: 37.8058,
    latitude: -122.4128
  },
  {
    zipcode: 94103,
    title: 'SAFEWAY  #1490',
    description: '2300 16th St, San Francisco, CA 94103',
    surcharge: false,
    longitude: 37.76577,
    latitude: -122.4092
  },
  {
    zipcode: 94111,
    title: 'SAFEWAY  #4601',
    description: '145 Jackson St, San Francisco, CA 94111',
    surcharge: false,
    longitude: 37.79687,
    latitude: -122.3992
  },
  {
    zipcode: 94131,
    title: 'SAFEWAY  #667',
    description: '5290 Diamond Heights Blvd, San Francisco, CA 94131',
    surcharge: false,
    longitude: 37.74456,
    latitude: -122.43962
  },
  {
    zipcode: 94110,
    title: 'SAFEWAY  #739',
    description: '3350 Mission St, San Francisco, CA 94110',
    surcharge: false,
    longitude: 37.74348,
    latitude: -122.42136
  },
  {
    zipcode: 94121,
    title: 'SAFEWAY  #785',
    description: '850 La Playa St, San Francisco, CA 94121',
    surcharge: false,
    longitude: 37.77231,
    latitude: -122.50987
  },
  {
    zipcode: 94116,
    title: 'SAFEWAY  #909',
    description: '730 Taraval St, San Francisco, CA 94116',
    surcharge: false,
    longitude: 37.74321,
    latitude: -122.47388
  },
  {
    zipcode: 94112,
    title: 'SAFEWAY  #964',
    description: '4950 Mission St, San Francisco, CA 94112',
    surcharge: false,
    longitude: 37.71885,
    latitude: -122.43936
  },
  {
    zipcode: 94122,
    title: 'SAFEWAY  #985',
    description: '2350 Noriega St, San Francisco, CA 94122',
    surcharge: false,
    longitude: 37.75378,
    latitude: -122.4888
  },
  {
    zipcode: 94115,
    title: 'SAFEWAY  #995',
    description: '1335 Webster St, San Francisco, CA 94115',
    surcharge: false,
    longitude: 37.78301,
    latitude: -122.43106
  },
  {
    zipcode: 94114,
    title: 'SAFEWAY #1507',
    description: '2020 Market St, San Francisco, CA 94114',
    surcharge: false,
    longitude: 37.76894,
    latitude: -122.42738
  },
  {
    zipcode: 95682,
    title: 'SAFEWAY #1618',
    description: '3380 Coach Ln, Cameron Park, CA 95682',
    surcharge: false,
    longitude: 38.65783,
    latitude: -120.9697
  },
  {
    zipcode: 94123,
    title: 'SAFEWAY #1711',
    description: '15 Marina Blvd, San Francisco, CA 94123',
    surcharge: false,
    longitude: 37.80509,
    latitude: -122.43233
  },
  {
    zipcode: 95667,
    title: 'SAFEWAY #1724',
    description: '3955 MISSION FLAT ROAD, PLACERVILLE, CA 95667',
    surcharge: false,
    longitude: 38.72302,
    latitude: -120.79863
  },
  {
    zipcode: 96150,
    title: 'SAFEWAY #1824',
    description: '1020 Johnson Blvd, South Lake Tahoe, CA 96150',
    surcharge: false,
    longitude: 38.94497,
    latitude: -119.96733
  },
  {
    zipcode: 95726,
    title: 'SAFEWAY #1825',
    description: '6498 Pony Express Trl, Pollock Pines, CA 95726',
    surcharge: false,
    longitude: 38.76234,
    latitude: -120.57692
  },
  {
    zipcode: 94107,
    title: 'SAFEWAY #2606',
    description: '298 King St, San Francisco, CA 94107',
    surcharge: false,
    longitude: 37.77745,
    latitude: -122.39297
  },
  {
    zipcode: 94118,
    title: 'Safeway #2646',
    description: '735 7th Ave, San Francisco, CA 94118',
    surcharge: false,
    longitude: 37.77408,
    latitude: -122.46494
  },
  {
    zipcode: 95762,
    title: 'Safeway #2683',
    description: '2207 Francisco Dr, El Dorado Hills, CA 95762',
    surcharge: false,
    longitude: 38.7162,
    latitude: -121.08275
  },
  {
    zipcode: 94127,
    title: 'SAFEWAY #759',
    description: '625 Monterey Blvd, San Francisco, CA 94127',
    surcharge: false,
    longitude: 37.73149,
    latitude: -122.4504
  },
  {
    zipcode: 93036,
    title: 'Sam\'s Club #6455',
    description: '2401 N Rose Ave, Oxnard, CA 93036',
    surcharge: false,
    longitude: 34.22402,
    latitude: -119.15876
  },
  {
    zipcode: 95667,
    title: 'Save Mart #614',
    description: '1270 Broadway, Placerville, CA 95667',
    surcharge: false,
    longitude: 38.73093,
    latitude: -120.78615
  },
  {
    zipcode: 95667,
    title: 'Save Mart #615',
    description: '3966 Missouri Flat Rd, Placerville, CA 95667',
    surcharge: false,
    longitude: 38.71278,
    latitude: -120.84163
  },
  {
    zipcode: 93015,
    title: 'SUPER A FOODS, INC #12',
    description: '725 W Ventura St, Fillmore, CA 93015',
    surcharge: false,
    longitude: 34.39624,
    latitude: -118.91755
  },
  {
    zipcode: 93033,
    title: 'Superior Grocers #138',
    description: '2401 Saviers Rd, Oxnard, CA 93033',
    surcharge: false,
    longitude: 34.17732,
    latitude: -119.17761
  },
  {
    zipcode: 94104,
    title: 'Target #3201',
    description: '225 Bush St, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.79092,
    latitude: -122.40199
  },
  {
    zipcode: 94112,
    title: 'Target #3203',
    description: '1830 Ocean Ave, San Francisco, CA 94112',
    surcharge: false,
    longitude: 37.72521,
    latitude: -122.46164
  },
  {
    zipcode: 94118,
    title: 'Target #T-2768',
    description: '2675 Geary Blvd, San Francisco, CA 94118',
    surcharge: false,
    longitude: 37.78225,
    latitude: -122.447
  },
  {
    zipcode: 91362,
    title: 'TARGET STORE #2810',
    description: '30740 Russell Ranch Rd, Westlake Village, CA 91362',
    surcharge: false,
    longitude: 34.15621,
    latitude: -118.8045
  },
  {
    zipcode: 93065,
    title: 'Target Store #T-0246',
    description: '2907 Cochran St, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.27908,
    latitude: -118.73792
  },
  {
    zipcode: 93003,
    title: 'Target Store #T-0298',
    description: '4200 E Main St, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.26334,
    latitude: -119.23937
  },
  {
    zipcode: 93010,
    title: 'Target Store #T-1027',
    description: '209 W Ventura Blvd, Camarillo, CA 93010',
    surcharge: false,
    longitude: 34.22101,
    latitude: -119.10104
  },
  {
    zipcode: 91320,
    title: 'Target Store #T-1100',
    description: '2705 Teller Rd, Thousand Oaks, CA 91320',
    surcharge: false,
    longitude: 34.19011,
    latitude: -118.93503
  },
  {
    zipcode: 93021,
    title: 'Target Store #T-1547',
    description: '800 New Los Angeles Ave, Moorpark, CA 93021',
    surcharge: false,
    longitude: 34.26862,
    latitude: -118.85515
  },
  {
    zipcode: 95762,
    title: 'Target Store #T-2270',
    description: '4400 Town Center Blvd, El Dorado Hills, CA 95762',
    surcharge: false,
    longitude: 38.65008,
    latitude: -121.06239
  },
  {
    zipcode: 93003,
    title: 'Target Store #T-2398',
    description: '245 S Mills Rd, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.27181,
    latitude: -119.24756
  },
  {
    zipcode: 93065,
    title: 'Target Store #T-2462',
    description: '51 Tierra Rejada Rd, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.2741,
    latitude: -118.80418
  },
  {
    zipcode: 93036,
    title: 'Target Store #T-2760',
    description: '2850 N Oxnard Blvd, Oxnard, CA 93036',
    surcharge: false,
    longitude: 34.2172,
    latitude: -119.16134
  },
  {
    zipcode: 94103,
    title: 'Target Store #T-2766',
    description: '789 Mission St, San Francisco, CA 94103',
    surcharge: false,
    longitude: 37.78486,
    latitude: -122.40362
  },
  {
    zipcode: 94118,
    title: 'TRADER JOE\'S  #100',
    description: '3 Masonic Ave, San Francisco, CA 94118',
    surcharge: false,
    longitude: 37.78245,
    latitude: -122.44737
  },
  {
    zipcode: 93010,
    title: 'TRADER JOE\'S  #114',
    description: '363 Carmen Dr, Camarillo, CA 93010',
    surcharge: false,
    longitude: 34.22068,
    latitude: -119.05076
  },
  {
    zipcode: 93003,
    title: 'TRADER JOE\'S  #45',
    description: '1795 S Victoria Ave, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.25946,
    latitude: -119.21126
  },
  {
    zipcode: 94103,
    title: 'TRADER JOE\'S  #78',
    description: '555 9th St, San Francisco, CA 94103',
    surcharge: false,
    longitude: 37.77067,
    latitude: -122.40763
  },
  {
    zipcode: 94133,
    title: 'TRADER JOE\'S #19',
    description: '401 Bay St, San Francisco, CA 94133',
    surcharge: false,
    longitude: 37.80533,
    latitude: -122.41515
  },
  {
    zipcode: 91360,
    title: 'Trader Joe\'s #196',
    description: '451 E Avenida de Los Arboles, Thousand Oaks, CA 91360',
    surcharge: false,
    longitude: 34.21805,
    latitude: -118.86944
  },
  {
    zipcode: 94109,
    title: 'Trader Joes #200',
    description: '1095 Hyde St, San Francisco, CA 94109',
    surcharge: false,
    longitude: 37.79091,
    latitude: -122.41747
  },
  {
    zipcode: 93003,
    title: 'Trader Joe\'s #218',
    description: '103 S Mills Rd, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.27226,
    latitude: -119.24766
  },
  {
    zipcode: 94132,
    title: 'Trader Joes #236',
    description: '265 Winston Dr, San Francisco, CA 94132',
    surcharge: false,
    longitude: 37.72689,
    latitude: -122.4757
  },
  {
    zipcode: 91320,
    title: 'Trader Joes #243',
    description: '125 N Reino Rd, Newbury Park, CA 91320',
    surcharge: false,
    longitude: 34.18243,
    latitude: -118.95342
  },
  {
    zipcode: 93065,
    title: 'TRADER JOE\'S #30',
    description: '2975 Cochran St Ste A, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.27908,
    latitude: -118.73825
  },
  {
    zipcode: 91362,
    title: 'TRADER JOE\'S #58',
    description: '3835 E  THOUSAND OAKS BLVD, Westlake Village, CA 91362',
    surcharge: false,
    longitude: 34.1624,
    latitude: -118.82553
  },
  {
    zipcode: 93030,
    title: 'VALLARTA SUPERMARKET #21',
    description: '1050 S A St, Oxnard, CA 93030',
    surcharge: false,
    longitude: 34.19068,
    latitude: -119.17857
  },
  {
    zipcode: 93065,
    title: 'Vallarta Supermarket #35',
    description: '1357 E Los Angeles Ave, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.27303,
    latitude: -118.79987
  },
  {
    zipcode: 93036,
    title: 'Vallarta Supermarkets #44',
    description: '2690 E Vineyard Ave, Oxnard, CA 93036',
    surcharge: false,
    longitude: 34.23144,
    latitude: -119.1734
  },
  {
    zipcode: 93010,
    title: 'VONS  #1672',
    description: '820 Arneill Rd, Camarillo, CA 93010',
    surcharge: false,
    longitude: 34.22595,
    latitude: -119.03898
  },
  {
    zipcode: 93021,
    title: 'VONS  #1735',
    description: '4241 Tierra Rejada Rd, Moorpark, CA 93021',
    surcharge: false,
    longitude: 34.26342,
    latitude: -118.87759
  },
  {
    zipcode: 91360,
    title: 'VONS #1610',
    description: '1790 N Moorpark Rd, Thousand Oaks, CA 91360',
    surcharge: false,
    longitude: 34.20132,
    latitude: -118.86819
  },
  {
    zipcode: 93030,
    title: 'VONS #1913',
    description: '450 S Ventura Rd, Oxnard, CA 93030',
    surcharge: false,
    longitude: 34.19856,
    latitude: -119.19465
  },
  {
    zipcode: 93063,
    title: 'VONS #2047',
    description: '5805 E Los Angeles Ave, Simi Valley, CA 93063',
    surcharge: false,
    longitude: 34.27182,
    latitude: -118.67775
  },
  {
    zipcode: 91362,
    title: 'VONS #2092',
    description: '2048 E Avenida de Los Arboles, Thousand Oaks, CA 91362',
    surcharge: false,
    longitude: 34.21118,
    latitude: -118.84187
  },
  {
    zipcode: 93012,
    title: 'VONS #2094',
    description: '5275 Mission Oaks Blvd, Camarillo, CA 93012',
    surcharge: false,
    longitude: 34.22847,
    latitude: -118.99792
  },
  {
    zipcode: 93001,
    title: 'VONS #2096',
    description: '115 W Main St, Ventura, CA 93001',
    surcharge: false,
    longitude: 34.28139,
    latitude: -119.30303
  },
  {
    zipcode: 93003,
    title: 'VONS #2164',
    description: '5688 Telephone Rd, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.2649,
    latitude: -119.21495
  },
  {
    zipcode: 91362,
    title: 'VONS #2215',
    description: '1135 Lindero Cyn Rd, Westlake Village, CA 91362',
    surcharge: false,
    longitude: 34.18559,
    latitude: -118.79001
  },
  {
    zipcode: 93023,
    title: 'VONS #2430',
    description: '1125 Maricopa Hwy, Ojai, CA 93023',
    surcharge: false,
    longitude: 34.44171,
    latitude: -119.26196
  },
  {
    zipcode: 93001,
    title: 'VONS #2431',
    description: '2433 Harbor Blvd, Ventura, CA 93001',
    surcharge: false,
    longitude: 34.26302,
    latitude: -119.2673
  },
  {
    zipcode: 93060,
    title: 'VONS #2434',
    description: '576 W Main St, Santa Paula, CA 93060',
    surcharge: false,
    longitude: 34.3444,
    latitude: -119.08362
  },
  {
    zipcode: 93036,
    title: 'VONS #2436',
    description: '2101 N Rose Ave, Oxnard, CA 93036',
    surcharge: false,
    longitude: 34.22373,
    latitude: -119.15869
  },
  {
    zipcode: 93015,
    title: 'VONS #2442',
    description: '636 W Ventura St, Fillmore, CA 93015',
    surcharge: false,
    longitude: 34.39625,
    latitude: -118.91684
  },
  {
    zipcode: 93065,
    title: 'VONS #2501',
    description: '1855 Cochran St, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.27908,
    latitude: -118.76209
  },
  {
    zipcode: 93003,
    title: 'VONS #2677',
    description: '2764 E Thompson Blvd, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.27227,
    latitude: -119.26022
  },
  {
    zipcode: 93003,
    title: 'VONS #2678',
    description: '6040 Telegraph Rd, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.27809,
    latitude: -119.21334
  },
  {
    zipcode: 93063,
    title: 'VONS #2692',
    description: '2938 Tapo Canyon Rd, Simi Valley, CA 93063',
    surcharge: false,
    longitude: 34.28865,
    latitude: -118.71758
  },
  {
    zipcode: 93035,
    title: 'VONS #2825',
    description: '1291 S Victoria Ave, Oxnard, CA 93035',
    surcharge: false,
    longitude: 34.19616,
    latitude: -119.21785
  },
  {
    zipcode: 91361,
    title: 'VONS #3135',
    description: '2725 Agoura Rd, Thousand Oaks, CA 91361',
    surcharge: false,
    longitude: 34.15083,
    latitude: -118.82597
  },
  {
    zipcode: 94124,
    title: 'WALGREEN #5487',
    description: '5300 3rd St, San Francisco, CA 94124',
    surcharge: false,
    longitude: 37.72927,
    latitude: -122.39274
  },
  {
    zipcode: 94103,
    title: 'WALGREEN CO #3185',
    description: '825 Market St, San Francisco, CA 94103',
    surcharge: false,
    longitude: 37.78565,
    latitude: -122.40579
  },
  {
    zipcode: 93065,
    title: 'Walgreens #10354',
    description: '2417 Sycamore Dr, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.27932,
    latitude: -118.74389
  },
  {
    zipcode: 94110,
    title: 'WALGREENS #1054',
    description: '3398 Mission St, San Francisco, CA 94110',
    surcharge: false,
    longitude: 37.74348,
    latitude: -122.42136
  },
  {
    zipcode: 95682,
    title: 'Walgreens #10599',
    description: '4014 Plaza Goldorado Cir, Cameron Park, CA 95682',
    surcharge: false,
    longitude: 38.66221,
    latitude: -120.97025
  },
  {
    zipcode: 93021,
    title: 'Walgreens #10738',
    description: '140 E Los Angeles Ave, Moorpark, CA 93021',
    surcharge: false,
    longitude: 34.29236,
    latitude: -118.84228
  },
  {
    zipcode: 94131,
    title: 'Walgreens #1109',
    description: '5260 Diamond Heights Blvd, San Francisco, CA 94131',
    surcharge: false,
    longitude: 37.74456,
    latitude: -122.43962
  },
  {
    zipcode: 94112,
    title: 'WALGREENS #1120',
    description: '4645 Mission St, San Francisco, CA 94112',
    surcharge: false,
    longitude: 37.7236,
    latitude: -122.4355
  },
  {
    zipcode: 94103,
    title: 'WALGREENS #1126',
    description: '1979 Mission St, San Francisco, CA 94103',
    surcharge: false,
    longitude: 37.76598,
    latitude: -122.41966
  },
  {
    zipcode: 93030,
    title: 'Walgreens #11707',
    description: '1801 N Rose Ave, Oxnard, CA 93030',
    surcharge: false,
    longitude: 34.21175,
    latitude: -119.1454
  },
  {
    zipcode: 95667,
    title: 'Walgreens #11823',
    description: '4220 Missouri Flat Rd, Placerville, CA 95667',
    surcharge: false,
    longitude: 38.70634,
    latitude: -120.83168
  },
  {
    zipcode: 94116,
    title: 'WALGREENS #1241',
    description: '1201 Taraval St, San Francisco, CA 94116',
    surcharge: false,
    longitude: 37.7428,
    latitude: -122.4792
  },
  {
    zipcode: 94102,
    title: 'WALGREENS #1283',
    description: '500 Geary St, San Francisco, CA 94102',
    surcharge: false,
    longitude: 37.78694,
    latitude: -122.4122
  },
  {
    zipcode: 95762,
    title: 'Walgreens #12840',
    description: '8230 Saratoga Way, El Dorado Hills, CA 95762',
    surcharge: false,
    longitude: 38.65923,
    latitude: -121.07208
  },
  {
    zipcode: 94107,
    title: 'WALGREENS #1297',
    description: '670 4th St, San Francisco, CA 94107',
    surcharge: false,
    longitude: 37.77757,
    latitude: -122.39573
  },
  {
    zipcode: 94114,
    title: 'WALGREENS #1327',
    description: '498 Castro St, San Francisco, CA 94114',
    surcharge: false,
    longitude: 37.76164,
    latitude: -122.43516
  },
  {
    zipcode: 94109,
    title: 'Walgreens #13666',
    description: '1300 Bush St, San Francisco, CA 94109',
    surcharge: false,
    longitude: 37.78889,
    latitude: -122.4195
  },
  {
    zipcode: 94118,
    title: 'Walgreens #13667',
    description: '5280 Geary Blvd, San Francisco, CA 94118',
    surcharge: false,
    longitude: 37.78065,
    latitude: -122.47577
  },
  {
    zipcode: 94102,
    title: 'Walgreens #13668',
    description: '1496 Market St, San Francisco, CA 94102',
    surcharge: false,
    longitude: 37.77634,
    latitude: -122.41796
  },
  {
    zipcode: 94127,
    title: 'Walgreens #13670',
    description: '200 W Portal Ave, San Francisco, CA 94127',
    surcharge: false,
    longitude: 37.73856,
    latitude: -122.46856
  },
  {
    zipcode: 94112,
    title: 'WALGREENS #1393',
    description: '1630 Ocean Ave, San Francisco, CA 94112',
    surcharge: false,
    longitude: 37.72466,
    latitude: -122.45928
  },
  {
    zipcode: 94123,
    title: 'WALGREENS #1403',
    description: '3201 Divisadero St, San Francisco, CA 94123',
    surcharge: false,
    longitude: 37.79938,
    latitude: -122.44281
  },
  {
    zipcode: 94133,
    title: 'Walgreens #15127',
    description: '1175 Columbus Ave, San Francisco, CA 94133',
    surcharge: false,
    longitude: 37.80468,
    latitude: -122.41667
  },
  {
    zipcode: 94103,
    title: 'Walgreens #15567',
    description: '845 Market St, San Francisco, CA 94103',
    surcharge: false,
    longitude: 37.78519,
    latitude: -122.4063
  },
  {
    zipcode: 94134,
    title: 'Walgreens #1626',
    description: '2494 San Bruno Ave, San Francisco, CA 94134',
    surcharge: false,
    longitude: 37.73076,
    latitude: -122.40498
  },
  {
    zipcode: 94132,
    title: 'Walgreens #2005',
    description: '2550 Ocean Ave, San Francisco, CA 94132',
    surcharge: false,
    longitude: 37.73135,
    latitude: -122.47227
  },
  {
    zipcode: 94114,
    title: 'WALGREENS #2088',
    description: '1333 Castro St, San Francisco, CA 94114',
    surcharge: false,
    longitude: 37.75124,
    latitude: -122.43399
  },
  {
    zipcode: 94133,
    title: 'WALGREENS #2125',
    description: '320 Bay St, San Francisco, CA 94133',
    surcharge: false,
    longitude: 37.80578,
    latitude: -122.41297
  },
  {
    zipcode: 94115,
    title: 'WALGREENS #2152',
    description: '1899 Fillmore St, San Francisco, CA 94115',
    surcharge: false,
    longitude: 37.7865,
    latitude: -122.43344
  },
  {
    zipcode: 94102,
    title: 'Walgreens #2153',
    description: '790 Van Ness Ave, San Francisco, CA 94102',
    surcharge: false,
    longitude: 37.78211,
    latitude: -122.42048
  },
  {
    zipcode: 94104,
    title: 'WALGREENS #2521',
    description: '300 Montgomery St, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.79192,
    latitude: -122.40248
  },
  {
    zipcode: 94122,
    title: 'Walgreens #2705',
    description: '2050 Irving St, San Francisco, CA 94122',
    surcharge: false,
    longitude: 37.76354,
    latitude: -122.47955
  },
  {
    zipcode: 94115,
    title: 'WALGREENS #2866',
    description: '1363 Divisadero St, San Francisco, CA 94115',
    surcharge: false,
    longitude: 37.78181,
    latitude: -122.43931
  },
  {
    zipcode: 94109,
    title: 'WALGREENS #3358',
    description: '1301 Franklin St, San Francisco, CA 94109',
    surcharge: false,
    longitude: 37.78689,
    latitude: -122.4234
  },
  {
    zipcode: 94108,
    title: 'WALGREENS #3383',
    description: '141 Kearny St, San Francisco, CA 94108',
    surcharge: false,
    longitude: 37.78913,
    latitude: -122.40379
  },
  {
    zipcode: 94121,
    title: 'WALGREENS #3475',
    description: '25 Point Lobos Ave, San Francisco, CA 94121',
    surcharge: false,
    longitude: 37.77954,
    latitude: -122.50324
  },
  {
    zipcode: 94111,
    title: 'WALGREENS #3624',
    description: '275 Sacramento St, San Francisco, CA 94111',
    surcharge: false,
    longitude: 37.79479,
    latitude: -122.39847
  },
  {
    zipcode: 94110,
    title: 'WALGREENS #3711',
    description: '1189 Potrero Ave, San Francisco, CA 94110',
    surcharge: false,
    longitude: 37.75399,
    latitude: -122.40633
  },
  {
    zipcode: 94118,
    title: 'WALGREENS #3849',
    description: '745 Clement St, San Francisco, CA 94118',
    surcharge: false,
    longitude: 37.78275,
    latitude: -122.46675
  },
  {
    zipcode: 94122,
    title: 'WALGREENS #3869',
    description: '1750 Noriega St, San Francisco, CA 94122',
    surcharge: false,
    longitude: 37.75407,
    latitude: -122.48216
  },
  {
    zipcode: 94110,
    title: 'Walgreens #4231',
    description: '2690 Mission St, San Francisco, CA 94110',
    surcharge: false,
    longitude: 37.75477,
    latitude: -122.41877
  },
  {
    zipcode: 94105,
    title: 'Walgreens #4275',
    description: '456 Mission St, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.79013,
    latitude: -122.39725
  },
  {
    zipcode: 94111,
    title: 'Walgreens #4492',
    description: '33 Drumm St, San Francisco, CA 94111',
    surcharge: false,
    longitude: 37.79332,
    latitude: -122.39641
  },
  {
    zipcode: 94114,
    title: 'Walgreens #4529',
    description: '2145 Market St, San Francisco, CA 94114',
    surcharge: false,
    longitude: 37.76696,
    latitude: -122.42934
  },
  {
    zipcode: 94102,
    title: 'WALGREENS #4558',
    description: '300 Gough St, San Francisco, CA 94102',
    surcharge: false,
    longitude: 37.77597,
    latitude: -122.4227
  },
  {
    zipcode: 94116,
    title: 'Walgreens #4570',
    description: '3001 Taraval St, San Francisco, CA 94116',
    surcharge: false,
    longitude: 37.74194,
    latitude: -122.49855
  },
  {
    zipcode: 94103,
    title: 'WALGREEN\'S #4609',
    description: '1301 Market St, San Francisco, CA 94103',
    surcharge: false,
    longitude: 37.77685,
    latitude: -122.41687
  },
  {
    zipcode: 94102,
    title: 'Walgreens #4680',
    description: '730 Market St, San Francisco, CA 94102',
    surcharge: false,
    longitude: 37.7877,
    latitude: -122.40351
  },
  {
    zipcode: 94109,
    title: 'WALGREENS #5599',
    description: '2120 Polk St, San Francisco, CA 94109',
    surcharge: false,
    longitude: 37.79635,
    latitude: -122.42175
  },
  {
    zipcode: 94104,
    title: 'WALGREENS #5618',
    description: '100 Sansome St, San Francisco, CA 94104',
    surcharge: false,
    longitude: 37.79119,
    latitude: -122.40065
  },
  {
    zipcode: 93036,
    title: 'WALGREENS #5846',
    description: '2303 E Vineyard Ave, Oxnard, CA 93036',
    surcharge: false,
    longitude: 34.2268,
    latitude: -119.17709
  },
  {
    zipcode: 94105,
    title: 'WALGREENS #6291',
    description: '116 New Montgomery St, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.78714,
    latitude: -122.40027
  },
  {
    zipcode: 94117,
    title: 'Walgreens #6557',
    description: '199 Parnassus Ave, San Francisco, CA 94117',
    surcharge: false,
    longitude: 37.76451,
    latitude: -122.45182
  },
  {
    zipcode: 94123,
    title: 'Walgreens #6625',
    description: '2141 Chestnut St, San Francisco, CA 94123',
    surcharge: false,
    longitude: 37.80044,
    latitude: -122.43844
  },
  {
    zipcode: 94102,
    title: 'WALGREENS #7043',
    description: '459 Powell St, San Francisco, CA 94102',
    surcharge: false,
    longitude: 37.78873,
    latitude: -122.40858
  },
  {
    zipcode: 94105,
    title: 'WALGREENS #7044',
    description: '88 Spear St, San Francisco, CA 94105',
    surcharge: false,
    longitude: 37.79259,
    latitude: -122.39428
  },
  {
    zipcode: 94112,
    title: 'WALGREENS #7150',
    description: '965 Geneva Ave, San Francisco, CA 94112',
    surcharge: false,
    longitude: 37.71602,
    latitude: -122.43988
  },
  {
    zipcode: 93033,
    title: 'WALGREENS #7305',
    description: '2851 S Rose Ave, Oxnard, CA 93033',
    surcharge: false,
    longitude: 34.18008,
    latitude: -119.1599
  },
  {
    zipcode: 93030,
    title: 'Walgreens #7449',
    description: '481 S Ventura Rd, Oxnard, CA 93030',
    surcharge: false,
    longitude: 34.19793,
    latitude: -119.19484
  },
  {
    zipcode: 91320,
    title: 'Walgreens #7992',
    description: '550 N Ventu Park Rd, Thousand Oaks, CA 91320',
    surcharge: false,
    longitude: 34.17003,
    latitude: -118.90548
  },
  {
    zipcode: 94109,
    title: 'WALGREENS #887',
    description: '1524 Polk St, San Francisco, CA 94109',
    surcharge: false,
    longitude: 37.79098,
    latitude: -122.42067
  },
  {
    zipcode: 94102,
    title: 'Walgreens #890',
    description: '135 Powell St, San Francisco, CA 94102',
    surcharge: false,
    longitude: 37.78594,
    latitude: -122.40803
  },
  {
    zipcode: 94133,
    title: 'Walgreens #893',
    description: '1344 Stockton St, San Francisco, CA 94133',
    surcharge: false,
    longitude: 37.79797,
    latitude: -122.40859
  },
  {
    zipcode: 94118,
    title: 'Walgreens #896',
    description: '3601 California St, San Francisco, CA 94118',
    surcharge: false,
    longitude: 37.78627,
    latitude: -122.45384
  },
  {
    zipcode: 94110,
    title: 'Walgreens #9886',
    description: '3400 Cesar Chavez, San Francisco, CA 94110',
    surcharge: false,
    longitude: 37.74819,
    latitude: -122.41855
  },
  {
    zipcode: 94124,
    title: 'WALGREENS CO #2244',
    description: '3801 3rd St, San Francisco, CA 94124',
    surcharge: false,
    longitude: 37.74266,
    latitude: -122.38783
  },
  {
    zipcode: 93003,
    title: 'Walmart #3650',
    description: '1739 S Victoria Ave, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.25969,
    latitude: -119.21132
  },
  {
    zipcode: 93063,
    title: 'Walmart Neighborhood Market #3147',
    description: '2204 Tapo St, Simi Valley, CA 93063',
    surcharge: false,
    longitude: 34.27649,
    latitude: -118.70885
  },
  {
    zipcode: 91320,
    title: 'Walmart Neighborhood Market #3179',
    description: '512 N Ventu Park Rd, Thousand Oaks, CA 91320',
    surcharge: false,
    longitude: 34.17003,
    latitude: -118.90548
  },
  {
    zipcode: 93036,
    title: 'Walmart Neighborhood Market #5643',
    description: '421 W Esplanade Dr, Oxnard, CA 93036',
    surcharge: false,
    longitude: 34.22948,
    latitude: -119.1734
  },
  {
    zipcode: 93010,
    title: 'Walmart Neighborhood Market #5664',
    description: '275 W Ventura Blvd, Camarillo, CA 93010',
    surcharge: false,
    longitude: 34.22101,
    latitude: -119.10104
  },
  {
    zipcode: 93036,
    title: 'Walmart Store #2032',
    description: '2001 N Rose Ave, Oxnard, CA 93036',
    surcharge: false,
    longitude: 34.22106,
    latitude: -119.15836
  },
  {
    zipcode: 95667,
    title: 'Walmart Store #2418',
    description: '4300 Missouri Flat Rd, Placerville, CA 95667',
    surcharge: false,
    longitude: 38.70299,
    latitude: -120.82684
  },
  {
    zipcode: 93065,
    title: 'Walmart Store #2621',
    description: '255 Cochran St, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.28299,
    latitude: -118.79851
  },
  {
    zipcode: 93033,
    title: 'Walmart Store #3087',
    description: '2701 Saviers Rd, Oxnard, CA 93033',
    surcharge: false,
    longitude: 34.17496,
    latitude: -119.17762
  },
  {
    zipcode: 93065,
    title: 'Walmart Store #5685',
    description: '2801 E Cochran St, Simi Valley, CA 93065',
    surcharge: false,
    longitude: 34.27908,
    latitude: -118.74142
  },
  {
    zipcode: 96097,
    title: 'Walmart SuperCenter #1630',
    description: '1906 Fort Jones Rd, Yreka, CA 96097',
    surcharge: false,
    longitude: 41.7023,
    latitude: -122.64548
  },
  {
    zipcode: 94109,
    title: 'Whole Foods Market #10044',
    description: '1765 California St, San Francisco, CA 94109',
    surcharge: false,
    longitude: 37.79014,
    latitude: -122.42338
  },
  {
    zipcode: 94107,
    title: 'Whole Foods Market #10151',
    description: '399 4th St, San Francisco, CA 94107',
    surcharge: false,
    longitude: 37.78086,
    latitude: -122.39956
  },
  {
    zipcode: 91360,
    title: 'Whole Foods Market #10204',
    description: '740 N Moorpark Rd, Thousand Oaks, CA 91360',
    surcharge: false,
    longitude: 34.18796,
    latitude: -118.87447
  },
  {
    zipcode: 94107,
    title: 'Whole Foods Market #10238',
    description: '450 Rhode Island St, San Francisco, CA 94107',
    surcharge: false,
    longitude: 37.76412,
    latitude: -122.40259
  },
  {
    zipcode: 93036,
    title: 'Whole Foods Market #10318',
    description: '630 Town Center Dr, Oxnard, CA 93036',
    surcharge: false,
    longitude: 34.23489,
    latitude: -119.18094
  },
  {
    zipcode: 94117,
    title: 'Whole Foods Market #10362',
    description: '690 Stanyan St, San Francisco, CA 94117',
    surcharge: false,
    longitude: 37.76968,
    latitude: -122.45355
  },
  {
    zipcode: 94114,
    title: 'Whole Foods Market #10379',
    description: '3950 24th St, San Francisco, CA 94114',
    surcharge: false,
    longitude: 37.7516,
    latitude: -122.43052
  },
  {
    zipcode: 94114,
    title: 'Whole Foods Market #10396',
    description: '2001 Market St, San Francisco, CA 94114',
    surcharge: false,
    longitude: 37.76832,
    latitude: -122.42711
  },
  {
    zipcode: 94112,
    title: 'Whole Foods Market #10432',
    description: '1150 Ocean Ave, San Francisco, CA 94112',
    surcharge: false,
    longitude: 37.72381,
    latitude: -122.45524
  },
  {
    zipcode: 93003,
    title: 'WinCo Foods #116',
    description: '4750 Telephone Rd, Ventura, CA 93003',
    surcharge: false,
    longitude: 34.2632,
    latitude: -119.22677
  },
  {
    zipcode: 95623,
    title: 'EL DORADO GROCERY & DELI',
    description: '6203    Pleasant Valley Rd, EL DORADO, CA 95623',
    surcharge: false,
    longitude: 38.68216,
    latitude: -120.84562
  },
  {
    zipcode: 95667,
    title: '',
    description: ', Placerville, CA 95667',
    surcharge: true,
    longitude: 0,
    latitude: 0
  },
  {
    zipcode: 94112,
    title: '',
    description: '5129    MISSION ST, San Francisco, CA 94112',
    surcharge: true,
    longitude: 37.71679,
    latitude: -122.44064
  },
  {
    zipcode: 94110,
    title: '',
    description: '993    SHOTWELL ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75297,
    latitude: -122.41513
  },
  {
    zipcode: 94110,
    title: '',
    description: '2531    MISSION ST, San Francisco, CA 94110',
    surcharge: true,
    longitude: 37.75622,
    latitude: -122.41873
  },
  {
    zipcode: 94102,
    title: '',
    description: '1098B    MARKET ST, San Francisco, CA 94102',
    surcharge: true,
    longitude: 37.78163,
    latitude: -122.41126
  },
  {
    zipcode: 94108,
    title: '',
    description: '9    KEARNY ST, San Francisco, CA 94108',
    surcharge: true,
    longitude: 37.78805,
    latitude: -122.4036
  }
];