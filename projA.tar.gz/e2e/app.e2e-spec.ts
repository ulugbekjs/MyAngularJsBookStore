import { ProjAPage } from './app.po';

describe('proj-a App', () => {
  let page: ProjAPage;

  beforeEach(() => {
    page = new ProjAPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
