import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

import { OnChanges, ChangeDetectionStrategy, ElementRef } from '@angular/core';


import { MdSelectModule } from '@angular/material';


@Component({
  selector: 'country-selector',
  templateUrl: './country-selector.component.html',
  styleUrls: ['./country-selector.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CountrySelectorComponent implements OnInit {

  @Input() countries: string[];

  @Output() changeCountry: EventEmitter<string> = new EventEmitter<string>();

  ngOnChanges(...args: any[]) {
    console.log("change detected from child");
    this.changeCountry.emit(this.selectedCountry);
  }
  
  
  
  // myChange(str: any) {
  //   console.log(str.value);
  // }

  // @Output() public onChange: EventEmitter<string> = new EventEmitter<string>();



  selectedCountry: string;

  constructor() {
    // this.myEvent.emit(this.selectedCountry);
   }

  ngOnInit() {
  }

}
