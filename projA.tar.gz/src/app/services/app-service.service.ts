import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

import { Card } from '../app.component';

@Injectable()
export class AppService {

  getCards(theUrl: string): Observable<Card[]> {
    return this.http.get(theUrl).map(res => res.json());
  }


  getCountries(): Observable<string[]> {
    return this.http.get('../../assets/countries.json').map(res => res.json());
  }

  getReports(): Observable<string[]> {
    return this.http.get('../../assets/reports.json').map(res => res.json());
  }


  constructor(private http: Http) { }

}
