import { NgModule, ErrorHandler } from '@angular/core';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';
import { AboutPage } from '../pages/about/about';
import { ContactPage } from '../pages/contact/contact';
import { HomePage } from '../pages/home/home';
import { TabsPage } from '../pages/tabs/tabs';
import {TransactionsPage} from '../pages/transactions/transactions';
import {SettingsPage} from '../pages/settings/settings';
import { LoginPage } from '../pages/login/login';
import { LanguagePage } from '../pages/language/language';
import { ResourcesPage } from '../pages/resources/resources';
import { RegisterPage } from '../pages/register/register';
import { ArrayFilterPipe } from "../pipes/array-filter.pipe";
import { TrnTypeFilter } from '../pipes/typefilter';
//Services
import { AuthService } from '../providers/auth-service';
import { TransactionService } from '../providers/transaction-service';
import {UserInfoService}  from '../providers/userinfo-service-mock'

import {HttpModule} from '@angular/http';
import {TranslateModule, TranslateStaticLoader, TranslateLoader} from 'ng2-translate/ng2-translate';
import {Http} from '@angular/http';
import {BrowserModule} from "@angular/platform-browser";
import {LocationsPage} from '../pages/locations/locations';
import { LocationResultsPage } from '../pages/locationresults/locationresults';
import { FilterData } from '../pages/locationresults/filterdata';
import { MapPage } from '../pages/map/map';
import { ListPage } from '../pages/list/list';
import { Locations } from '../providers/locations';
import { GoogleMaps } from '../providers/google-maps';
import { Connectivity } from '../providers/connectivity';

export function createTranslateLoader(http: Http) {
  return new TranslateStaticLoader(http, './assets/i18n', '.json');
}

@NgModule({
  declarations: [
    MyApp,
    AboutPage,
    ContactPage,
    HomePage,
    TabsPage,
    TransactionsPage,
    SettingsPage,
    LoginPage,
    LocationsPage,
    LocationResultsPage,
    FilterData,
    LanguagePage,
    ResourcesPage,
    ArrayFilterPipe,
    TrnTypeFilter,
<<<<<<< .mine
	TransactionsPage, RegisterPage
=======
    Page1,
    MapPage,
    ListPage
>>>>>>> .r10947
  ],
  imports: [
    IonicModule.forRoot(MyApp),
    BrowserModule,
    HttpModule,
    TranslateModule.forRoot({
    provide: TranslateLoader,
    useFactory: createTranslateLoader,
    deps: [Http]
    })

  ],
   exports: [BrowserModule, HttpModule, TranslateModule],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    AboutPage,  
    ContactPage,
    HomePage,
    TabsPage,
    TransactionsPage,
    SettingsPage,
    LoginPage,
    LanguagePage,
	TransactionsPage,
    ResourcesPage, 
	RegisterPage,

    LocationsPage,
    LocationResultsPage,
    
    ResourcesPage,
    MapPage,
    ListPage
  ],
  providers: [{ provide: ErrorHandler, useClass: IonicErrorHandler }, TransactionService, UserInfoService, AuthService, Locations, GoogleMaps, Connectivity]
})
export class AppModule {}
