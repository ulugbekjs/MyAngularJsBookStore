import { Component, NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { NavController } from 'ionic-angular';
import { XMlHttpRequestProvider } from '../../providers/x-ml-http-request-provider';

@Component({
    selector: 'page-page1',
    templateUrl: 'page1.html',
    providers: [XMlHttpRequestProvider]
})
@NgModule({
    imports: [CommonModule]
})
export class Page1 {
    transactionlist: any;
    userballist : any;  
    filteredlist = [];
    startdate: any;
    enddate: any;
    daterange = 90;
    datePipeEn: any
    arr = [];
    newarr = [];
    dateArray = [];
    shownGroup = null;
    currentDate = "";
    numberOfItemsToDisplay = 6;
    cash = 540;
    food = 690;
    constructor(public navCtrl: NavController, private xmlhttp: XMlHttpRequestProvider) {
        
        this.transactionlist = xmlhttp.getTransactionData();//transaction history list

        this.userballist = xmlhttp.getBalanceData(); //balanc list

        this.datePipeEn = new DatePipe('en-US');
       
        this.newarr = this.getuniquedatevalues(this.getfinallist().slice(0,this.numberOfItemsToDisplay));

    }

    get date() {
        this.currentDate = new Date().toLocaleTimeString('en-US', { hour: 'numeric', hour12: true, minute: 'numeric', timeZoneName: 'long' });
        return this.currentDate;
    }

    
    toggleGroup(event: any) {
        if (this.isGroupShown(event)) {
            this.shownGroup = null;
        } else {
            this.shownGroup = event;
        }
    };
    toggleDetails(data) {
        if (data.showDetails) {
            data.showDetails = false;

        } else {
            data.showDetails = true;

        }
    }
    isGroupShown(event: any) {
        return this.shownGroup == event;
    };
    trntype = "ALL";
    transactiontype(event: any) {
        this.trntype = event.currentTarget.value;
     this.getnewArray();

    }
    getdaterange(event: any) {
        this.daterange = event.currentTarget.value;
       this.getnewArray();

    }
    getlistafterdaterange() {
        if (this.daterange == 90) {
            var list = this.transactionlist;
            return list;
        } else {

            this.startdate = this.getstartdate();
            this.enddate = this.getenddate(this.startdate, this.daterange);
            this.filteredlist = this.applydaterange(this.startdate, this.enddate, this.transactionlist);
        }
        return this.filteredlist;
    }
    getuniquedatevalues(list) {
        let arr1 = new Array();
        for (let date in list) {
            console.log(list[date].stTransactionDate);
            var x = (list[date].stTransactionDate.slice(0, 7));
            arr1.push(x);
        }
        let obj = {};
        for (let i = 0; i < arr1.length; i++) {
            obj[arr1[i]] = true;
        }
        this.newarr = [];
        for (let key in obj) {
            this.newarr.push(key);
        }


        var sortedArray1: string[] = this.getSortedArray(this.newarr);
        return sortedArray1;
    }
    getstartdate() {
        for (let date in this.transactionlist) {
            var x = (this.transactionlist[date].stTransactionDate);

            this.dateArray.push(x);
        }
        var sortedArray: string[] = this.getSortedArray(this.dateArray);
        return sortedArray[0];
    }

    getenddate(date, range) {
        let reggie = /(\d{4})-(\d{2})-(\d{2})/;
        let dateArray = reggie.exec(date);
        let dateObject = new Date(
            (+dateArray[1]),
            ((+dateArray[2])) - 1,
            (+dateArray[3])
        );
        let enddate = new Date(dateObject);
        enddate.setDate(enddate.getDate() - range);
        return this.datePipeEn.transform(enddate, 'yyyy-MM-dd');
    }

    applydaterange(stdate, enddate, list) {

        var newlist = [];
        for (let x in list) {

            if (new Date(list[x].stTransactionDate).valueOf() >= new Date(enddate).valueOf()) {
                if (new Date(list[x].stTransactionDate).valueOf() <= new Date(stdate).valueOf()) {
                    newlist.push(list[x]);
                }
            }
        }

        return newlist;
    }
    getfinallist() {
        var finallist = [];
        if (this.trntype == "ALL") {
            finallist = this.getlistafterdaterange();
            return finallist;
        }
        else {
            for (let item in this.getlistafterdaterange()) {
                if (this.trntype === this.getlistafterdaterange()[item].stTransactioType) {
                    finallist.push(this.getlistafterdaterange()[item]);
                }
            }
        }
        return finallist;
    }
    getSortedArray(array: any) {
        var sortedArray: string[] = array.sort((n1, n2) => {
            if (n1 > n2) {
                return -1;
            }
            if (n1 < n2) {
                return 1;
            }
            return 0;
        });
        return sortedArray;
    }
    addmore() {
       
        if (this.getfinallist().length > this.numberOfItemsToDisplay)
            this.numberOfItemsToDisplay += 6; // load number of more items
            this.getnewArray();
      
            return this.numberOfItemsToDisplay;
    }
    getnewArray(){
        this.newarr = this.getuniquedatevalues(this.getfinallist().slice(0,this.numberOfItemsToDisplay));
    }
    hasMoreitems(){
        var b;
        if(this.getfinallist().length < this.numberOfItemsToDisplay){
        
            b = false;
        }
        else
        b = true;
        return b;
    }
}

