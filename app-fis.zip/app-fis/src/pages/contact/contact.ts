import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import {Injectable, Pipe} from '@angular/core';
import * as _ from 'lodash';

@Pipe({ name: 'order-by' })
export class OrderByPipe {
  transform(array, args) {
    return _.sortBy(array, args);
  }
}



@Component({
  selector: 'page-contact',
  templateUrl: 'contact.html'
})
export class ContactPage {
items: any;
constructor(public navCtrl: NavController) {
this.items = [
            {title: 'one'},
            {title: 'two'},
            {title: 'three'},
            {title: 'four'},
            {title: 'five'},
            {title: 'six'}
        ]
}

}
