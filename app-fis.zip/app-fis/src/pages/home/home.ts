import { Component } from '@angular/core';
import { NavController,PopoverController,ViewController} from 'ionic-angular';
import {UserInfoService}  from '../../providers/userinfo-service-mock'
import { TransactionsPage } from '../../pages/transactions/transactions'; 
import { TabsPage } from '../tabs/tabs';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'  
})

export class HomePage {
 cardholder : any;

  constructor(public navCtrl: NavController, public service : UserInfoService) {
    service.findById('1').then(data => this.cardholder = data);
  }

  gotoTransactionPage()
  {
   // console.log("tra");
   // this.navCtrl.push(Page1);
    this.navCtrl.setRoot(TransactionsPage,{Test:true}); 
  }
}