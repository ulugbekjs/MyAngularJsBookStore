import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { UserInfoService } from '../../providers/userinfo-service-mock';
import { HomePage } from '../../pages/home/home';
import { TranslateService } from 'ng2-translate/ng2-translate';
/*import { ContactPage } from '../pages/contact/contact';
import { HomePage } from '../pages/home/home';
import { TabsPage } from '../pages/tabs/tabs';
import { TransactionsPage} from '../pages/transactions/transactions';
*/

/*
  Generated class for the Settings page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-settings',
  templateUrl: 'settings.html'
})
export class SettingsPage {
  cardholder: any;
  byText = true;
  byEmail = true;
  newBenifitAvailable = true;
  newAdjustmentComplete = false;
  myAccountInactive = true;
  benefitsExpireSoon = true;
  newsFromState = true;

  constructor(public navCtrl: NavController, public navParams: NavParams, public service: UserInfoService, private translate: TranslateService) {
    service.findById('1').then(data => this.cardholder = data);
  
}

  ionViewDidLoad() {
    console.log('ionViewDidLoad SettingsPage');    
  }

  gotoHomePage() {
   // this.navCtrl.push(HomePage);
    this.navCtrl.push(HomePage);
    console.log("gotohomepage event");
  }

  saveSettings() {
    console.log("By Text:"+this.byText);
    console.log("By Email:"+this.byEmail);
    console.log("New Benifit Available:"+this.newBenifitAvailable);
    console.log("New Adjustment Complete:"+this.newAdjustmentComplete);
    console.log("MyAccountInactive:"+this.myAccountInactive);
    console.log("BenefitsExpireSoon:"+this.benefitsExpireSoon);
    console.log("NewsFromState:"+this.newsFromState);  
  }  
}