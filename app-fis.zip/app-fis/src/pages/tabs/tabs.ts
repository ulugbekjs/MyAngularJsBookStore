import { Component } from '@angular/core';
import { HomePage } from '../home/home';
import { AboutPage } from '../about/about';
import { ContactPage } from '../contact/contact';
import { TransactionsPage } from '../transactions/transactions';
import { SettingsPage } from '../settings/settings';
import { NavParams } from 'ionic-angular';
import { LocationsPage } from '../locations/locations';
import { MapPage } from '../map/map';
import { ListPage } from '../list/list';

@Component({
  templateUrl: 'tabs.html'
})
export class TabsPage {
  // this tells the tabs component which Pages
  // should be each tab's root Page
 /* tab1Root: any = HomePage;
  tab5Root: any = AboutPage;
  tab4Root: any = ContactPage;
  tab2Root: any = TransactionsPage;
  tab3Root: any = SettingsPage; */

  tab1Root: any = HomePage;
  tab2Root: any = TransactionsPage;
  tab3Root: any = SettingsPage;
  tab4Root: any = LocationsPage;
  tab5Root: any = AboutPage; 
  tab6Root: any = ContactPage;  
  tab7Root: any = MapPage;
  tab8Root: any = ListPage;

  mySelectedIndex: number;

  constructor(navParams: NavParams) {
    this.mySelectedIndex = navParams.data.tabIndex || 0;
    
  }
}
