import { Component, ElementRef, ViewChild} from '@angular/core';
import { NavController, Platform, NavParams} from 'ionic-angular';
import { GoogleMaps } from '../../providers/google-maps';
//import { MapPage } from '../map/map';
import { Locations } from '../../providers/locations';
import { Http } from '@angular/http';


declare var google;

/*
  Generated class for the LocationResults page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-locationresults',
  templateUrl: 'locationresults.html'

})
export class LocationResultsPage {

  @ViewChild('map') mapElement: ElementRef;
  @ViewChild('pleaseConnect') pleaseConnect: ElementRef;
    
  filteredLocationsList = null;
  map: any;
  markers: any = [];

  locationDataList = null;
  sortedlocationDataList = null;
  argDist = '';
  argSurcharge = '';
  sortArgDist = '';
  sortArgSurcharge = '';
  userSearchTag = [];
  userSearchSubTag = [];
  showListAndMapViewButton = true;  
  maxLoadResultPerPage = 21;
  showMapView = true;  
  showListview = false;


  constructor(public navCtrl: NavController, public navParams: NavParams, public maps: GoogleMaps, public platform: Platform, public locations: Locations, public http: Http) {
    this.navCtrl = navCtrl;
    this.userSearchTag = this.navParams.get('userSearchTag');
    this.userSearchSubTag = this.navParams.get('userSearchSubTag');
    this.callLocationService();
  }

   ionViewDidLoad(){        
        /*this.platform.ready().then(() => {
 
            let mapLoaded = this.maps.init(this.mapElement.nativeElement, this.pleaseConnect.nativeElement);
            let locationsLoaded = this.locations.load();
 
            Promise.all([
                mapLoaded,
                locationsLoaded
            ]).then((result) => {                
                // let locations = result[1];
                let locations = this.sortedlocationDataList;
 
                for(let location of locations){
                    // this.maps.addMarker(location.latitude, location.longitude);
                    this.maps.addMarker(location.stLatitude, location.stLongitude);
                }
 
            });
 
        });*/
 
    }

    addMarker(lat: number, lng: number): void {
 
    let latLng = new google.maps.LatLng(lat, lng);
 
    let marker = new google.maps.Marker({
      map: this.map,
      animation: google.maps.Animation.DROP,
      position: latLng
    });
 
    this.markers.push(marker);  
 
  }

  showMap(){      
    this.showMapView = false;    
    this.showListview = true;

    this.platform.ready().then(() => {
 
            let mapLoaded = this.maps.init(this.mapElement.nativeElement, this.pleaseConnect.nativeElement);
            let locationsLoaded = this.locations.load();
 
            Promise.all([
                mapLoaded,
                locationsLoaded
            ]).then((result) => {                
                // let locations = result[1];
                let locations = this.sortedlocationDataList;                           
 
                for(let location of locations){                    
                    this.maps.addMarker(location.latitude, location.longitude);
                }
 
            });
 
        });                

    //this.navCtrl.push(MapPage,{filteredLocationsList: this.sortedlocationDataList});    //Passing data to next page. 
  }

  showList(){
    this.showMapView = true;    
    this.showListview = false;
  }

  goBackToPrvPage() {
    this.navCtrl.pop();
  }

  distanceFilter(event: any) {
    this.argDist = event.currentTarget.value;
  }

  surchargeFilter(event: any) {
    this.argSurcharge = event.currentTarget.value;
  }

  sortresults() {
    this.showListAndMapViewButton = false;
    this.sortArgDist = this.argDist;
    this.sortArgSurcharge = this.argSurcharge;
    this.argDist = '';
    this.argSurcharge = '';
  }

  callLocationService() {

    //Data from MicroService Start

  /*var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("POST", "http://localhost:8080/locationservice?stLocationtype=" + this.userSearchTag + ",&stLocationSubtype=" + this.userSearchSubTag, false);
    xmlhttp.send();
    // alert(xmlhttp.response);
    var vLocationListData = JSON.parse(xmlhttp.response);
    this.locationDataList = vLocationListData;
    */

    //Data from MicroService End

    /*********************/
        
    //Data from Local Service Provider Start


    /*this.http.get('assets/data/locations.json').map(res => res.json()).subscribe(locationDataList => {

                this.locationDataList = locationDataList.locations;               

                // resolve(this.locationDataList);
                alert(this.locationDataList);
                });*/

    return new Promise(resolve => {

            this.http.get('assets/data/locations.json').map(res => res.json()).subscribe(locationDataList => {

                this.locationDataList = this.locations.applyHaversine(locationDataList.locations);

                this.locationDataList.sort((locationA, locationB) => {
                    return locationA.distance - locationB.distance;
                });

                resolve(this.locationDataList);
                                
            });

        });

    //Data from Local Service Provider End

        
    /*for (let i in  this.locationDataList) {
      alert(this.locationDataList[i].stLocationName);
    }*/
  } 
}
