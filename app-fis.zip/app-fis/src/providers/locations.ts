import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { Geolocation } from 'ionic-native';

declare var google;

@Injectable()
export class Locations {

    data: any;    

    constructor(public http: Http) {

    }

    load() {

        if (this.data) {
            return Promise.resolve(this.data);
        }

        return new Promise(resolve => {

            this.http.get('assets/data/locations.json').map(res => res.json()).subscribe(data => {

                this.data = this.applyHaversine(data.locations);

                this.data.sort((locationA, locationB) => {
                    return locationA.distance - locationB.distance;
                });

                resolve(this.data);
            });

        });


    }

    applyHaversine(locations) {

        Geolocation.getCurrentPosition().then((position) => {

            // UNCOMMENT FOR NORMAL USE --> This is to get user's current location.
            //let latLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);         
           
            // let usersLocation = {
            //     lat: position.coords.latitude,
            //     lng: position.coords.longitude
            // };      

            let usersLocation = {
                lat: 43.038902,
                lng: -87.906474
            };     

            locations.map((location) => {

                let placeLocation = {
                    lat: location.latitude,
                    lng: location.longitude
                };

                location.distance = this.getDistanceBetweenPoints(
                    usersLocation,
                    placeLocation,
                    'miles'
                ).toFixed(2);
            });
        });
        return locations;
    }

    getDistanceBetweenPoints(start, end, units) {

        let earthRadius = {
            miles: 3958.8,
            km: 6371
        };

        let R = earthRadius[units || 'miles'];
        let lat1 = start.lat;
        let lon1 = start.lng;
        let lat2 = end.lat;
        let lon2 = end.lng;

        let dLat = this.toRad((lat2 - lat1));
        let dLon = this.toRad((lon2 - lon1));
        let a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(this.toRad(lat1)) * Math.cos(this.toRad(lat2)) *
            Math.sin(dLon / 2) *
            Math.sin(dLon / 2);
        let c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        let d = R * c;

        return d;

    }

    toRad(x) {
        return x * Math.PI / 180;
    }

}