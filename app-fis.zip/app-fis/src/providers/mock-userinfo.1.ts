let cardholders = [
    {
        id: 1,
        firstName: "LINDA",
        lastName: "SANDOVAL",
        pan : "5077122110000001407",
        panStatus : "A",
        caBal : "73.05",
        fsBal : "220.12",
        ccBal : "300.00",
        alerts :[{message : "You have first alert" }, {message : "You have second alert" }],
        phone: "617-244-3672",
        email: "linda.sandoval009@gmail.com",
        transactions :[{}]

}]

export default cardholders;
