import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';


@Injectable()
export class TransactionService {

  constructor(public http: Http) {
    console.log('Hello Transaction Provider');
  }

}
