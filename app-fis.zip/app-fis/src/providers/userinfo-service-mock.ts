import { Injectable } from '@angular/core';

import 'rxjs/add/operator/map';

import cardholders from './mock-userinfo'

@Injectable()
export class UserInfoService {

   findAll() {
        return Promise.resolve(cardholders);
    }

    findById(id) {
        return Promise.resolve(cardholders[0]);
    }

}
