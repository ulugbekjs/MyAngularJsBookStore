import { Injectable } from '@angular/core';

import 'rxjs/add/operator/map';
import { Http } from '@angular/http';
import cardholders from './mock-userinfo'

@Injectable()
export class UserInfoService {
     data;
      dataById;
    constructor(public http: Http) {
        //console.log('Hello PeopleService Provider');
    }
   findAll() {
        return Promise.resolve(cardholders);
    }

  /*  findById(id) {
        return Promise.resolve(cardholders[0]);
    } */


   /*findById(id) {           
         return new Promise(resolve => {
    // We're using Angular HTTP provider to request the data,
    // then on the response, it'll map the JSON data to a parsed JS object.
    // Next, we process the data and resolve the promise with the new data.
      // this.http.get('https://api.github.com/users/mralexgray/repos')
         console.log("start");
       //this.http.get('http://10.74.135.178:9999/gov/portal/ca/cardhistory?pan=5077190000001491').map(res => res.json()).subscribe(dataById => {
       this.http.get('http://phxebtqcwss01.corp.efunds.com:9999/gov/portal/ca/cardhistory?pan=5077190000001491').map(res => res.json()).subscribe(dataById => {
            
           
      this.dataById = dataById.balanceSummary;         
      resolve(this.dataById); 
        });         
    });
   }  */
    
     findAlternateById(id) {
        return new Promise(resolve => {
            //this.http.get('http://localhost:9999/gov/portal/ca/alternate?pan=5077190000001491')
             this.http.get('http://phxebtqcwss01.corp.efunds.com:9999/gov/portal/ca/alternate?pan=5077190000001490')
                .map(res => res.json())
                .subscribe(data => {
                    this.data = data;
                    resolve(this.data);
                });
            console.log(this.data);
        });
    }
}
