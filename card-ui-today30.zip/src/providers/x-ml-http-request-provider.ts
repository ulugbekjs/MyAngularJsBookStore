import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';

/*
  Generated class for the XMlHttpRequestProvider provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info on providers and Angular 2 DI.
*/
@Injectable()
export class XMlHttpRequestProvider {
trnitems : any;
balitems ; any;
  constructor(public http: Http) {
   
  }
getTransactionData(){
   var xmlhttp = new XMLHttpRequest();
  xmlhttp.open("POST","http://phxebtqcwss01.corp.efunds.com:9999/gov/portal/ca/cardhistory?pan=5077190000001491 ",false);
  //xmlhttp.open("POST","http://10.74.135.178:9999/gov/portal/ca/cardhistory?pan=5077190000001491 ",false);
  xmlhttp.send();
  this.trnitems = JSON.parse(xmlhttp.response);
  return this.trnitems;
}
}
