

import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name: "filter",
    pure: false
})
export class ArrayFilterPipe implements PipeTransform {


    transform(items: Array<any>, conditions: {[field: string]: any}): Array<any> {
        return items.filter(item => {
            for (let field in conditions) {
                
                if (item[field].split('-')[1] !== conditions[field].split('-')[1] || item[field].split('-')[0] !== conditions[field].split('-')[0]  ) {
                    return false;
                }
            }
            return true;
        });
    }
}

