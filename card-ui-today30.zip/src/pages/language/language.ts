import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { Splashscreen } from 'ionic-native';
import { Events } from 'ionic-angular';
import { TranslateService } from 'ng2-translate/ng2-translate';
import { App } from 'ionic-angular';

/*
  Generated class for the Language page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-language',
  templateUrl: 'language.html'
})
export class LanguagePage {

  constructor(public navCtrl: NavController, public navParams: NavParams,public appCtrl: App, private translate: TranslateService) {}

  ionViewDidLoad() {
    console.log('ionViewDidLoad LanguagePage');
   // location.reload();
   // this.initTranslation();
    //viewController.fireWillEnter();
    //window.location.reload();
    //Splashscreen.show(); 
    //state.reload()
 }


  initTranslationEn() {
    var userLang = navigator.language.split('-')[0]; // use navigator lang if available
    userLang = /(fr|en|es|in|zh)/gi.test(userLang) ? userLang : 'es';  
    // this language will be used as a fallback when a translation isn't found in the current language
    this.translate.setDefaultLang('es');  
    // the lang to use, if the lang isn't available, it will use the current loader to get them
    this.translate.use('en');
    this.translate.get("HOME", null).subscribe(localizedValue => console.log(localizedValue));
    //window.location.reload();
  }

   initTranslationEs() {
    var userLang = navigator.language.split('-')[0]; // use navigator lang if available
    userLang = /(fr|en|es|in|zh)/gi.test(userLang) ? userLang : 'es';   
    // this language will be used as a fallback when a translation isn't found in the current language
    this.translate.setDefaultLang('en'); 
    // the lang to use, if the lang isn't available, it will use the current loader to get them
    this.translate.use('es');
    this.translate.get("HOME", null).subscribe(localizedValue => console.log(localizedValue));
    //window.location.reload();
  }

  saveSelectedLanguage() {
    var currLang = this.translate.currentLang;
    console.log(currLang);
  }
}
