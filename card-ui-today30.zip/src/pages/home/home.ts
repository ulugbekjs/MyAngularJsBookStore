import { Component } from '@angular/core';
import { NavController, PopoverController, ViewController, NavParams } from 'ionic-angular';
import { UserInfoService } from '../../providers/userinfo-service-mock'
import { TransactionsPage } from '../../pages/transactions/transactions';
import { TabsPage } from '../tabs/tabs';
import { AlertController } from 'ionic-angular';
import { Storage } from '@ionic/storage';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})

export class HomePage {
  cardholder: any;
  alternate: any;
  pan;
  fsAmt = '';
  cashAmt = '';

  namelist;
  constructor(public navCtrl: NavController, public service: UserInfoService, public alertCtrl: AlertController, public navParms: NavParams, public storage: Storage) {
    // Or to get a key/value pair    

    storage.ready();

    storage.get('usercred').then((val) => {

      if (val != null) {
        console.log('Your name is in Home', JSON.parse(val));
        var obj = JSON.parse(val);
        this.pan = obj.user;
//        alert("paninhome:" + this.pan);
      } else {
        storage.get('usercred').then((val) => {
          console.log('Your name is in second home', JSON.parse(val));
          var obj = JSON.parse(val);
          this.pan = obj.user;
        //  alert("paninhomesecond:" + this.pan);
        })
      }
    })

    
    this.getData();   
    service.findAlternateById('1').then(data => this.alternate = data);    
  }

  getData() {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("POST", "http://phxebtqcwss01.corp.efunds.com:9999/gov/portal/ca/cardhistory?pan="+this.pan, false);
    xmlhttp.send();
    // alert(xmlhttp.response);
    var vLocationListData = JSON.parse(xmlhttp.response);
    this.cardholder = vLocationListData.balanceSummary;
    this.pan = vLocationListData.balanceSummary.pan;
    this.fsAmt = vLocationListData.balanceSummary.fsAmt;
    this.cashAmt = vLocationListData.balanceSummary.cashAmt;
  }

  gotoTransactionPage() {
    // console.log("tra");
    // this.navCtrl.push(Page1);
    this.navCtrl.setRoot(TransactionsPage, { Test: true });
  }

  showAlternate() {
    console.log("AlternateS")
    this.service.findAlternateById('1').then(data => this.alternate = data);
    // var namelist ='<html>Mano </br>Ravi</br>Ram</br></html>'
    // console.log("Data"+this.alternate.firstName)
    this.namelist = "";
    for (var _i = 0; _i < this.alternate.alternatenameList.length; _i++) {
      this.namelist += this.alternate.alternatenameList[_i].firstName + "," + this.alternate.alternatenameList[_i].lastName + "<br>";
    }
    //  this.namelist="";
    console.log(this.namelist);

    let alert = this.alertCtrl.create({
      title: '<font >Alternates</font>',
      subTitle: this.namelist,
      buttons: ['OK']
    });
    alert.present();
  }
}