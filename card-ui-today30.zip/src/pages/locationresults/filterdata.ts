import { Pipe, PipeTransform } from '@angular/core';
import { LocationResultsPage } from '../locationresults/locationresults';

@Pipe({
    name: 'filterData',
    pure: false
})

export class FilterData implements PipeTransform {

    constructor(public locationsResults: LocationResultsPage) {
 
    }  
    transform(items: any[], argsD: string, argsS: string): any[] {
        var resultArray = [];
        if ((argsD === '') && (argsS === '')) {
            resultArray = items;
        } else if ((argsD != '') && (argsS === '')) {
            for (let item of items) {
                if ((parseFloat(item.stDistance) <= parseFloat(argsD))) {
                    resultArray.push(item);
                }
            }
        } else if ((argsS != '') && (argsD === '')) {
            for (let item of items) {
                if ((parseFloat(item.stSurcharge) <= parseFloat(argsS))) {
                    resultArray.push(item);
                }
            }
        } else if ((argsD != '') && (argsS != '')) {
            for (let item of items) {
                if ((parseFloat(item.stSurcharge) <= parseFloat(argsS)) && (parseFloat(item.stDistance) <= parseFloat(argsD))) {
                    resultArray.push(item);
                }
            }
        } 
        this.locationsResults.sortedlocationDataList = resultArray;
        return resultArray;
    }

}