import { Component, NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { NavController, NavParams } from 'ionic-angular';
import { XMlHttpRequestProvider } from '../../providers/x-ml-http-request-provider';
import * as $ from 'jquery';

@Component({
    selector: 'page-transactions',
    templateUrl: 'transactions.html',
    providers: [XMlHttpRequestProvider]
})
@NgModule({
    imports: [CommonModule]
})
export class TransactionsPage {
    transactionlist: any;
    userballist: any;
    filteredlist = [];
    startdate: any;
    enddate: any;
    daterange = 90;
    datePipeEn: any
    arr = [];
    newarr = [];
    dateArray = [];
    shownGroup = null;
    currentDate = "";
    numberOfItemsToDisplay = 3;
    cashbal :any;
    foodbal :any;
    accountnum :any;
    param : any;
    trntype = "ALL";
    trntype1 ="FS";
    finallist = [];
    Cashtype : boolean = false;
    Alltype : boolean = false;
    Foodtype : boolean = false;
    foodindex:any;
    historysummary : any;
    constructor(public navCtrl: NavController, private xmlhttp: XMlHttpRequestProvider, private navParams: NavParams) {

        this.historysummary = xmlhttp.getTransactionData();//transaction history list

        this.userballist = this.historysummary.balanceSummary;//balanc list

        this.transactionlist = this.historysummary.historySearchResponse.history;
        
        this.datePipeEn = new DatePipe('en-US');

        this.finallist = this.getfinallist();

        this.newarr = this.getuniquedatevalues(this.getfinallist().slice(0, this.numberOfItemsToDisplay));

        this.accountnum = this.userballist.pan.slice(12,16);
        
        this.cashbal = this.userballist.cashAmt;
        
        this.foodbal = this.userballist.fsAmt;
       
       
       console.log(this.finallist);
  
    }
   
    
    get date() {
        this.currentDate = new Date().toLocaleTimeString('en-US', { hour: 'numeric', hour12: true, minute: 'numeric', timeZoneName: 'long' });
        return this.currentDate;
    }
    

    toggleGroup(event: any) {
        if (this.isGroupShown(event)) {
            this.shownGroup = null;
        } else {
            this.shownGroup = event;
        }
    };
    toggleDetails(data) {
        if (data.showDetails) {
            data.showDetails = false;

        } else {
            data.showDetails = true;

        }
    }
    isGroupShown(event: any) {
        return this.shownGroup == event;
    };
    
    transactiontype(event: any) {
        this.trntype = event.currentTarget.value;
        
        this.getnewArray();

    }
    getdaterange(event: any) {
         
        this.daterange = event.currentTarget.value;
         
        this.getnewArray();

    }
    getlistafterdaterange() {
        if (this.daterange == 90) {
            var list = this.transactionlist;
            return list;
        } else {

            this.startdate = this.getstartdate();
            this.enddate = this.getenddate(this.startdate, this.daterange);
            this.filteredlist = this.applydaterange(this.startdate, this.enddate, this.transactionlist);
        }
        return this.filteredlist;
    }
    getuniquedatevalues(list) {
        let arr1 = new Array();
        for (let date in list) {
            console.log(list[date].tranDate);
           
            var x = (list[date].tranDate.slice(0,7));
           
            arr1.push(x);
        }
        let obj = {};
        for (let i = 0; i < arr1.length; i++) {
            obj[arr1[i]] = true;
        }
        this.newarr = [];
        for (let key in obj) {
            this.newarr.push(key);
        }


        var sortedArray1: string[] = this.getSortedArray(this.newarr);
        return sortedArray1;
    }
    getstartdate() {
        for (let date in this.transactionlist) {
            var x = (this.transactionlist[date].tranDate);

            this.dateArray.push(x);
        }
        var sortedArray: string[] = this.getSortedArray(this.dateArray);
        return sortedArray[0];
    }

    getenddate(date, range) {
        let reggie = /(\d{4})-(\d{2})-(\d{2})/;
        let dateArray = reggie.exec(date);
        let dateObject = new Date(
            ((+dateArray[1])) ,
            ((+dateArray[2])) - 1,
            (+dateArray[3])
        );
        let enddate = new Date(dateObject);
        enddate.setDate(enddate.getDate() - range);
        return this.datePipeEn.transform(enddate, 'MM/dd/yyyy');
    }

    applydaterange(stdate, enddate, list) {

        var newlist = [];
        for (let x in list) {

            if (new Date(list[x].tranDate).valueOf() >= new Date(enddate).valueOf()) {
                if (new Date(list[x].tranDate).valueOf() <= new Date(stdate).valueOf()) {
                    newlist.push(list[x]);
                }
            }
        }

        return newlist;
    }
    getfinallist() {
        var finallist = [];
        this.foodindex = this.navParams.data.tabIndex;
        var cashindex = this.navParams.data.tabIndex;
       
     if(this.foodindex == null || this.foodindex == "" || this.foodindex == undefined || cashindex == null || cashindex == "" || cashindex== undefined ){
         
        if (this.trntype == "ALL") {
            finallist = this.getlistafterdaterange();
            return finallist;
        }
        else {
            for (let item in this.getlistafterdaterange()) {
                 if (this.trntype === this.getlistafterdaterange()[item].programClass) {
                   
                    finallist.push(this.getlistafterdaterange()[item]);

                }
            }
        }
     
        return finallist;
     }else if(this.foodindex == 6){
        this.Alltype = true; 
       this.Cashtype = true;
         for (let item in this.getlistafterdaterange()) {
                if ("Food Stamp" === this.getlistafterdaterange()[item].programClass) {
                    
                    finallist.push(this.getlistafterdaterange()[item]);
                }
            }
            return finallist;
        }else if(cashindex == 7){
         this.Alltype = true;
         this.Foodtype = true;
             
         for (let item in this.getlistafterdaterange()) {
                if ("Cash" === this.getlistafterdaterange()[item].programClass) {
                   
                    finallist.push(this.getlistafterdaterange()[item]);
                }
            }
            return finallist;
        }
        
     
    }
    getSortedArray(array: any) {
        var sortedArray: string[] = array.sort((n1, n2) => {
            if (n1 > n2) {
                return -1;
            }
            if (n1 < n2) {
                return 1;
            }
            return 0;
        });
        return sortedArray;
    }
    addmore() {

        if (this.getfinallist().length > this.numberOfItemsToDisplay)
            this.numberOfItemsToDisplay += 3; // load number of more items
        this.getnewArray();

        return this.numberOfItemsToDisplay;
    }
    getnewArray() {
        this.newarr = this.getuniquedatevalues(this.getfinallist().slice(0, this.numberOfItemsToDisplay));
    }
    hasMoreitems() {
        var b;
        if (this.getfinallist().length < this.numberOfItemsToDisplay) {

            b = false;
        }
        else
            b = true;
        return b;
    }
    noRecordsFound() {
        var b;
        if (this.getfinallist().length != 0) {

            b = false;
        }
        else
            b = true;
        return b;
    }

     addClass = function (el, cl) {
        el.className += ' ' + cl;
    }

    removeClass = function (el, cl) {
        var regex = new RegExp('(?:\\s|^)' + cl + '(?:\\s|$)');
        el.className = el.className.replace(regex, ' ');
    }
    


}

window.onload=()=>{

}