import { Component } from '@angular/core';
import { NavController, AlertController, LoadingController, Loading } from 'ionic-angular';
import { AuthService } from '../../providers/auth-service';
//import { RegisterPage } from '../register/register';
import { HomePage } from '../home/home';
import { TabsPage } from '../tabs/tabs';
import { Storage } from '@ionic/storage';

import { ResponsiveModule } from 'ng2-responsive';

@Component({
  selector: 'page-login',
  templateUrl: 'login.html'
})
export class LoginPage {
  loading: Loading;
  registerCredentials = {email: '', password: ''};
 
  constructor(private nav: NavController, private auth: AuthService, private alertCtrl: AlertController, private loadingCtrl: LoadingController, public storage: Storage) {
 // set a key/value
  

  }
 
  public createAccount() {
    //this.nav.push(RegisterPage);
  }
 
  public login() {
    this.showLoading()
    this.auth.login(this.registerCredentials).subscribe(allowed => {
      if (allowed) {

        var userObj = {
    //user: this.registerCredentials.email,
    //pass: this.registerCredentials.password
    user: this.registerCredentials.email,
    pass: 'pass'
  };  
    this.storage.clear();
    this.storage.remove('usercred');
    this.storage.ready();    
    this.storage.set('usercred', JSON.stringify(userObj));

    // Or to get a key/value pair
   

        setTimeout(() => {
        this.loading.dismiss();  
        this.nav.setRoot(TabsPage)
        });
      } else {
        this.showError("Invalid login");
      }
    },
    error => {
      this.showError(error);
    });
  }
 
  showLoading() {
    this.loading = this.loadingCtrl.create({
      content: 'Please wait...'
    });
    this.loading.present();
  }
 
  showError(text) {
    setTimeout(() => {
      this.loading.dismiss();
    });
 
    let alert = this.alertCtrl.create({
      title: 'Fail',
      subTitle: text,
      buttons: ['OK']
    });
    alert.present(prompt);
  }
  
}