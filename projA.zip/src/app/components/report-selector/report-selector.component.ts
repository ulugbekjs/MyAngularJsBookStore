import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-selector',
  templateUrl: './report-selector.component.html',
  styleUrls: ['./report-selector.component.css']
})
export class ReportSelectorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
