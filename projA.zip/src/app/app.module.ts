import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { MaterialModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


import { AppComponent } from './app.component';
import { CardComponent } from './components/card/card.component';
import { CountrySelectorComponent } from './components/country-selector/country-selector.component';
import { ReportSelectorComponent } from './components/report-selector/report-selector.component';

import { AppService } from './services/app-service.service'

@NgModule({
  declarations: [
    AppComponent,
    CardComponent,
    CountrySelectorComponent,
    ReportSelectorComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    MaterialModule,
    BrowserAnimationsModule
  ],
  providers: [AppService],
  bootstrap: [AppComponent]
})
export class AppModule { }
