import { Component, OnInit } from '@angular/core';
import { CountrySelectorComponent } from './components/country-selector/country-selector.component';
import { AppService } from './services/app-service.service'
import { Observable } from 'rxjs/Observable';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{

  constructor(private service: AppService) { }

  title = 'app works!';
  country: string = 'USA';
  report: string = 'EBT01';
  
  cards: Card[] = [];
  reportsList: string[];
  countriesList: string[];


  setCountry(c: string = 'USA') {
    console.log(c);
    this.country = c;
    this.loadCards();
  }

  setReport(r: string = 'EBT01') {
    this.country = r;
    this.loadCards();
  }

  ngOnInit(): void {
    this.loadCountries();
    this.loadReports();
    this.loadCards();
  }

  loadCards() {
    let theUrl = '../../assets/'+this.country+'/'+this.report+'/data.json';

    this.service.getCards(theUrl)
                .subscribe(
                  cards => this.cards = cards
                );
  }

  loadReports() {
    this.service.getReports()
                .subscribe(
                  reps => this.reportsList = reps
                );                
  }

  loadCountries() {
    this.service.getCountries()
                    .subscribe(
                      countries => this.countriesList = countries
                    );
  }


}

export interface Card {
  date: string;
  desc: string;
  link: string;
}