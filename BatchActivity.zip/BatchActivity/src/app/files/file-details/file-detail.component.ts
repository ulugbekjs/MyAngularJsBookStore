import 'rxjs/add/operator/switchMap';

import { Component, OnInit, HostBinding, Input } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';

import { slideInDownAnimation } from '../../animations/file-details.animations';

import { FileService }         from '../../provider/file.service';
import {File} from '../../provider/file';

@Component({
  templateUrl: `./file-detail.component.html`,
  styleUrls:['../file-list.component.css','./file-detail.component.css'] ,
  animations: [ slideInDownAnimation ]
})
export class FileDetailComponent implements OnInit {
  @HostBinding('@routeAnimation') routeAnimation = true;
  @HostBinding('style.display')   display = 'inherit';
  @HostBinding('style.position')  position = 'relative';

  file: File;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private fileService: FileService
  ) {}

  ngOnInit() {
    this.route.params
      // (+) converts string 'id' to a number
      .switchMap((params: Params) => this.fileService.getFile(+params['id']))
      .subscribe((file: File) => this.file = file);
  }

  gotoFiles() {
    let fileId = this.file ? this.file.id : null;
    this.router.navigate(['/files', { id: fileId, details: 'errors'}]);
  }
}
