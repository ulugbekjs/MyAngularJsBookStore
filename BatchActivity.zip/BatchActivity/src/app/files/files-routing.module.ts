import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { FileListComponent }    from './file-list.component';
import { FileDetailComponent }  from './file-details/file-detail.component';

const filesRoutes: Routes = [
  { path: 'files',  component: FileListComponent },
  { path: 'file/:id', component: FileDetailComponent }
];

@NgModule({
  imports: [
    RouterModule.forChild(filesRoutes)
  ],
  exports: [
    RouterModule
  ]
})

export class FileRoutingModule { }
