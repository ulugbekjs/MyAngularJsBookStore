import { NgModule }       from '@angular/core';
import { CommonModule }   from '@angular/common';
import { FormsModule }    from '@angular/forms';

import { FileListComponent }    from './file-list.component';
import { FileDetailComponent }  from './file-details/file-detail.component';

import { FileService } from "../provider/file.service";

import { FileRoutingModule } from './files-routing.module';

import { Md2Module }  from 'md2';
import {NgxPaginationModule} from 'ngx-pagination';

import { OrderByPipePipe } from '../pipes/order-by-pipe.pipe';
import { UniqueTypePipe } from '../pipes/unique-type.pipe';
import { DatePipePipe } from '../pipes/date-pipe.pipe';

import { DaterangePickerModule } from 'ng2-daterange-picker';

import { MdCardModule,
         MdButtonModule, 
         MdSelectModule,
         MdCheckboxModule,
         MdIconModule, 
         MdRadioModule} from '@angular/material';

import { FlexLayoutModule } from '@angular/flex-layout';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    FileRoutingModule,
    DaterangePickerModule,
    NgxPaginationModule,
    Md2Module.forRoot(),
    MdCardModule,
    MdButtonModule,
    MdSelectModule,
    MdCheckboxModule,
    MdIconModule,
    MdRadioModule,
    FlexLayoutModule
  ],
  declarations: [
    FileListComponent,
    FileDetailComponent,
    OrderByPipePipe,
    UniqueTypePipe,
    DatePipePipe
  ],
  providers: [ FileService ]
})
export class FilesModule {}
