import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';

import 'rxjs/add/operator/switchMap';
import { Observable } from 'rxjs/Observable';

import { FileService }         from '../provider/file.service';
import {File} from '../provider/file';

import * as moment from 'moment';

import { toggleSlideAnimation } from '../animations/card-details-toggle.animations';

@Component({
  selector: 'file-list',
  templateUrl: './file-list.component.html',
  providers: [ FileService ],
  styleUrls: ['./file-list.component.css'],
  animations: [ toggleSlideAnimation ]
})

export class FileListComponent{
  
  files: File[];
  fileId: Observable<File[]>;
  permanent_files: File[];
  
  private selectedId: number;

  constructor (
    private route: ActivatedRoute,
    private router: Router,
    private fileService: FileService, 
    ) {}

  ngOnInit() { 
   this.getFiles();
   this.fileId =  this.route.params
      .switchMap((params: Params) => {
        this.selectedId = +params['id'];
        return this.fileService.getFiles();
      });
  }
  
  getFiles() {
    this.fileService.getFiles()
                     .then(
                       files => this.files = files)
                     .then(
                       () => this.permanent_files = this.files);
  }

  isSelected(file: File) { return file.id === this.selectedId; }

  onSelect(file: File) {
    this.router.navigate(['/file', file.id]);
  }

  p: number = 1;

  isOpened: boolean = false;

  toggle(){
    this.isOpened = !this.isOpened;
  }

  mindate: any;
  maxdate: any;

  mdate: Date;
  
  selectedDate(){

    if(!this.mdate) return;

    if(this.mdate !== null){ 
      let ndate = moment(this.mdate).format("MM/DD/YYYY");    
  
      this.files = this.permanent_files.filter(file => {
            let xdate = moment(file.processing_startsTs).format("MM/DD/YYYY");
            return xdate === ndate});
    } 
  }


  // @ViewChild('daterangePicker', { read: ViewContainerRef }) daterangePickerParentViewContainer: ViewContainerRef;

  // showDaterangePickerSelector() {
  //   let daterangePickerComponentFactory = this.componentFactory.resolveComponentFactory(DaterangePickerComponent);
  //   let daterangePickerComponent: DaterangePickerComponent = DaterangePickerComponent.initWithData(this.daterangePickerParentViewContainer, daterangePickerComponentFactory);

  //   daterangePickerComponent.onSelectedDaterange.subscribe(
  //         data => {
  //                   this.showSelectedDaterange(data.startDate, data.endDate);
  //         }
  //   );
  // }

  // showSelectedDaterange(startDate: Date, endDate: Date) {
    
  //     let mindate = moment(startDate).format("MM/DD/YYYY");
  //     let maxdate = moment(endDate).format("MM/DD/YYYY");

  //     this.files = this.permanent_files.filter(file => {
  //           let xdate = moment(file.processing_startsTs).format("MM/DD/YYYY");
  //           return (xdate >= mindate && xdate <= maxdate)});
  // }

  selectedCounty: string;

  sortByCounty(){
    if(this.selectedCounty !== null){
      this.files = this.permanent_files.filter(file => {
        return file.county === this.selectedCounty});
    }
  }

  selectedFileType: string;

  sortByFileType(){
    if(this.selectedFileType !== null){
      this.files = this.permanent_files.filter(file => {
        return file.fileType === this.selectedFileType});
    }
  }

  statuss = [
    {value: 'In Queue'},
    {value: 'In Processing'},
    {value: 'Completed'},
    {value: 'Failed'}
  ];

  selectedStatus: string;

  sortByStatus(){
    if(this.selectedStatus !== null){
      this.files = this.permanent_files.filter(file => {
        return file.processing_status === this.selectedStatus});
    }
  }

}

