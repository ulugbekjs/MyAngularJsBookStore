import { Injectable } from '@angular/core';
import { Headers, Http, Response, RequestOptions } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';

import { File } from './file';

@Injectable()
export class FileService {

  private filesUrl = '../assets/MOCK_DATA.json';  
  
  constructor (private http: Http) {}
  
  getFiles(): Promise<File[]> {
    return this.http.get(this.filesUrl)
                    .toPromise()
                    .then(res => res.json() as File[]);
  }

  getFile(id: number | string) {
    return this.getFiles()
      .then(files => files.find(file => file.id === +id));
  }
  
}