export class File {
  constructor(
  public id: number,
  public fileName: String,
  public arrivalTs: String,
  public county: String,
  public processing_startsTs: string,
  public processing_endTs: Date,
  public processing_status: String,
  public number_of_errors: Number,
  public number_of_records: Number,
  public fileType: String,
  public error: String  
  ){}
  
}