import { NgModule }              from '@angular/core';
import { RouterModule, Routes }  from '@angular/router';

//import { FileListComponent }     from './files/file-list.component';
import { PageNotFoundComponent } from './not-found.component';

const appRoutes: Routes = [
  //{ path: 'heroes',        component: FileListComponent },
  { path: '',   redirectTo: '/files', pathMatch: 'full' },
  { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes)
  ],
  exports: [
    RouterModule
  ]
})

export class AppRoutingModule {}
