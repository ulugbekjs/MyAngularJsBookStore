import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule, JsonpModule } from '@angular/http';
import { RouterModule, Routes } from '@angular/router';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import 'hammerjs';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';

import { FilesModule }     from './files/files.module';

import { PageNotFoundComponent } from './not-found.component';

import { ShellModule } from '@ruf/shell';
import { MdIconModule, 
         MdSidenavModule,
         MdCardModule, 
         MdButtonModule,
         MdSelectModule,
         MdCheckboxModule, } from '@angular/material';



@NgModule({
  declarations: [
    AppComponent,
    PageNotFoundComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpModule,
    JsonpModule,
    FilesModule,
    AppRoutingModule,
    ShellModule,
    MdIconModule,
    MdSidenavModule,
    MdButtonModule,
  ],
  providers: [ ],
  bootstrap: [AppComponent]
})
export class AppModule { }
