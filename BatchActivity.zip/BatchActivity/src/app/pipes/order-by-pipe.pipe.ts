import { Pipe, PipeTransform } from '@angular/core';
import {File} from '../provider/file';

@Pipe({
  name: 'orderByPipe'
})
export class OrderByPipePipe implements PipeTransform {
  transform(value: Array<File>, args: any) : Array<File>{
    if(!value){return;}
    let sortedArr =  value.sort(function(a: any, b: any){

      let c = new Date(a[args]).getTime();
      let d = new Date(b[args]).getTime();

      return d - c;
    });

    return sortedArr;
  }

}
