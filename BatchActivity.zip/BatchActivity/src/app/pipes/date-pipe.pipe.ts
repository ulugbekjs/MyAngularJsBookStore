import { Pipe, PipeTransform } from '@angular/core';
import * as moment from 'moment';
import 'moment-timezone'; 

@Pipe({
  name: 'datePipe'
})
export class DatePipePipe implements PipeTransform {

  transform(value: any) : any{
    if(!value){return;}

    let timezone = moment.tz.guess();
    
    let mdate = moment(value).tz(timezone).format("MM/DD/YYYY HH:mm:ss z");
    return mdate;
  }
}

