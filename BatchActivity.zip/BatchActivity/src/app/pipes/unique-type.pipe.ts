import { Pipe, PipeTransform } from '@angular/core';
import * as _ from 'lodash'; 

@Pipe({
  name: 'uniqueType'
})
export class UniqueTypePipe implements PipeTransform {
  transform(value: any, args: any): any{
    if(value!== undefined && value!== null){
      //gets the unique field in the files array.
      let uniqueSorted = _.uniqBy(value, args);

      //sorts the unique field array alphabetically.
      uniqueSorted.sort((a: any, b: any) => {
        let c = a[args];
        let d = b[args];
      if (c < d) {
        return -1;
      } else if (c > d) {
        return 1;
      } else {
        return 0;
      }
    });

    return uniqueSorted;
    }
    
  }
}
