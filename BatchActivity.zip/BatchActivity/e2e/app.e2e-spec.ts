import { ActivityAppMonPage } from './app.po';

describe('activity-app-mon App', () => {
  let page: ActivityAppMonPage;

  beforeEach(() => {
    page = new ActivityAppMonPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
